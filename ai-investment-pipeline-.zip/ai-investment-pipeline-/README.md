# AI Investment Pipeline

Point it at a topic, get one-page VC memos out the other end. A query-driven pipeline that
**sources** startups (Hacker News + YC), **analyzes** them, **scores** them against a stated
investment thesis, and writes **Pass / Watch / Take-a-meeting** memos — every claim traceable to a source.

## Setup

```bash
npm install
cp .env.example .env      # then add ONE key:
#   GROQ_API_KEY=...      
#   GEMINI_API_KEY=...     (alternative)
```

The provider is auto-selected (Groq if its key is set, else Gemini).

## Run a query

One command, topic in → memos out:

```bash
npm run pipeline -- --query "AI developer tools"
```

Flags: `--limit 15` · `--provider groq|gemini` · `--model <id>` · `--offline` (replay a cached run, no key) · `--run-id <name>`.

Stages can also run alone: `npm run source|analyze|score|memo -- --run-id <id>`. Tests: `npm test`.

## Pipeline flow

```
your query
   │
   ▼
① SOURCING                                                    → candidates.json + meta.json
   ├─ query planner (LLM): query → HN search terms + keywords
   ├─ Hacker News (Show HN) search on those terms  ┐
   ├─ YC export: enrich matches + grow the pool     ┘→ candidate pool
   └─ relevance filter (LLM, or keyword offline): keep only on-topic, no padding
   │
   ▼
② ANALYSIS  (per candidate)                                  → evidence/<id>.json + analysis/<id>.json
   ├─ gather evidence (verbatim facts + source URLs)
   └─ LLM reasons → Team / Product / Market / Traction / Risks / Unknowns  (every fact cites evidence)
   │
   ▼
③ SCORING  (per candidate)                                   → recommendations.json + unscored.json
   ├─ LLM fills gates + 5 rubric sub-scores (each with evidence)
   └─ code computes the weighted total + Pass / Watch / Take-a-meeting  (deterministic, reproducible)
   │
   ▼
④ MEMOS                                                      → memos/<id>.md + summary.md
   └─ deterministic render (no LLM): one-page memo per startup + ranked index
```

Cross-cutting: every HTTP + LLM call is cached (content-addressed) at `.cache/http/`, shared across runs;
each candidate is isolated (one failure never aborts the batch); every stage output is schema-validated.

## Reading a run report

Everything lands in `runs/<run-id>/`. Read it in this order:

| File | What it is |
|---|---|
| `summary.md` | **Start here** — ranked triage table (call · score · company), links to each memo, plus any *Unscored* companies |
| `memos/<id>.md` | One-page memo per startup (~60s read); every factual bullet cites a `[n]` source |
| `recommendations.json` | Machine-readable scores, gates, and calls |
| `meta.json` | How it was sourced — the LLM `searchPlan`, source counts, warnings |
| `candidates.json` · `evidence/` · `analysis/` | Intermediate artifacts (traceability: memo → analysis fact → evidence → source URL) |

`--offline` re-runs a query with no key and no network, served entirely from `.cache/http/`. It replays only
what that cache already holds for the exact same query and model, and fails loudly on a miss rather than
falling back to the network.

## How the docs are organized

`docs/` holds the design & decision record (read in this order):

- **assignment-analysis.md** — requirements, scope, and decisions.
- **thesis.md** — the investment thesis and scoring rubric (what a memo is judged against).
- **scoring-model.md** — how the rubric is derived and the score computed.
- **source-strategy.md** — where candidates come from and why.
- **data-model.md** — the schemas that flow between stages.
- **pipeline-design.md** — the stage architecture and cross-cutting design (cache, replay, isolation).
- **CLAUDE.md** — the brief and engineering principles.
