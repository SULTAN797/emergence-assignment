# Cohesive — Pass (23/100)

getcohesiveai.com · <https://getcohesiveai.com>

> The agentic CRM for blue-collar services [1]

**Score 23/100** — workflow 20 · team 10 · traction 45 · gtm 25 · moat 20

**Product.** Cohesive positions itself as an agentic CRM tailored for blue-collar services, but details regarding specific workflow automation or software integrations are unavailable.
- Cohesive is an agentic CRM built for blue-collar services. [1]

**Team.** No information is provided about the founders, technical depth, or domain experience in the trades.

**Market.** The company targets blue-collar service businesses, which aligns with trade and field-service sectors, though exact ideal customer profiles remain unspecified.
- Cohesive targets the blue-collar services market. [1]

**Traction.** Cohesive is backed by Y Combinator as part of its Spring 2025 batch. Other traction metrics like customer counts or revenue are not disclosed.
- Cohesive is backed by Y Combinator in the Spring 2025 batch. [1]

**Why we like it.** Acceptance into Y Combinator's Spring 2025 batch provides initial validation and early backing for an AI-native product targeting blue-collar services.

**Risks.** Complete lack of information on founder domain proximity and whether the product performs deep operational workflow actions versus lightweight CRM management.
- Unverified integration capabilities with existing field service management (FSM) systems or telephony providers.
- High potential competition from incumbent CRM and FSM software providers adding native AI features.

**What would change our mind.**
1. Demonstrated technical depth and domain proximity to trades or field-service software among the founding team.
2. Verification of deep, multi-directional integrations with core FSM systems of record (e.g., ServiceTitan, Jobber, QuickBooks) that execute real operational actions.
3. Quantitative traction metrics showing active trade SMB customer counts, retention, or automated booking/job volume.

**Sources.**
[1] Cohesive — YC profile — <https://www.ycombinator.com/companies/cohesive>
