# Feldy — Pass (23/100)

feldy.ai · <https://feldy.ai>

> Field-First AI for home services [1]

**Score 23/100** — workflow 20 · team 10 · traction 45 · gtm 20 · moat 20

**Product.** Feldy positions itself as 'Field-First AI for home services', but there are no details on specific workflow automation capabilities, core FSM integrations, or autonomous features.
- Feldy offers 'Field-First AI for home services'. [1]

**Team.** No information regarding the founders, their technical depth, or domain experience in home services is available in the provided evidence.

**Market.** Feldy targets the home services market, aligning broadly with the thesis domain, but specific sub-verticals and target SMB sizes are unconfirmed.
- Feldy targets the home services market. [1]

**Traction.** Feldy participated in Y Combinator's Winter 2024 batch, though specific customer and revenue traction metrics are not disclosed.
- Feldy is backed by Y Combinator and was in the Winter 2024 batch. [1]

**Why we like it.** Acceptance into Y Combinator's Winter 2024 batch provides early signal and confirms recent AI-native founding.

**Risks.** Complete lack of detail on product architecture, autonomous workflow capabilities, FSM integrations, and founder trade domain expertise.
- Insufficient evidence to verify whether the product executes core workflow actions or integrates into FSM/phone systems versus being a generic AI tool.
- Lack of verified founder technical expertise or trade domain experience.

**What would change our mind.**
1. Evidence of direct integrations into core FSM systems (ServiceTitan, Jobber, Housecall Pro) performing autonomous workflow execution like booking or dispatching.
2. Founder background details showing technical depth in AI/voice or real domain proximity to the trades.
3. Verified SMB customer usage metrics, booking volumes, or revenue growth.

**Sources.**
[1] Feldy — YC profile — <https://www.ycombinator.com/companies/feldy>
