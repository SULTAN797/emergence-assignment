# Cactus — Pass (24/100)

oncactus.com · <https://oncactus.com>

> All-In-One AI Growth Partner. Built for Trades. [1]

**Score 24/100** — workflow 20 · team 10 · traction 50 · gtm 25 · moat 15

**Product.** Cactus positions itself as an all-in-one AI growth partner tailored for trades businesses, but specific details regarding features, operational workflows, and software integrations are not provided.
- Cactus offers an all-in-one AI growth partner built for trades. [1]

**Team.** There is no information provided in the evidence regarding the team members or founder backgrounds.

**Market.** Cactus targets the trades industry, which aligns with home-services businesses.
- Cactus builds software designed for trades businesses. [1]

**Traction.** Cactus is backed by Y Combinator in the Spring 2025 batch.
- Cactus is backed by Y Combinator as part of the Spring 2025 batch. [1]

**Why we like it.** Acceptance into Y Combinator's Spring 2025 batch.

**Risks.** The product may focus on top-of-funnel lead generation rather than deep operational workflow automation and FSM system integration.
- The 'AI Growth Partner' positioning may indicate a marketing or top-of-funnel lead generation tool rather than core operational workflow automation.
- No evidence of integration with essential field service management (FSM) systems, phone systems, or accounting software.

**What would change our mind.**
1. Evidence of direct integrations with FSM tools (e.g., ServiceTitan, Jobber) that take automated operational actions like booking or dispatching.
2. Founder background details showing strong technical expertise and domain experience in trades or field software.
3. Traction data demonstrating SMB customer adoption, engagement, and retention.

**Sources.**
[1] Cactus — YC profile — <https://www.ycombinator.com/companies/oncactus>
