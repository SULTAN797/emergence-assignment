# Bravi — Pass (21/100)

bravi.app · <https://www.bravi.app/>

> The AI operating system powering home services businesses [1]

**Score 21/100** — workflow 25 · team 10 · traction 30 · gtm 20 · moat 20

**Product.** Bravi describes itself as an AI operating system for home services businesses, though specific feature capabilities and integrations are not detailed in the available evidence.
- Bravi develops an AI operating system targeting home services businesses. [1]

**Team.** There is no information provided regarding the founders, team composition, or domain/technical expertise.

**Market.** The company operates in the home services industry, though specific target SMB sub-verticals or customer profiles are unspecified in the provided evidence.
- Bravi builds software for home services businesses. [1]

**Traction.** Bravi is backed by Y Combinator in the Fall 2025 batch, but no revenue, customer, or usage metrics are provided.
- Bravi is backed by Y Combinator as part of the Fall 2025 batch. [1]

**Why we like it.** Selection into Y Combinator (Fall 2025 batch) targeting the home services vertical.

**Risks.** Complete absence of details on team domain/technical expertise and specific product workflow automation capabilities.
- Lack of detail on team domain proximity or technical background makes evaluating execution capability impossible with current data.
- Without product details, it is unclear whether Bravi automates core operational workflows or integrates with key FSM systems as required by the thesis.

**What would change our mind.**
1. Proof of founder technical depth and real-world domain proximity to home services or field-service software.
2. Demonstrated native integrations with FSM tools (e.g., ServiceTitan, Jobber) that automate core actions like scheduling, dispatch, or billing.
3. Early customer usage data and SMB traction metrics showing recurring retention or active job volume.

**Sources.**
[1] Bravi — YC profile — <https://www.ycombinator.com/companies/bravi>
