# Stormy — Pass (22/100)

stormy.ai · <https://stormy.ai>

>  Stormy runs the office so your crew can run the work. [1]

**Score 22/100** — workflow 20 · team 10 · traction 45 · gtm 20 · moat 15
_Gate: fails the vertical/SMB gate: Provided evidence does not explicitly confirm a dedicated focus on home-services or trades SMBs, only mentioning running the office for 'your crew'.._

**Product.** Stormy positions its product as running office operations for field crews, but specific features, AI capabilities, and system-of-record integrations are not detailed.
- Stormy describes its product as running the office so your crew can run the work. [1]

**Team.** No evidence was provided regarding the founding team, technical backgrounds, or trade domain experience.

**Market.** No target verticals, market segments, or customer business sizes are detailed in the provided evidence.

**Traction.** Stormy has achieved acceptance into Y Combinator's Summer 2025 batch, though no revenue or usage metrics are disclosed.
- Stormy is backed by Y Combinator in the Summer 2025 batch. [1]
- Stormy received 1 point on a Hacker News discussion. [2]

**Why we like it.** Acceptance into Y Combinator's Summer 2025 batch.

**Risks.** Complete lack of detail on product capabilities, FSM integrations, trade vertical focus, and team domain experience.
- Lack of detail on product functionality makes it difficult to verify if the solution provides autonomous workflow execution or integrates with FSM tools.
- Unknown founder backgrounds present execution risk regarding technical depth and trade domain proximity.

**What would change our mind.**
1. Evidence of deep integrations into trade systems of record (e.g., ServiceTitan, Jobber, QuickBooks) that autonomously execute core office tasks.
2. Verification of technical founders with direct domain experience in field services or home-services trade operations.
3. Data showing early customer adoption, revenue, and active usage among 1–50 employee home-service SMBs.

**Sources.**
[1] Stormy — YC profile — <https://www.ycombinator.com/companies/stormy>
[2] news.ycombinator.com — <https://news.ycombinator.com/item?id=44433325>
