# Deal screen — AI receptionists for home services

5 scored candidates, ranked by thesis fit.

| Call | Score | Company | One-liner | Memo |
|---|---:|---|---|---|
| ⚪ Pass | 24 | Cactus | All-In-One AI Growth Partner. Built for Trades. | [memo](memos/oncactus.md) |
| ⚪ Pass | 23 | Cohesive | The agentic CRM for blue-collar services | [memo](memos/cohesive.md) |
| ⚪ Pass | 23 | Feldy | Field-First AI for home services | [memo](memos/feldy.md) |
| ⚪ Pass | 22 | Stormy |  Stormy runs the office so your crew can run the work. | [memo](memos/stormy.md) |
| ⚪ Pass | 21 | Bravi | The AI operating system powering home services businesses | [memo](memos/bravi.md) |

## Unscored (10)

Not evaluated — no recommendation was produced (this is **not** a Pass).

| Company | Reason |
|---|---|
| Kebra | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Bernard | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Maive | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| CentralComs | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Vestris | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Drillbit | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Prox | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Upfront | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Distro | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
| Definite | Gemini rate limit / quota exhausted — retry after the quota resets or use a paid tier. |
