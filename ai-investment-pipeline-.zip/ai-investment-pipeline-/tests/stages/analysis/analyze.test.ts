import { describe, expect, it } from "vitest";
import { Evidence, StartupAnalysis, type StartupCandidate } from "../../../src/domain";
import type { LlmClient, LlmRequest } from "../../../src/infra";
import { analyzeCandidate } from "../../../src/stages/analysis";

const AT = "2026-08-25T00:00:00Z";

const candidate: StartupCandidate = {
  id: "acme",
  name: "Acme",
  website: "https://acme.com",
  description: "AI dispatch for HVAC contractors",
  founders: [],
  sourceRecords: [{ source: "yc", url: "https://www.ycombinator.com/companies/acme", retrievedAt: AT }],
  signals: { batch: "Winter 2025" },
  discoveredAt: AT,
};

const evidence: Evidence[] = [
  Evidence.parse({
    id: "acme-e1",
    startupId: "acme",
    kind: "product",
    snippet: "AI dispatch for HVAC contractors",
    sourceType: "yc",
    sourceUrl: "https://www.ycombinator.com/companies/acme",
    retrievedAt: AT,
  }),
];

/** A fake LLM that returns scripted responses, one per attempt. */
function fakeLlm(responses: string[]): LlmClient & { calls: LlmRequest[] } {
  const calls: LlmRequest[] = [];
  let i = 0;
  return {
    calls,
    async generate(req: LlmRequest): Promise<string> {
      calls.push(req);
      const r = responses[Math.min(i, responses.length - 1)];
      i += 1;
      return r ?? "";
    },
  };
}

const goodBody = {
  team: { summary: "Unknown founders.", facts: [], confidence: "low" },
  product: {
    summary: "Dispatch automation for HVAC.",
    facts: [{ statement: "Does AI dispatch for HVAC contractors.", evidenceIds: ["acme-e1"] }],
    confidence: "medium",
  },
  market: { summary: "Home services.", facts: [], confidence: "low" },
  traction: { summary: "Little public.", facts: [], confidence: "low" },
  risks: ["Incumbents may add AI."],
  unknowns: ["Revenue unknown."],
};

describe("analyzeCandidate — valid output", () => {
  it("accepts valid output, injects startupId, and validates against the schema", async () => {
    const llm = fakeLlm([JSON.stringify(goodBody)]);
    const { analysis, status, attempts } = await analyzeCandidate(candidate, evidence, "thesis", llm);
    expect(status).toBe("ok");
    expect(attempts).toBe(1);
    expect(analysis.startupId).toBe("acme"); // preserved, not model-controlled
    expect(StartupAnalysis.safeParse(analysis).success).toBe(true);
    expect(analysis.product.facts[0]?.evidenceIds).toEqual(["acme-e1"]);
  });

  it("tolerates JSON wrapped in ```json fences", async () => {
    const llm = fakeLlm(["```json\n" + JSON.stringify(goodBody) + "\n```"]);
    const { status } = await analyzeCandidate(candidate, evidence, "thesis", llm);
    expect(status).toBe("ok");
  });
});

describe("analyzeCandidate — invalid / incomplete LLM output", () => {
  it("falls back to explicit-unknown when the output is not valid JSON", async () => {
    const llm = fakeLlm(["this is not json", "still not json", "nope"]);
    const { analysis, status, attempts } = await analyzeCandidate(candidate, evidence, "thesis", llm);
    expect(status).toBe("fallback");
    expect(attempts).toBe(3);
    expect(StartupAnalysis.safeParse(analysis).success).toBe(true);
    expect(analysis.unknowns.length).toBeGreaterThan(0);
    expect(analysis.product.facts).toEqual([]); // nothing invented
  });

  it("rejects incomplete output missing a required section", async () => {
    const { market, ...noMarket } = goodBody;
    void market;
    const llm = fakeLlm([JSON.stringify(noMarket)]);
    const { status } = await analyzeCandidate(candidate, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("fallback");
  });

  it("rejects a fact that cites a non-existent evidence id (no invented citations)", async () => {
    const hallucinated = {
      ...goodBody,
      product: {
        summary: "x",
        facts: [{ statement: "made up", evidenceIds: ["ev-does-not-exist"] }],
        confidence: "medium",
      },
    };
    const llm = fakeLlm([JSON.stringify(hallucinated)]);
    const { status, issues } = await analyzeCandidate(candidate, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("fallback");
    expect(issues.join(" ")).toContain("unknown evidence ids");
  });

  it("rejects a fact with an empty evidenceIds array (schema invariant)", async () => {
    const noRefs = {
      ...goodBody,
      product: { summary: "x", facts: [{ statement: "unsupported", evidenceIds: [] }], confidence: "low" },
    };
    const llm = fakeLlm([JSON.stringify(noRefs)]);
    const { status } = await analyzeCandidate(candidate, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("fallback");
  });

  it("recovers on a later attempt (retry then success)", async () => {
    const llm = fakeLlm(["garbage", JSON.stringify(goodBody)]);
    const { status, attempts } = await analyzeCandidate(candidate, evidence, "thesis", llm, { maxAttempts: 3 });
    expect(status).toBe("ok");
    expect(attempts).toBe(2);
  });

  it("handles the LLM throwing without crashing the stage", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        throw new Error("network down");
      },
    };
    const { status, analysis } = await analyzeCandidate(candidate, evidence, "thesis", llm, { maxAttempts: 2 });
    expect(status).toBe("fallback");
    expect(StartupAnalysis.safeParse(analysis).success).toBe(true);
  });
});
