import { describe, expect, it } from "vitest";
import { Evidence, type StartupCandidate } from "../../../src/domain";
import { buildCandidateEvidence } from "../../../src/stages/analysis";

const AT = "2026-08-25T00:00:00Z";
const YC_URL = "https://www.ycombinator.com/companies/acme";
const HN_URL = "https://news.ycombinator.com/item?id=42";

const base: StartupCandidate = {
  id: "acme",
  name: "Acme",
  website: "https://acme.com",
  description: "AI dispatch for HVAC contractors",
  founders: [],
  sourceRecords: [
    { source: "yc", url: YC_URL, retrievedAt: AT },
    { source: "hn", url: HN_URL, retrievedAt: AT },
  ],
  signals: { batch: "Winter 2025", hnPoints: 42 },
  discoveredAt: AT,
};

describe("buildCandidateEvidence", () => {
  it("derives schema-valid evidence from sourced fields, all tagged with the startup id", () => {
    const ev = buildCandidateEvidence(base);
    expect(ev.length).toBe(3); // description + batch + hn points
    for (const e of ev) {
      expect(Evidence.safeParse(e).success).toBe(true);
      expect(e.startupId).toBe("acme");
    }
  });

  it("preserves real source URLs (traceability, rule #7)", () => {
    const ev = buildCandidateEvidence(base);
    const product = ev.find((e) => e.kind === "product");
    const hn = ev.find((e) => e.sourceType === "hn");
    expect(product?.sourceUrl).toBe(YC_URL);
    expect(hn?.sourceUrl).toBe(HN_URL);
    expect(hn?.snippet).toContain("42 points");
  });

  it("is deterministic — same input yields the same evidence ids", () => {
    const a = buildCandidateEvidence(base).map((e) => e.id);
    const b = buildCandidateEvidence(base).map((e) => e.id);
    expect(a).toEqual(b);
  });

  it("never invents: a bare candidate yields no evidence rather than fabricated facts", () => {
    const bare: StartupCandidate = {
      id: "bare",
      name: "Bare",
      founders: [],
      sourceRecords: [{ source: "yc", url: "https://www.ycombinator.com/companies/bare", retrievedAt: AT }],
      signals: {},
      discoveredAt: AT,
    };
    expect(buildCandidateEvidence(bare)).toEqual([]);
  });
});
