import { describe, expect, it } from "vitest";
import type { StartupCandidate } from "../../../src/domain";
import { canonicalKey, dedupeCandidates } from "../../../src/stages/sourcing";

const AT = "2026-08-25T00:00:00Z";

function candidate(over: Partial<StartupCandidate> & Pick<StartupCandidate, "id" | "name">): StartupCandidate {
  return {
    id: over.id,
    name: over.name,
    founders: over.founders ?? [],
    sourceRecords: over.sourceRecords ?? [
      { source: "yc", url: `https://www.ycombinator.com/companies/${over.id}`, retrievedAt: AT },
    ],
    signals: over.signals ?? {},
    discoveredAt: over.discoveredAt ?? AT,
    ...(over.website ? { website: over.website } : {}),
    ...(over.description ? { description: over.description } : {}),
  };
}

describe("canonicalKey", () => {
  it("keys by website host (ignoring www) when present", () => {
    const a = candidate({ id: "a", name: "Acme", website: "https://www.acme.com" });
    const b = candidate({ id: "b", name: "Acme Inc", website: "https://acme.com/pricing" });
    expect(canonicalKey(a)).toBe(canonicalKey(b));
  });

  it("keys by normalized name when there is no website", () => {
    const a = candidate({ id: "a", name: "Blue Collar AI" });
    const b = candidate({ id: "b", name: "blue-collar ai!" });
    expect(canonicalKey(a)).toBe(canonicalKey(b));
  });
});

describe("dedupeCandidates", () => {
  it("keeps distinct companies separate", () => {
    const list = [
      candidate({ id: "a", name: "Acme", website: "https://acme.com" }),
      candidate({ id: "b", name: "Bravo", website: "https://bravo.com" }),
    ];
    expect(dedupeCandidates(list)).toHaveLength(2);
  });

  it("merges same-domain duplicates and unions their source records", () => {
    const fromYc = candidate({ id: "acme", name: "Acme", website: "https://www.acme.com" });
    const fromHn: StartupCandidate = {
      ...candidate({ id: "acme2", name: "Acme", website: "https://acme.com" }),
      sourceRecords: [{ source: "hn", url: "https://news.ycombinator.com/item?id=999", retrievedAt: AT }],
    };
    const [merged, ...rest] = dedupeCandidates([fromYc, fromHn]);
    expect(rest).toHaveLength(0);
    expect(merged?.sourceRecords.map((r) => r.source).sort()).toEqual(["hn", "yc"]);
  });

  it("fills a missing field from the duplicate (never overwrites present data)", () => {
    const noDesc = candidate({ id: "acme", name: "Acme", website: "https://acme.com" });
    const withDesc = candidate({
      id: "acme2",
      name: "Acme",
      website: "https://acme.com",
      description: "AI dispatch for HVAC",
    });
    const [merged] = dedupeCandidates([noDesc, withDesc]);
    expect(merged?.description).toBe("AI dispatch for HVAC");
  });

  it("dedupes source records by url when merging", () => {
    const same = { source: "yc" as const, url: "https://www.ycombinator.com/companies/acme", retrievedAt: AT };
    const a: StartupCandidate = { ...candidate({ id: "acme", name: "Acme", website: "https://acme.com" }), sourceRecords: [same] };
    const b: StartupCandidate = { ...candidate({ id: "acme2", name: "Acme", website: "https://acme.com" }), sourceRecords: [same] };
    const [merged] = dedupeCandidates([a, b]);
    expect(merged?.sourceRecords).toHaveLength(1);
  });
});
