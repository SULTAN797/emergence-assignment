import { describe, expect, it } from "vitest";
import { StartupCandidate } from "../../../src/domain";
import { extractHnCandidates, hnHitToCandidate } from "../../../src/stages/sourcing";
import type { HnHit, YcCompanyRaw } from "../../../src/stages/sourcing";
import { candidateFromHn } from "../../../src/stages/sourcing/normalize";

const AT = "2026-08-26T00:00:00Z";

const showHnHit: HnHit = {
  objectID: "42",
  title: "Show HN: Cactus – AI growth partner for the trades",
  url: "https://oncactus.com/pricing",
  points: 120,
  created_at: "2026-05-01T00:00:00Z",
};

describe("hnHitToCandidate", () => {
  it("extracts name, website origin, description, and traction from a Show HN post", () => {
    const c = hnHitToCandidate(showHnHit);
    expect(c).toBeDefined();
    expect(c?.name).toBe("Cactus");
    expect(c?.host).toBe("oncactus.com");
    expect(c?.website).toBe("https://oncactus.com"); // origin, path dropped
    expect(c?.description).toContain("AI growth partner");
    expect(c?.points).toBe(120);
    expect(c?.hnItemUrl).toBe("https://news.ycombinator.com/item?id=42");
  });

  it("drops stories with no linked site", () => {
    expect(hnHitToCandidate({ objectID: "1", title: "Ask HN: thoughts?", url: null })).toBeUndefined();
  });

  it("drops non-startup hosts (news / platforms / social)", () => {
    for (const url of ["https://github.com/a/b", "https://techcrunch.com/x", "https://x.com/y"]) {
      expect(hnHitToCandidate({ objectID: "1", title: "X – y", url })).toBeUndefined();
    }
  });

  it("derives a name from the host when the title has no separator", () => {
    const c = hnHitToCandidate({ objectID: "2", title: "just some words", url: "https://acme.io" });
    expect(c?.name).toBe("Acme");
  });
});

describe("extractHnCandidates", () => {
  it("dedupes by host, keeping the highest-points post", () => {
    const low = { ...showHnHit, objectID: "a", points: 10 };
    const high = { ...showHnHit, objectID: "b", points: 300 };
    const out = extractHnCandidates([low, high]);
    expect(out).toHaveLength(1);
    expect(out[0]?.points).toBe(300);
  });
});

describe("candidateFromHn", () => {
  it("builds a schema-valid candidate; never invents founders", () => {
    const hn = hnHitToCandidate(showHnHit)!;
    const c = candidateFromHn(hn, undefined, AT);
    expect(StartupCandidate.safeParse(c).success).toBe(true);
    expect(c.founders).toEqual([]);
    expect(c.signals.hnPoints).toBe(120);
    expect(c.sourceRecords.map((r) => r.source)).toEqual(["hn"]);
  });

  it("enriches with a matched YC company (adds batch + YC source + one-liner)", () => {
    const hn = hnHitToCandidate({ ...showHnHit, title: "Show HN: Cactus", url: "https://oncactus.com" })!;
    const yc: YcCompanyRaw = {
      name: "Cactus",
      slug: "oncactus",
      website: "https://oncactus.com",
      one_liner: "AI growth partner built for the trades",
      batch: "Spring 2025",
      url: "https://www.ycombinator.com/companies/oncactus",
    };
    const c = candidateFromHn(hn, yc, AT);
    expect(c.id).toBe("oncactus"); // prefers stable YC slug
    expect(c.signals.batch).toBe("Spring 2025");
    expect(c.description).toBe("AI growth partner built for the trades"); // filled from YC
    expect(c.sourceRecords.map((r) => r.source).sort()).toEqual(["hn", "yc"]);
  });
});
