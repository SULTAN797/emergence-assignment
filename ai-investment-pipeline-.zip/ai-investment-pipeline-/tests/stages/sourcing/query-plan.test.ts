import { describe, expect, it } from "vitest";
import type { LlmClient } from "../../../src/infra";
import { deterministicDistill, planSearchQuery } from "../../../src/stages/sourcing";

describe("deterministicDistill", () => {
  it("strips generic/stopwords, keeping the distinctive topic", () => {
    const plan = deterministicDistill("AI startup companies helping architects reduce their workload");
    expect(plan.keywords).toContain("architects");
    // generic words are removed
    for (const junk of ["startup", "companies", "helping", "reduce", "workload", "ai"]) {
      expect(plan.keywords).not.toContain(junk);
    }
    expect(plan.hnQuery).toContain("architects");
  });

  it("never returns empty (falls back to the raw query)", () => {
    const plan = deterministicDistill("AI startup company");
    expect(plan.keywords.length).toBeGreaterThan(0);
    expect(plan.hnQuery.length).toBeGreaterThan(0);
  });
});

describe("planSearchQuery", () => {
  it("uses the deterministic distill when no LLM is given", async () => {
    const plan = await planSearchQuery("AI tools for architects", undefined);
    expect(plan.keywords).toContain("architects");
  });

  it("uses the LLM plan when valid", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        return JSON.stringify({ hnQuery: "architects", keywords: ["architecture", "AEC", "BIM"] });
      },
    };
    const plan = await planSearchQuery("AI helping architects reduce workload", llm);
    expect(plan.hnQuery).toBe("architects");
    expect(plan.keywords).toEqual(["architecture", "AEC", "BIM"]);
  });

  it("falls back to distill when the LLM returns junk", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        return "not json at all";
      },
    };
    const plan = await planSearchQuery("AI for architects", llm);
    expect(plan.keywords).toContain("architects"); // deterministic backstop
  });

  it("falls back to distill when the LLM throws (e.g. offline)", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        throw new Error("offline: no cached LLM response for this request");
      },
    };
    const plan = await planSearchQuery("robotics for warehouses", llm);
    expect(plan.keywords.some((k) => k === "robotics" || k === "warehouses")).toBe(true);
  });
});
