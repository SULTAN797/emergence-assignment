import { describe, expect, it } from "vitest";
import type { StartupCandidate } from "../../../src/domain";
import type { LlmClient } from "../../../src/infra";
import { filterRelevant } from "../../../src/stages/sourcing";

const AT = "2026-08-26T00:00:00Z";
const cand = (id: string, name: string, description: string): StartupCandidate => ({
  id,
  name,
  website: `https://${id}.com`,
  description,
  founders: [],
  sourceRecords: [{ source: "hn", url: `https://news.ycombinator.com/item?id=${id}`, retrievedAt: AT }],
  signals: {},
  discoveredAt: AT,
});

const plan = { hnQuery: "architects", keywords: ["architect", "architecture", "AEC", "building design"] };

const pool: StartupCandidate[] = [
  cand("aec1", "BuildAI", "AI for building architects and AEC firms"),
  cand("soundscape", "Yamanote", "A soundscape for Tokyo's train line"),
  cand("fps", "RobloxFPS", "A first-person shooter we built for fun"),
  cand("aec2", "DraftBot", "Generates architecture drawings for design studios"),
];

describe("filterRelevant — deterministic (no LLM)", () => {
  it("keeps keyword-matching candidates and drops the random ones", async () => {
    const out = await filterRelevant(pool, "AI for architects", plan);
    const ids = out.map((c) => c.id).sort();
    expect(ids).toEqual(["aec1", "aec2"]); // soundscape + fps dropped
  });

  it("returns [] when nothing matches — never pads with random", async () => {
    const out = await filterRelevant([pool[1]!, pool[2]!], "AI for architects", plan);
    expect(out).toEqual([]);
  });
});

describe("filterRelevant — LLM (judges intent, not just keywords)", () => {
  it("keeps exactly the ids the model returns", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        return JSON.stringify({ relevantIds: ["aec1"] }); // model deems only aec1 truly on-intent
      },
    };
    const out = await filterRelevant(pool, "AI for building architects", plan, llm);
    expect(out.map((c) => c.id)).toEqual(["aec1"]);
  });

  it("falls back to the deterministic gate when the LLM output is invalid", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        return "not json";
      },
    };
    const out = await filterRelevant(pool, "AI for architects", plan, llm);
    expect(out.map((c) => c.id).sort()).toEqual(["aec1", "aec2"]);
  });
});
