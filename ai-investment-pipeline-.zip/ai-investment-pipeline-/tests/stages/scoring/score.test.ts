import { describe, expect, it } from "vitest";
import { Evidence, Recommendation, type StartupAnalysis, type StartupCandidate } from "../../../src/domain";
import type { LlmClient, LlmRequest } from "../../../src/infra";
import { scoreCandidate } from "../../../src/stages/scoring";

const AT = "2026-08-25T00:00:00Z";

const candidate: StartupCandidate = {
  id: "acme",
  name: "Acme",
  website: "https://acme.com",
  description: "AI dispatch for HVAC contractors",
  founders: [],
  sourceRecords: [{ source: "yc", url: "https://www.ycombinator.com/companies/acme", retrievedAt: AT }],
  signals: { batch: "Winter 2025" },
  discoveredAt: AT,
};

const section = { summary: "s", facts: [], confidence: "low" as const };
const analysis: StartupAnalysis = {
  startupId: "acme",
  team: section,
  product: section,
  market: section,
  traction: section,
  risks: [],
  unknowns: [],
};

const evidence: Evidence[] = [
  Evidence.parse({
    id: "acme-e1",
    startupId: "acme",
    kind: "product",
    snippet: "AI dispatch for HVAC contractors",
    sourceType: "yc",
    sourceUrl: "https://www.ycombinator.com/companies/acme",
    retrievedAt: AT,
  }),
];

function fakeLlm(responses: string[]): LlmClient {
  let i = 0;
  return {
    async generate(_req: LlmRequest): Promise<string> {
      const r = responses[Math.min(i, responses.length - 1)];
      i += 1;
      return r ?? "";
    },
  };
}

const crit = (score: number, evidenceIds: string[] = ["acme-e1"]) => ({
  score,
  explanation: "grounded",
  evidenceIds,
});

const body = (over: Partial<Record<string, unknown>> = {}) => ({
  gates: {
    ventureScale: { pass: true, reason: "large, growing market" },
    earlyStage: { pass: true, reason: "seed-stage, YC 2025" },
  },
  criteria: {
    market: crit(80),
    team: crit(60),
    product: crit(50),
    traction: crit(55),
    moat: crit(40, []), // low → no evidence is allowed
  },
  strongestPositive: "Large market with a clear why-now.",
  biggestRisk: "Undifferentiated versus incumbents.",
  whatWouldChangeOurMind: ["Paid usage numbers", "A defensibility signal"],
  ...over,
});

describe("scoreCandidate — valid output", () => {
  it("computes total + call deterministically and validates the Recommendation", async () => {
    const llm = fakeLlm([JSON.stringify(body())]);
    const { recommendation, status } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm);
    expect(status).toBe("ok");
    expect(recommendation).toBeDefined();
    expect(Recommendation.safeParse(recommendation).success).toBe(true);
    // 0.25*80 + 0.25*60 + 0.20*50 + 0.15*55 + 0.15*40 = 20+15+10+8.25+6 = 59.25 → 59 → PASS
    expect(recommendation?.score).toBe(59);
    expect(recommendation?.recommendation).toBe("PASS");
    expect(recommendation?.strongestPositive).toContain("why-now");
    expect(recommendation?.evidenceIds).toContain("acme-e1");
  });

  it("a failed gate yields PASS with a gateReason", async () => {
    const gated = body({
      gates: {
        ventureScale: { pass: false, reason: "a lifestyle agency, not venture-scale" },
        earlyStage: { pass: true, reason: "ok" },
      },
    });
    const llm = fakeLlm([JSON.stringify(gated)]);
    const { recommendation } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm);
    expect(recommendation?.recommendation).toBe("PASS");
    expect(recommendation?.gateReason).toContain("venture-scale gate");
  });

  it("clears WATCH with strong across-the-board scores", async () => {
    const strong = body({
      criteria: { market: crit(80), team: crit(80), product: crit(70), traction: crit(60), moat: crit(60) },
    });
    // 0.25*80 + 0.25*80 + 0.20*70 + 0.15*60 + 0.15*60 = 20+20+14+9+9 = 72 → WATCH
    const llm = fakeLlm([JSON.stringify(strong)]);
    const { recommendation } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm);
    expect(recommendation?.score).toBe(72);
    expect(recommendation?.recommendation).toBe("WATCH");
  });
});

describe("scoreCandidate — invalid / unsupported output is UNSCORED, never a fabricated PASS", () => {
  it("returns unscored (invalid_output) when the output is not valid JSON", async () => {
    const llm = fakeLlm(["not json", "still not", "nope"]);
    const { status, recommendation, errorKind } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm);
    expect(status).toBe("unscored");
    expect(recommendation).toBeUndefined(); // NOT a Pass
    expect(errorKind).toBe("invalid_output");
  });

  it("rejects an incomplete body (missing a criterion)", async () => {
    const incomplete = body();
    // @ts-expect-error deliberately remove a required criterion
    delete incomplete.criteria.team;
    const llm = fakeLlm([JSON.stringify(incomplete)]);
    const { status } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("unscored");
  });

  it("rejects a fact citing an evidence id that was not provided", async () => {
    const bad = body({ criteria: { ...body().criteria, team: crit(70, ["ev-nope"]) } });
    const llm = fakeLlm([JSON.stringify(bad)]);
    const { status, issues } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("unscored");
    expect(issues.join(" ")).toContain("unknown evidence ids");
  });

  it("rejects an unsupported high score (>40 with no evidence)", async () => {
    const bad = body({ criteria: { ...body().criteria, moat: crit(85, []) } });
    const llm = fakeLlm([JSON.stringify(bad)]);
    const { status, issues } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(status).toBe("unscored");
    expect(issues.join(" ")).toContain("unsupported high scores");
  });

  it("recovers on a later attempt (retry then success)", async () => {
    const llm = fakeLlm(["garbage", JSON.stringify(body())]);
    const { status, attempts } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, { maxAttempts: 3 });
    expect(status).toBe("ok");
    expect(attempts).toBe(2);
  });
});

describe("scoreCandidate — infrastructure errors are unscored with the right kind", () => {
  it("classifies a 429 quota error as rate_limit (not a Pass)", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        throw new Error('{"error":{"code":429,"status":"RESOURCE_EXHAUSTED","message":"quota"}}');
      },
    };
    const { status, recommendation, errorKind } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, {
      maxAttempts: 1,
    });
    expect(status).toBe("unscored");
    expect(recommendation).toBeUndefined();
    expect(errorKind).toBe("rate_limit");
  });

  it("classifies a generic failure as network", async () => {
    const llm: LlmClient = {
      async generate(): Promise<string> {
        throw new Error("socket hang up");
      },
    };
    const { errorKind } = await scoreCandidate(candidate, analysis, evidence, "thesis", llm, { maxAttempts: 1 });
    expect(errorKind).toBe("network");
  });
});
