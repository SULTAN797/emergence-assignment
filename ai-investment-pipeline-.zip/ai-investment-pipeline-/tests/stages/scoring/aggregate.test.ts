import { describe, expect, it } from "vitest";
import { thesisConfig } from "../../../src/config";
import type { CategoryScores } from "../../../src/domain";
import { computeTotal, decideCall } from "../../../src/stages/scoring";

const crit = (score: number) => ({ score, explanation: "x", evidenceIds: ["e1"] });
const scores = (n: {
  market: number;
  team: number;
  product: number;
  traction: number;
  moat: number;
}): CategoryScores => ({
  market: crit(n.market),
  team: crit(n.team),
  product: crit(n.product),
  traction: crit(n.traction),
  moat: crit(n.moat),
});

const { weights, bands } = thesisConfig;

describe("computeTotal (deterministic weighted sum)", () => {
  it("returns 100 when every criterion is 100", () => {
    expect(computeTotal(scores({ market: 100, team: 100, product: 100, traction: 100, moat: 100 }), weights)).toBe(100);
  });

  it("returns 0 when every criterion is 0", () => {
    expect(computeTotal(scores({ market: 0, team: 0, product: 0, traction: 0, moat: 0 }), weights)).toBe(0);
  });

  it("applies the 25/25/20/15/15 weights", () => {
    // only market=100 → 25% weight → 25
    expect(computeTotal(scores({ market: 100, team: 0, product: 0, traction: 0, moat: 0 }), weights)).toBe(25);
    // only moat=100 → 15% weight → 15
    expect(computeTotal(scores({ market: 0, team: 0, product: 0, traction: 0, moat: 100 }), weights)).toBe(15);
  });
});

describe("decideCall (gates -> bands)", () => {
  const bothGates = { ventureScale: true, earlyStage: true };

  it("TAKE_A_MEETING at/above meetingMin", () => {
    expect(decideCall(bothGates, bands.meetingMin, bands).call).toBe("TAKE_A_MEETING");
  });

  it("WATCH between watchMin and meetingMin", () => {
    expect(decideCall(bothGates, bands.watchMin, bands).call).toBe("WATCH");
    expect(decideCall(bothGates, bands.meetingMin - 1, bands).call).toBe("WATCH");
  });

  it("PASS below watchMin", () => {
    expect(decideCall(bothGates, bands.watchMin - 1, bands).call).toBe("PASS");
  });

  it("a failed gate forces PASS regardless of a high score", () => {
    const d = decideCall({ ventureScale: false, earlyStage: true }, 95, bands);
    expect(d.call).toBe("PASS");
    expect(d.reason).toBe("gate");
  });
});
