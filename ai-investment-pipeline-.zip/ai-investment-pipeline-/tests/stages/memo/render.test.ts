import { describe, expect, it } from "vitest";
import { Evidence, type Recommendation, type StartupAnalysis, type StartupCandidate } from "../../../src/domain";
import { renderMemo } from "../../../src/stages/memo";

const AT = "2026-08-25T00:00:00Z";
const YC = "https://www.ycombinator.com/companies/acme";
const HN = "https://news.ycombinator.com/item?id=42";

const candidate: StartupCandidate = {
  id: "acme",
  name: "Acme",
  website: "https://acme.com",
  description: "AI dispatch for HVAC contractors",
  founders: [],
  sourceRecords: [
    { source: "yc", url: YC, retrievedAt: AT },
    { source: "hn", url: HN, retrievedAt: AT },
  ],
  signals: { batch: "Winter 2025", hnPoints: 42 },
  discoveredAt: AT,
};

const ev = (id: string, snippet: string, url: string, sourceType: "yc" | "hn"): Evidence =>
  Evidence.parse({ id, startupId: "acme", kind: "product", snippet, sourceType, sourceUrl: url, retrievedAt: AT });

const evidence: Evidence[] = [
  ev("e1", "AI dispatch for HVAC contractors", YC, "yc"),
  ev("e2", "Integrates with ServiceTitan", YC, "yc"),
  ev("e3", "142 points on Hacker News", HN, "hn"),
];

const analysis: StartupAnalysis = {
  startupId: "acme",
  team: { summary: "Two technical founders.", facts: [{ statement: "Ex-field-service engineers.", evidenceIds: ["e1"] }], confidence: "medium" },
  product: {
    summary: "Automates dispatch inside the FSM.",
    facts: [{ statement: "Writes jobs to ServiceTitan.", evidenceIds: ["e2"] }],
    confidence: "high",
  },
  market: { summary: "Home services is large and fragmented.", facts: [], confidence: "low" },
  traction: { summary: "Early attention.", facts: [{ statement: "142 HN points.", evidenceIds: ["e3"] }], confidence: "low" },
  risks: ["Incumbents may add AI.", "SMB churn is high."],
  unknowns: ["Revenue unknown."],
};

const rec: Recommendation = {
  startupId: "acme",
  gates: { ventureScale: true, earlyStage: true },
  categoryScores: {
    market: { score: 80, explanation: "large market", evidenceIds: ["e2"] },
    team: { score: 60, explanation: "technical", evidenceIds: ["e1"] },
    product: { score: 55, explanation: "differentiated", evidenceIds: [] },
    traction: { score: 50, explanation: "some HN", evidenceIds: ["e3"] },
    moat: { score: 40, explanation: "thin", evidenceIds: [] },
  },
  score: 61,
  recommendation: "WATCH",
  strongestPositive: "Writes jobs directly into ServiceTitan, not just chat.",
  biggestRisk: "Incumbents may add AI.",
  whatWouldChangeOurMind: ["Paid customer count", "A defensibility signal"],
  rationale: "Watch — scored 61/100 against the thesis.",
  evidenceIds: ["e1", "e2", "e3"],
};

describe("renderMemo", () => {
  const memo = renderMemo(candidate, analysis, rec, evidence);

  it("includes every required section", () => {
    for (const needle of ["Acme", "Watch", "61/100", "Product", "Team", "Market", "Traction", "Why we like it", "Risks", "What would change our mind", "Sources"]) {
      expect(memo).toContain(needle);
    }
    // one-sentence thesis (the one-liner) appears as a blockquote
    expect(memo).toContain("> AI dispatch for HVAC contractors");
  });

  it("gives every fact bullet a source reference", () => {
    const factBullets = memo.split("\n").filter((l) => l.startsWith("- ") && !l.startsWith("- ["));
    // fact bullets under sections must end with a [n] citation; risk bullets are not factual claims
    const inSources = memo.indexOf("**Sources.**");
    for (const line of factBullets) {
      if (memo.indexOf(line) > inSources) continue; // skip anything after Sources
      // the fact bullets (product/team/traction) carry citations
    }
    // stronger assertion: each analysis fact statement is followed by a bracketed number
    expect(memo).toMatch(/Writes jobs to ServiceTitan\. \[\d\]/);
    expect(memo).toMatch(/Ex-field-service engineers\. \[\d\]/);
    expect(memo).toMatch(/142 HN points\. \[\d\]/);
  });

  it("numbers sources by unique URL (YC once, HN once)", () => {
    const sourcesBlock = memo.slice(memo.indexOf("**Sources.**"));
    expect(sourcesBlock).toContain("[1]");
    expect(sourcesBlock).toContain("[2]");
    expect(sourcesBlock).not.toContain("[3]"); // only two unique URLs
    expect(sourcesBlock).toContain(YC);
    expect(sourcesBlock).toContain(HN);
  });

  it("shows the score breakdown across the five criteria", () => {
    expect(memo).toContain("market 80");
    expect(memo).toContain("moat 40");
  });

  it("stays concise (a 60-second read, not an essay)", () => {
    expect(memo.length).toBeLessThan(2000);
    expect(memo.split("\n\n").length).toBeLessThan(16);
  });

  it("avoids generic AI marketing language", () => {
    const banned = ["cutting-edge", "revolutionary", "game-chang", "seamlessly", "in today's", "fast-paced", "leverage", "unlock the power"];
    const lower = memo.toLowerCase();
    for (const phrase of banned) expect(lower).not.toContain(phrase);
  });

  it("marks a section with no evidence honestly rather than padding", () => {
    // market has no facts → only the summary line, no fabricated bullets
    const marketLine = memo.split("\n").find((l) => l.startsWith("**Market."));
    expect(marketLine).toContain("Home services is large and fragmented.");
  });
});
