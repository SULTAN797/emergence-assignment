import { describe, expect, it } from "vitest";
import { rateLimitInfo } from "../../src/infra";

describe("rateLimitInfo", () => {
  it("detects a per-day quota cap and its retry delay (won't recover soon)", () => {
    const err = new Error(
      '{"error":{"code":429,"status":"RESOURCE_EXHAUSTED","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"},{"retryDelay":"16s"}]}}',
    );
    const info = rateLimitInfo(err);
    expect(info.is429).toBe(true);
    expect(info.perDay).toBe(true);
    expect(info.delayMs).toBe(16000);
  });

  it("detects a transient per-minute 429 (short backoff, recoverable)", () => {
    const err = new Error('{"error":{"code":429,"message":"per-minute limit","details":[{"retryDelay":"3s"}]}}');
    const info = rateLimitInfo(err);
    expect(info.is429).toBe(true);
    expect(info.perDay).toBe(false);
    expect(info.delayMs).toBe(3000);
  });

  it("reports non-429 errors as not rate-limited", () => {
    expect(rateLimitInfo(new Error("socket hang up")).is429).toBe(false);
  });
});
