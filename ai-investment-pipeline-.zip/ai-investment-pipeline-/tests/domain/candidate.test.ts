import { describe, expect, it } from "vitest";
import { SourceRecord, StartupCandidate } from "../../src/domain";
import { validCandidate, validSourceRecord } from "../fixtures";

describe("StartupCandidate", () => {
  it("accepts a valid candidate", () => {
    expect(StartupCandidate.safeParse(validCandidate).success).toBe(true);
  });

  it("allows empty founders (unknown, not invented)", () => {
    expect(
      StartupCandidate.safeParse({ ...validCandidate, founders: [] }).success,
    ).toBe(true);
  });

  it("requires at least one source record", () => {
    expect(
      StartupCandidate.safeParse({ ...validCandidate, sourceRecords: [] }).success,
    ).toBe(false);
  });

  it("rejects a non-URL website", () => {
    expect(
      StartupCandidate.safeParse({ ...validCandidate, website: "not-a-url" }).success,
    ).toBe(false);
  });

  it("rejects an empty name", () => {
    expect(StartupCandidate.safeParse({ ...validCandidate, name: "" }).success).toBe(false);
  });

  it("rejects hallucinated extra keys (strict)", () => {
    expect(
      StartupCandidate.safeParse({ ...validCandidate, madeUpField: 1 }).success,
    ).toBe(false);
  });
});

describe("SourceRecord", () => {
  it("accepts a valid record and allows omitting cacheKey", () => {
    expect(SourceRecord.safeParse(validSourceRecord).success).toBe(true);
  });

  it("rejects an invalid source type", () => {
    expect(
      SourceRecord.safeParse({ ...validSourceRecord, source: "twitter" }).success,
    ).toBe(false);
  });

  it("rejects a non-ISO retrievedAt", () => {
    expect(
      SourceRecord.safeParse({ ...validSourceRecord, retrievedAt: "yesterday" }).success,
    ).toBe(false);
  });
});
