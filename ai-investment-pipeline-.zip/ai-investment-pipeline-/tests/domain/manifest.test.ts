import { describe, expect, it } from "vitest";
import { RunManifest } from "../../src/domain";
import { validManifest } from "../fixtures";

describe("RunManifest", () => {
  it("accepts a valid manifest", () => {
    expect(RunManifest.safeParse(validManifest).success).toBe(true);
  });

  it("rejects a negative count", () => {
    const bad = { ...validManifest, counts: { ...validManifest.counts, memos: -1 } };
    expect(RunManifest.safeParse(bad).success).toBe(false);
  });

  it("rejects a non-integer count", () => {
    const bad = { ...validManifest, counts: { ...validManifest.counts, candidates: 1.5 } };
    expect(RunManifest.safeParse(bad).success).toBe(false);
  });

  it("rejects a non-ISO createdAt", () => {
    expect(RunManifest.safeParse({ ...validManifest, createdAt: "now" }).success).toBe(false);
  });
});
