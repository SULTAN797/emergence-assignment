import { describe, expect, it } from "vitest";
import { Recommendation } from "../../src/domain";
import { validRecommendation } from "../fixtures";

describe("Recommendation", () => {
  it("accepts a valid recommendation", () => {
    expect(Recommendation.safeParse(validRecommendation).success).toBe(true);
  });

  it("rejects a composite score above 100", () => {
    expect(Recommendation.safeParse({ ...validRecommendation, score: 101 }).success).toBe(
      false,
    );
  });

  it("rejects a non-integer composite score", () => {
    expect(Recommendation.safeParse({ ...validRecommendation, score: 66.5 }).success).toBe(
      false,
    );
  });

  it("rejects a category sub-score out of range", () => {
    const bad = {
      ...validRecommendation,
      categoryScores: {
        ...validRecommendation.categoryScores,
        market: { score: 120, explanation: "x", evidenceIds: [] },
      },
    };
    expect(Recommendation.safeParse(bad).success).toBe(false);
  });

  it("rejects a criterion missing its explanation", () => {
    const bad = {
      ...validRecommendation,
      categoryScores: {
        ...validRecommendation.categoryScores,
        team: { score: 50, evidenceIds: [] },
      },
    };
    expect(Recommendation.safeParse(bad).success).toBe(false);
  });

  it("rejects an invalid recommendation call", () => {
    expect(
      Recommendation.safeParse({ ...validRecommendation, recommendation: "MAYBE" }).success,
    ).toBe(false);
  });

  it("enforces 2–3 'what would change our mind' items", () => {
    const one = { ...validRecommendation, whatWouldChangeOurMind: ["only one"] };
    const four = {
      ...validRecommendation,
      whatWouldChangeOurMind: ["a", "b", "c", "d"],
    };
    const three = { ...validRecommendation, whatWouldChangeOurMind: ["a", "b", "c"] };
    expect(Recommendation.safeParse(one).success).toBe(false);
    expect(Recommendation.safeParse(four).success).toBe(false);
    expect(Recommendation.safeParse(three).success).toBe(true);
  });

  it("requires both gates as booleans", () => {
    const bad = { ...validRecommendation, gates: { ventureScale: true } };
    expect(Recommendation.safeParse(bad).success).toBe(false);
  });
});
