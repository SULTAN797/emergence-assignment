import { describe, expect, it } from "vitest";
import { Evidence } from "../../src/domain";
import { validEvidence } from "../fixtures";

describe("Evidence", () => {
  it("accepts a valid evidence record", () => {
    expect(Evidence.safeParse(validEvidence).success).toBe(true);
  });

  it("rejects an unknown kind", () => {
    expect(Evidence.safeParse({ ...validEvidence, kind: "pricing" }).success).toBe(false);
  });

  it("rejects an empty snippet (a fact must have content)", () => {
    expect(Evidence.safeParse({ ...validEvidence, snippet: "" }).success).toBe(false);
  });

  it("rejects a non-URL sourceUrl", () => {
    expect(Evidence.safeParse({ ...validEvidence, sourceUrl: "x" }).success).toBe(false);
  });

  it("rejects a non-ISO retrievedAt", () => {
    expect(
      Evidence.safeParse({ ...validEvidence, retrievedAt: "2026/08/25" }).success,
    ).toBe(false);
  });

  it("rejects hallucinated extra keys (strict)", () => {
    expect(Evidence.safeParse({ ...validEvidence, confidence: "high" }).success).toBe(false);
  });
});
