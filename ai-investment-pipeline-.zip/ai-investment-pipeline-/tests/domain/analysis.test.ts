import { describe, expect, it } from "vitest";
import { AnalysisSection, FactPoint, StartupAnalysis } from "../../src/domain";
import { validAnalysis } from "../fixtures";

describe("FactPoint", () => {
  it("accepts a fact that cites evidence", () => {
    expect(
      FactPoint.safeParse({ statement: "does X", evidenceIds: ["ev_1"] }).success,
    ).toBe(true);
  });

  it("rejects a fact with no evidence (traceability invariant)", () => {
    expect(
      FactPoint.safeParse({ statement: "does X", evidenceIds: [] }).success,
    ).toBe(false);
  });
});

describe("AnalysisSection", () => {
  it("requires a non-empty summary", () => {
    const bad = { summary: "", facts: [], confidence: "low" };
    expect(AnalysisSection.safeParse(bad).success).toBe(false);
  });

  it("allows an empty facts array (unknown signal)", () => {
    const ok = { summary: "little is public", facts: [], confidence: "low" };
    expect(AnalysisSection.safeParse(ok).success).toBe(true);
  });

  it("rejects an invalid confidence value", () => {
    const bad = { summary: "s", facts: [], confidence: "very-high" };
    expect(AnalysisSection.safeParse(bad).success).toBe(false);
  });
});

describe("StartupAnalysis", () => {
  it("accepts a valid analysis", () => {
    expect(StartupAnalysis.safeParse(validAnalysis).success).toBe(true);
  });

  it("requires all four sections", () => {
    const { market, ...missingMarket } = validAnalysis;
    void market;
    expect(StartupAnalysis.safeParse(missingMarket).success).toBe(false);
  });
});
