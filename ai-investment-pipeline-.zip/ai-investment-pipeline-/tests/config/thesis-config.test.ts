import { describe, expect, it } from "vitest";
import { RubricWeights, ScoreBands, thesisConfig } from "../../src/config";

describe("thesisConfig (mirrors thesis.md v2.0)", () => {
  it("loads with weights summing to 100", () => {
    const w = thesisConfig.weights;
    expect(w.market + w.team + w.product + w.traction + w.moat).toBe(100);
  });

  it("has the sector-agnostic S1–S5 weights and 60/75 bands", () => {
    expect(thesisConfig.weights).toEqual({
      market: 25,
      team: 25,
      product: 20,
      traction: 15,
      moat: 15,
    });
    expect(thesisConfig.bands).toEqual({ watchMin: 60, meetingMin: 75 });
  });
});

describe("RubricWeights", () => {
  it("rejects weights that don't sum to 100", () => {
    const bad = { market: 25, team: 25, product: 20, traction: 15, moat: 25 }; // sums to 110
    expect(RubricWeights.safeParse(bad).success).toBe(false);
  });
});

describe("ScoreBands", () => {
  it("rejects bands where meetingMin does not exceed watchMin", () => {
    expect(ScoreBands.safeParse({ watchMin: 75, meetingMin: 60 }).success).toBe(false);
  });
});
