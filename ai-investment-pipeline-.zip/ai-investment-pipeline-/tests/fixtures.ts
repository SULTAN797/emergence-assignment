import type {
  AnalysisSection,
  Evidence,
  Founder,
  Recommendation,
  RunManifest,
  SourceRecord,
  StartupAnalysis,
  StartupCandidate,
} from "../src/domain";

/** Minimal valid instances of each domain type. Tests clone + mutate these to probe rejection. */

export const validSourceRecord: SourceRecord = {
  source: "yc",
  url: "https://www.ycombinator.com/companies/bravi",
  retrievedAt: "2026-08-25T00:00:00Z",
};

export const validFounder: Founder = {
  name: "Jane Doe",
  evidenceIds: [],
};

export const validCandidate: StartupCandidate = {
  id: "bravi",
  name: "Bravi",
  website: "https://www.bravi.app",
  description: "The AI operating system powering home services businesses",
  founders: [validFounder],
  sourceRecords: [validSourceRecord],
  signals: { batch: "Fall 2025" },
  discoveredAt: "2026-08-25T00:00:00Z",
};

export const validEvidence: Evidence = {
  id: "ev_bravi_1",
  startupId: "bravi",
  kind: "product",
  snippet: "The AI operating system powering home services businesses",
  sourceType: "yc",
  sourceUrl: "https://www.ycombinator.com/companies/bravi",
  retrievedAt: "2026-08-25T00:00:00Z",
};

const section = (): AnalysisSection => ({
  summary: "Technical founders with direct field-service background.",
  facts: [{ statement: "Founded by ex-field-service engineers.", evidenceIds: ["ev_bravi_1"] }],
  confidence: "medium",
});

export const validAnalysis: StartupAnalysis = {
  startupId: "bravi",
  team: section(),
  product: section(),
  market: section(),
  traction: section(),
  risks: ["Incumbents may ship native AI."],
  unknowns: ["Exact revenue is not public."],
};

const crit = (score: number, evidenceIds: string[] = ["ev_bravi_1"]) => ({
  score,
  explanation: "Scored from the available evidence.",
  evidenceIds,
});

export const validRecommendation: Recommendation = {
  startupId: "bravi",
  gates: { ventureScale: true, earlyStage: true },
  categoryScores: {
    market: crit(70),
    team: crit(70),
    product: crit(65),
    traction: crit(55),
    moat: crit(40, []),
  },
  score: 63,
  recommendation: "WATCH",
  strongestPositive: "Large, structurally growing market with a clear why-now.",
  biggestRisk: "Incumbents could copy the wedge before a moat forms.",
  whatWouldChangeOurMind: ["Evidence of paid usage", "A clearer moat"],
  rationale: "WATCH — scored 63/100 against the thesis.",
  evidenceIds: ["ev_bravi_1"],
};

export const validManifest: RunManifest = {
  runId: "home-services-2026-08-25",
  seed: "AI receptionists for home services",
  model: "gemini-pinned-id",
  thesisVersion: "1.1",
  sourceSnapshot: "yc-oss-2026-08-25",
  createdAt: "2026-08-25T00:00:00Z",
  counts: { candidates: 18, analyzed: 15, memos: 15 },
};
