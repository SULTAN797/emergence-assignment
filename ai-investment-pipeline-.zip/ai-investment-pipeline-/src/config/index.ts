/**
 * Config layer — validated configuration values. Pure data, no I/O.
 */
export * from "./model";
export * from "./thesis-config";
