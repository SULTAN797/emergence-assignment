import { z } from "zod";
import { NonEmptyString } from "../domain/common";

/**
 * Configuration models for the scoring rubric (thesis.md §6–§7).
 *
 * This is DATA, not scoring logic — no company is scored here. The scoring stage
 * (a later step) will read `thesisConfig` to compute the weighted composite. Keeping
 * it as a self-validating value means a bad rubric (weights that don't sum to 100,
 * inverted bands) fails loudly at load time.
 */

/** Rubric weights (sector-agnostic S1–S5). Keys mirror `CategoryScores`; must sum to 100. */
export const RubricWeights = z
  .strictObject({
    market: z.number().min(0).max(100),
    team: z.number().min(0).max(100),
    product: z.number().min(0).max(100),
    traction: z.number().min(0).max(100),
    moat: z.number().min(0).max(100),
  })
  .refine((w) => w.market + w.team + w.product + w.traction + w.moat === 100, {
    message: "rubric weights must sum to 100",
  });
export type RubricWeights = z.infer<typeof RubricWeights>;

/** Score band thresholds. `>= meetingMin` => meeting; `>= watchMin` => watch; else pass. */
export const ScoreBands = z
  .strictObject({
    watchMin: z.number().int().min(0).max(100),
    meetingMin: z.number().int().min(0).max(100),
  })
  .refine((b) => b.meetingMin > b.watchMin, {
    message: "meetingMin must exceed watchMin",
  });
export type ScoreBands = z.infer<typeof ScoreBands>;

export const ThesisConfig = z.strictObject({
  version: NonEmptyString,
  weights: RubricWeights,
  bands: ScoreBands,
});
export type ThesisConfig = z.infer<typeof ThesisConfig>;

/**
 * The thesis in prose, for grounding LLM prompts (mirrors thesis.md).
 * Analysis and scoring read this so every stage judges against the same stated thesis.
 *
 * This is a SECTOR-AGNOSTIC framework (not a vertical bet): it is specific about the
 * QUALITIES a great early-stage investment must have, so the score stays meaningful for
 * any query — avoiding the "we back good companies" anti-pattern by naming exact criteria.
 */
export const thesisStatement = `We back early-stage startups (pre-seed to Series A) positioned to become
category-defining businesses. Independent of sector, we require a convergence of five conditions:
(1) MARKET — a large or structurally expanding market with a clear "why now" catalyst (a technology shift,
regulatory change, or behavioral inflection);
(2) TEAM — founders with unique insight, technical capability, and credible domain proximity;
(3) PRODUCT — a differentiated product that resolves an acute, validated customer pain, not a nice-to-have;
(4) TRACTION — early, capital-efficient evidence of real demand and momentum;
(5) MOAT — a durable defensibility mechanism (proprietary data, network effects, high switching costs, or a
distribution advantage) that compounds over time.
We are biased toward product-led businesses attacking structural inefficiencies, and against undifferentiated,
incumbent-imitating, or margin-thin models. A company earns a meeting only when most conditions hold and its
failure modes are understood.`;

/** The concrete, validated rubric — mirrors thesis.md v2.0. Parsed at load; throws if invalid. */
export const thesisConfig: ThesisConfig = ThesisConfig.parse({
  version: "2.0",
  weights: {
    market: 25,
    team: 25,
    product: 20,
    traction: 15,
    moat: 15,
  },
  bands: { watchMin: 60, meetingMin: 75 },
});
