/**
 * Sourcing configuration for the query-driven pipeline.
 *
 * Primary discovery is Hacker News (Algolia search) using the seed QUERY, so pointing the
 * tool at any topic returns candidates for that topic. The YC export is a secondary source:
 * it enriches matched companies (batch/industry) and supplements the list to reach 10–20.
 */
export const sourceConfig = {
  hn: {
    /** Hacker News Algolia search — keyless. `query` drives discovery. */
    searchUrl: "https://hn.algolia.com/api/v1/search",
    hitsPerPage: 100,
  },
  yc: {
    /** yc-oss.github.io export — keyless, updated daily. Enrichment + supplement. */
    apiUrl: "https://yc-oss.github.io/api/companies/all.json",
  },
  /**
   * Hosts that are platforms / news / social / docs — i.e. NOT a startup's own site.
   * HN results linking to these are dropped so we keep company homepages, not articles.
   */
  nonStartupHosts: [
    "github.com",
    "gitlab.com",
    "medium.com",
    "substack.com",
    "youtube.com",
    "youtu.be",
    "twitter.com",
    "x.com",
    "reddit.com",
    "news.ycombinator.com",
    "wikipedia.org",
    "nytimes.com",
    "techcrunch.com",
    "theverge.com",
    "arstechnica.com",
    "bloomberg.com",
    "wsj.com",
    "ft.com",
    "linkedin.com",
    "facebook.com",
    "apple.com",
    "google.com",
    "microsoft.com",
    "amazon.com",
    "wordpress.com",
    "blogspot.com",
    "notion.so",
    "arxiv.org",
    "stackoverflow.com",
    "wired.com",
    "cnbc.com",
    "apnews.com",
    "businessinsider.com",
    "forbes.com",
    "reuters.com",
    "theguardian.com",
    "washingtonpost.com",
    "cnn.com",
    "bbc.com",
    "bbc.co.uk",
    "huggingface.co",
    "kaggle.com",
    "npmjs.com",
    "pypi.org",
    "crates.io",
    "sequoiacap.com",
    "a16z.com",
    "redmonk.com",
    "protocol.com",
    "businesswire.com",
    "prnewswire.com",
    "nature.com",
    "sciencedirect.com",
  ],
} as const;
