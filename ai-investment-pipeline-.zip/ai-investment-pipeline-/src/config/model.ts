/**
 * Default Gemini model. The Gemini API reported that gemini-2.5-flash is retired for new
 * users and directs to this id; confirm the current id from Google's docs if it changes.
 * Override per-run with --model or the GEMINI_MODEL env var.
 */
export const DEFAULT_MODEL = "gemini-3.6-flash";
