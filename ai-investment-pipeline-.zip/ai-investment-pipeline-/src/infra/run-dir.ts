import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";

/** URL/path-safe slug from arbitrary text. */
export function slugify(s: string): string {
  const out = s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  return out.length > 0 ? out : "run";
}

/** Deterministic, human-readable run id: "<seed-slug>-<yyyy-mm-dd>". */
export function makeRunId(seed: string, date: Date): string {
  return `${slugify(seed)}-${date.toISOString().slice(0, 10)}`;
}

export interface RunPaths {
  dir: string;
  candidates: string;
  meta: string;
  rawYc: string;
}

export function runPaths(runsRoot: string, runId: string): RunPaths {
  const dir = join(runsRoot, runId);
  return {
    dir,
    candidates: join(dir, "candidates.json"),
    meta: join(dir, "meta.json"),
    rawYc: join(dir, "raw", "yc-matched.json"),
  };
}

/** Write pretty JSON, creating parent directories as needed. */
export async function writeJson(file: string, value: unknown): Promise<void> {
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

/** Write UTF-8 text, creating parent directories as needed. */
export async function writeText(file: string, content: string): Promise<void> {
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, content, "utf8");
}
