import type { Cache } from "./cache";

/** A cached JSON fetch result, carrying the retrieval time for provenance. */
export interface FetchResult<T> {
  data: T;
  retrievedAt: string; // ISO 8601
  fromCache: boolean;
}

export interface HttpClient {
  getJson<T>(url: string): Promise<FetchResult<T>>;
}

/**
 * HTTP client that reads through the cache. First call fetches and stores the raw
 * response; later calls (and `--offline`) serve from disk. Never invents data — a
 * miss in offline mode throws rather than returning something fabricated.
 */
export function createHttpClient(cache: Cache, opts: { offline?: boolean } = {}): HttpClient {
  const offline = opts.offline ?? false;
  return {
    async getJson<T>(url: string): Promise<FetchResult<T>> {
      const cached = await cache.get<{ data: T; retrievedAt: string }>(url);
      if (cached) return { data: cached.data, retrievedAt: cached.retrievedAt, fromCache: true };
      if (offline) throw new Error(`offline: no cached response for ${url}`);

      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText} for ${url}`);
      const data = (await res.json()) as T;
      const retrievedAt = new Date().toISOString();
      await cache.set(url, { data, retrievedAt });
      return { data, retrievedAt, fromCache: false };
    },
  };
}
