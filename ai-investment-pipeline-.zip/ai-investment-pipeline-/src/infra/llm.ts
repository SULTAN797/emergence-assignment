import { GoogleGenAI } from "@google/genai";
import type { Cache } from "./cache";
import { hashKey } from "./cache";

/**
 * A single structured LLM request. `json: true` asks the model for a JSON response;
 * the caller is still responsible for validating that JSON with Zod (never trust it raw).
 */
export interface LlmRequest {
  system: string;
  prompt: string;
  json?: boolean;
  temperature?: number;
}

/**
 * Provider-agnostic LLM boundary. The pipeline depends on THIS, not on any vendor,
 * so stages can be unit-tested with a fake client and the provider can be swapped.
 */
export interface LlmClient {
  generate(req: LlmRequest): Promise<string>;
}

export type LlmProvider = "gemini" | "groq";

export interface LlmClientOptions {
  apiKey: string;
  model: string;
  cache?: Cache; // when provided, responses are cached for deterministic, offline replay
  offline?: boolean; // cache-only; a miss throws rather than calling the network
  maxRetries?: number; // backoff attempts on a per-minute 429 (default 2)
}

/** Classify a provider error. Distinguishes a per-day quota cap (won't recover soon) from a per-minute limit. */
export function rateLimitInfo(err: unknown): { is429: boolean; perDay: boolean; delayMs: number } {
  const msg = err instanceof Error ? err.message : String(err);
  const is429 = /"code":\s*429|HTTP 429|\b429\b|RESOURCE_EXHAUSTED|Too Many Requests|rate.?limit/i.test(msg);
  const perDay = /PerDay|per day|per-day/i.test(msg);
  const m =
    msg.match(/"retryDelay":\s*"(\d+(?:\.\d+)?)s"/) ?? // Gemini
    msg.match(/try again in (\d+(?:\.\d+)?)\s*s/i) ?? // Groq / OpenAI-style
    msg.match(/retry.?after[":\s]+(\d+(?:\.\d+)?)/i);
  const delayMs = m ? Math.ceil(Number(m[1]) * 1000) : 1000;
  return { is429, perDay, delayMs };
}

const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Wrap a raw provider call with the cross-cutting concerns shared by every provider:
 * content-addressed caching (offline replay), and 429-aware backoff (fast-fail on a per-day cap).
 */
function cached(opts: LlmClientOptions, call: (req: LlmRequest) => Promise<string>): LlmClient {
  return {
    async generate(req: LlmRequest): Promise<string> {
      const cacheKey = `llm:${hashKey(
        JSON.stringify({
          model: opts.model,
          system: req.system,
          prompt: req.prompt,
          json: req.json ?? false,
          temperature: req.temperature ?? 0,
        }),
      )}`;

      if (opts.cache) {
        const hit = await opts.cache.get<{ text: string }>(cacheKey);
        if (hit) return hit.text;
      }
      if (opts.offline) throw new Error("offline: no cached LLM response for this request");

      const maxRetries = opts.maxRetries ?? 4;
      const MAX_DELAY_MS = 60_000;
      let lastErr: unknown;
      for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
        try {
          const text = await call(req);
          if (opts.cache) await opts.cache.set(cacheKey, { text });
          return text;
        } catch (err) {
          lastErr = err;
          const { is429, perDay, delayMs } = rateLimitInfo(err);
          // Back off only on a transient per-minute 429. A per-day cap (or any other error) fails fast.
          if (is429 && !perDay && attempt < maxRetries && delayMs <= MAX_DELAY_MS) {
            await sleep(delayMs);
            continue;
          }
          throw err;
        }
      }
      throw lastErr;
    },
  };
}

/** Gemini-backed LlmClient (Google `@google/genai`). temp defaults to 0 for determinism. */
export function createGeminiClient(opts: LlmClientOptions): LlmClient {
  // Constructed lazily so offline/cache-only runs never touch the SDK (and never warn about a missing key).
  let ai: GoogleGenAI | undefined;
  const client = (): GoogleGenAI => (ai ??= new GoogleGenAI({ apiKey: opts.apiKey }));
  return cached(opts, async (req) => {
    const res = await client().models.generateContent({
      model: opts.model,
      contents: req.prompt,
      config: {
        systemInstruction: req.system,
        temperature: req.temperature ?? 0,
        ...(req.json ? { responseMimeType: "application/json" } : {}),
      },
    });
    return res.text ?? "";
  });
}

/** Groq-backed LlmClient (OpenAI-compatible REST API — no SDK needed). */
export function createGroqClient(opts: LlmClientOptions): LlmClient {
  return cached(opts, async (req) => {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { authorization: `Bearer ${opts.apiKey}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: opts.model,
        temperature: req.temperature ?? 0,
        // No max_tokens: on Groq's free tier the per-request budget counts against an
        // 8k tokens/minute cap, so reserving a large output 413s. The model's default is ample.
        messages: [
          { role: "system", content: req.system },
          { role: "user", content: req.prompt },
        ],
        ...(req.json ? { response_format: { type: "json_object" } } : {}),
      }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`Groq HTTP ${res.status}: ${body.slice(0, 500)}`);
    }
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return data.choices?.[0]?.message?.content ?? "";
  });
}
