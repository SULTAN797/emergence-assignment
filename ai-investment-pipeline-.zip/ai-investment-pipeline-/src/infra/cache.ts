import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";

/**
 * Content-addressed disk cache — the replayability backbone. Every external
 * response is stored under a hash of its key, so re-runs are deterministic and
 * `--offline` can serve from disk. Infrastructure layer: this is where I/O lives.
 */
export interface Cache {
  get<T>(key: string): Promise<T | undefined>;
  set<T>(key: string, value: T): Promise<void>;
}

export function hashKey(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function createDiskCache(root: string): Cache {
  const fileFor = (key: string) => join(root, `${hashKey(key)}.json`);
  return {
    async get<T>(key: string): Promise<T | undefined> {
      try {
        return JSON.parse(await readFile(fileFor(key), "utf8")) as T;
      } catch {
        return undefined; // miss (or unreadable) — treat as absent
      }
    },
    async set<T>(key: string, value: T): Promise<void> {
      const file = fileFor(key);
      await mkdir(dirname(file), { recursive: true });
      await writeFile(file, JSON.stringify(value), "utf8");
    },
  };
}
