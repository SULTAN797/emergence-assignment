import { DEFAULT_MODEL } from "../config/model";
import type { Cache } from "./cache";
import { createGeminiClient, createGroqClient, type LlmClient, type LlmProvider } from "./llm";

/** Provider defaults. Confirm the current id from the provider's docs if a model is retired. */
const GROQ_DEFAULT_MODEL = "openai/gpt-oss-20b";

export interface ResolvedLlm {
  llm: LlmClient;
  provider: LlmProvider;
  model: string;
}

export interface ResolveLlmOptions {
  provider?: string; // explicit override (--provider); else env; else auto
  model?: string;
  offline?: boolean;
  cache?: Cache;
}

/** Pick the provider: explicit flag → LLM_PROVIDER env → auto (Groq if its key is set, else Gemini). */
export function resolveLlmProvider(explicit?: string): LlmProvider {
  const p = (explicit ?? process.env.LLM_PROVIDER ?? "").toLowerCase();
  if (p === "groq" || p === "gemini") return p;
  return process.env.GROQ_API_KEY ? "groq" : "gemini";
}

/** Build the LlmClient from the environment, honoring an explicit provider/model override. */
export function resolveLlmFromEnv(opts: ResolveLlmOptions = {}): ResolvedLlm {
  const offline = opts.offline ?? false;
  const provider = resolveLlmProvider(opts.provider);
  const cacheOpt = opts.cache ? { cache: opts.cache } : {};

  if (provider === "groq") {
    const apiKey = (process.env.GROQ_API_KEY ?? "").trim();
    if (!apiKey && !offline) throw new Error("GROQ_API_KEY is not set. Add it to .env, or use --offline.");
    const model = opts.model ?? process.env.GROQ_MODEL ?? GROQ_DEFAULT_MODEL;
    return { provider, model, llm: createGroqClient({ apiKey, model, offline, ...cacheOpt }) };
  }

  const apiKey = (process.env.GEMINI_API_KEY ?? "").trim();
  if (!apiKey && !offline) throw new Error("GEMINI_API_KEY is not set. Add it to .env, or use --offline.");
  const model = opts.model ?? process.env.GEMINI_MODEL ?? DEFAULT_MODEL;
  return { provider, model, llm: createGeminiClient({ apiKey, model, offline, ...cacheOpt }) };
}
