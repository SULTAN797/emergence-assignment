import { z } from "zod";
import { NonEmptyString } from "./common";

/** The final call. */
export const RecommendationCall = z.enum(["PASS", "WATCH", "TAKE_A_MEETING"]);
export type RecommendationCall = z.infer<typeof RecommendationCall>;

/** Binary thesis gates (scoring-model.md §6). Fail => auto-PASS with a stated reason. */
export const Gates = z.strictObject({
  ventureScale: z.boolean(), // G1 — a venture-scale, category-defining opportunity (not a lifestyle/niche business)
  earlyStage: z.boolean(), // G2 — actually early-stage (pre-seed–Series A), not a mature incumbent
});
export type Gates = z.infer<typeof Gates>;

/**
 * One scored criterion: the number, WHY it got that number (inference), and the
 * evidence it rests on. `evidenceIds` may be [] only when the score is low — a high
 * score with no evidence is an unsupported claim and is rejected in the scoring stage.
 */
export const CriterionScore = z.strictObject({
  score: z.number().min(0).max(100),
  explanation: NonEmptyString,
  evidenceIds: z.array(NonEmptyString),
});
export type CriterionScore = z.infer<typeof CriterionScore>;

/** The 5 scored criteria (sector-agnostic rubric S1–S5). */
export const CategoryScores = z.strictObject({
  market: CriterionScore, // S1 25% — market size/growth + why-now
  team: CriterionScore, // S2 25% — insight, technical depth, domain proximity
  product: CriterionScore, // S3 20% — differentiation, acute pain solved
  traction: CriterionScore, // S4 15% — demand, momentum, capital efficiency
  moat: CriterionScore, // S5 15% — data / network effects / switching costs / distribution
});
export type CategoryScores = z.infer<typeof CategoryScores>;

/** Output of the Scoring stage — the memo's structured backbone. */
export const Recommendation = z.strictObject({
  startupId: NonEmptyString,
  gates: Gates,
  categoryScores: CategoryScores,
  score: z.number().int().min(0).max(100), // DERIVED: weighted sum, rounded (in code)
  recommendation: RecommendationCall, // DERIVED: gates -> guardrail -> bands
  strongestPositive: NonEmptyString, // the single strongest positive signal
  biggestRisk: NonEmptyString, // the single biggest risk
  whatWouldChangeOurMind: NonEmptyString.array().min(2).max(3), // evidence that would flip the call
  rationale: NonEmptyString, // one-line synthesis
  gateReason: NonEmptyString.optional(), // present iff a gate failed (why the auto-PASS)
  evidenceIds: z.array(NonEmptyString), // union of all evidence the scores rest on
});
export type Recommendation = z.infer<typeof Recommendation>;
