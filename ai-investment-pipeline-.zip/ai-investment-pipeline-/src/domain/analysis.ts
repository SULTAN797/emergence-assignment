import { z } from "zod";
import { NonEmptyString } from "./common";

/** Confidence in an inferred conclusion (not in a verbatim fact). */
export const Confidence = z.enum(["high", "medium", "low"]);
export type Confidence = z.infer<typeof Confidence>;

/** A single sourced claim. Must cite >=1 Evidence — a fact with no evidence is not allowed. */
export const FactPoint = z.strictObject({
  statement: NonEmptyString,
  evidenceIds: z.array(NonEmptyString).min(1),
});
export type FactPoint = z.infer<typeof FactPoint>;

/**
 * One dimension of the analysis. Enforces the facts-vs-inference split:
 * `summary` is inference the LLM wrote; `facts` are claims, each linked to Evidence.
 */
export const AnalysisSection = z.strictObject({
  summary: NonEmptyString, // INFERENCE
  facts: z.array(FactPoint), // FACTS (may be [] when the signal is unknown)
  confidence: Confidence,
});
export type AnalysisSection = z.infer<typeof AnalysisSection>;

/** Output of the Analysis stage — structured reasoning over one startup's evidence. */
export const StartupAnalysis = z.strictObject({
  startupId: NonEmptyString,
  team: AnalysisSection,
  product: AnalysisSection,
  market: AnalysisSection,
  traction: AnalysisSection,
  risks: z.array(NonEmptyString), // "what would kill this" — may be []
  unknowns: z.array(NonEmptyString), // signals we could not find — explicit
});
export type StartupAnalysis = z.infer<typeof StartupAnalysis>;
