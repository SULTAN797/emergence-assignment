import { z } from "zod";
import { IsoDateTime, NonEmptyString, SourceType, Url } from "./common";

/** Provenance of where a candidate was discovered / corroborated. */
export const SourceRecord = z.strictObject({
  source: SourceType,
  url: Url, // canonical & citable (YC /companies/<slug>, HN item?id=)
  retrievedAt: IsoDateTime,
  cacheKey: NonEmptyString.optional(), // ref to the committed raw response (offline replay)
});
export type SourceRecord = z.infer<typeof SourceRecord>;

/** A founder. Fields are optional because YC has no founder data — often unknown, never invented. */
export const Founder = z.strictObject({
  name: NonEmptyString,
  role: NonEmptyString.optional(),
  background: NonEmptyString.optional(),
  linkedinUrl: Url.optional(),
  evidenceIds: z.array(NonEmptyString), // may be [] until corroborated
});
export type Founder = z.infer<typeof Founder>;

/**
 * Freshness / traction signals (assignment requires >=1 per candidate). All fields
 * optional so a missing signal is omitted, never invented; the object is always present.
 */
export const CandidateSignals = z.strictObject({
  batch: NonEmptyString.optional(), // YC batch, e.g. "Fall 2024" (freshness)
  launchedAt: IsoDateTime.optional(), // YC launch time (freshness)
  hnPoints: z.number().int().min(0).optional(), // Hacker News points (traction)
});
export type CandidateSignals = z.infer<typeof CandidateSignals>;

/** Output of the Sourcing stage — one discovered startup. */
export const StartupCandidate = z.strictObject({
  id: NonEmptyString, // deterministic slug (e.g. yc slug)
  name: NonEmptyString,
  website: Url.optional(),
  description: NonEmptyString.optional(), // one-liner
  founders: z.array(Founder), // may be [] — unknown, not invented
  sourceRecords: z.array(SourceRecord).min(1), // must come from >=1 source
  signals: CandidateSignals, // >=1 freshness/traction signal (fields may be absent)
  discoveredAt: IsoDateTime,
});
export type StartupCandidate = z.infer<typeof StartupCandidate>;
