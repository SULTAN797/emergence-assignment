import { z } from "zod";
import { IsoDateTime, NonEmptyString } from "./common";

/** One run's provenance — what makes a run replayable and traceable. */
export const RunManifest = z.strictObject({
  runId: NonEmptyString, // deterministic (e.g. "<slug>-<date>")
  seed: NonEmptyString, // the topic/URL/feed input
  model: NonEmptyString, // pinned model id
  thesisVersion: NonEmptyString, // which thesis.md version scored this run
  sourceSnapshot: NonEmptyString, // YC export snapshot id / date
  createdAt: IsoDateTime,
  counts: z.strictObject({
    candidates: z.number().int().min(0),
    analyzed: z.number().int().min(0),
    memos: z.number().int().min(0),
  }),
});
export type RunManifest = z.infer<typeof RunManifest>;
