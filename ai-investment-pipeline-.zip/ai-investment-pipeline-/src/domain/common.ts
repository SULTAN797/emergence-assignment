import { z } from "zod";

/**
 * Shared primitives used across every domain schema.
 *
 * Domain layer rule: this file (and everything in `domain/`) imports ONLY `zod`.
 * No filesystem, no network, no config — pure data-shape definitions.
 */

/** Required text — rejects the empty string so "" can't masquerade as a value. */
export const NonEmptyString = z.string().min(1);

/** ISO-8601 UTC timestamp, e.g. "2026-08-25T00:00:00Z" (what `Date#toISOString()` emits). */
export const IsoDateTime = z.iso.datetime();

/** An absolute URL. */
export const Url = z.url();

/** Where a piece of data came from. YC + HN discover; the website enriches. */
export const SourceType = z.enum(["yc", "hn", "website"]);
export type SourceType = z.infer<typeof SourceType>;
