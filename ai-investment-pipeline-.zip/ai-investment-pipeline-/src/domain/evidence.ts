import { z } from "zod";
import { IsoDateTime, NonEmptyString, SourceType, Url } from "./common";

/** Which analysis dimension a piece of evidence speaks to. */
export const EvidenceKind = z.enum([
  "team",
  "product",
  "market",
  "traction",
  "company",
  "other",
]);
export type EvidenceKind = z.infer<typeof EvidenceKind>;

/**
 * A single sourced FACT (not inference). The `snippet` is verbatim text from the
 * source; provenance (`sourceUrl` + `retrievedAt`) travels with it so any claim
 * in a memo can be traced back. Website text is a self-reported claim (`sourceType`).
 */
export const Evidence = z.strictObject({
  id: NonEmptyString, // deterministic (hash of startupId + sourceUrl + snippet)
  startupId: NonEmptyString,
  kind: EvidenceKind,
  snippet: NonEmptyString, // VERBATIM from the source
  sourceType: SourceType,
  sourceUrl: Url,
  sourceTitle: NonEmptyString.optional(),
  retrievedAt: IsoDateTime, // freezes mutable website content
});
export type Evidence = z.infer<typeof Evidence>;
