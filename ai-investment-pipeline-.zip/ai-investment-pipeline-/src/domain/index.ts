/**
 * Domain layer — the shared data models.
 *
 * Pure Zod schemas + their inferred TypeScript types, one file per stage's output.
 * These are the contracts between pipeline stages; they perform no I/O and depend
 * only on `zod`. Each `Schema`/`Type` pair is co-named (schema is a value, type is a type).
 */
export * from "./common";
export * from "./candidate";
export * from "./evidence";
export * from "./analysis";
export * from "./recommendation";
export * from "./manifest";
