/**
 * AI Investment Pipeline — public surface of the foundation (Step 1).
 *
 * Layering (kept strictly separate — see docs/pipeline-design.md):
 *   domain/  — pure data models (Zod schemas + inferred types). Imports only `zod`. No I/O.
 *   config/  — validated configuration (thesis rubric weights, bands). No I/O.
 *   infra/   — [later step] cache, HTTP, Gemini client, filesystem. The ONLY layer that does I/O.
 *   stages/  — [later step] sourcing → evidence → analysis → scoring → memos.
 *
 * Step 1 delivers domain + config only. No sourcing/analysis/scoring/memo logic yet.
 */
export * from "./domain";
export * from "./config";
