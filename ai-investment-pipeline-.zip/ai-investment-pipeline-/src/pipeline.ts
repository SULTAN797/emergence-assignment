import { createDiskCache, resolveLlmFromEnv } from "./infra";
import { runAnalysis } from "./stages/analysis";
import { runMemos } from "./stages/memo";
import { runScoring } from "./stages/scoring";
import { runSourcing } from "./stages/sourcing";

export interface RunPipelineOptions {
  /** The investment thesis / seed query — the only input. */
  query: string;
  provider?: string; // "groq" | "gemini"; default auto (Groq if its key is set). Keys come from env.
  model?: string;
  limit?: number;
  offline?: boolean; // cache-only, no network / no API calls
  runId?: string;
  runsRoot?: string;
  cacheRoot?: string;
  log?: (message: string) => void;
}

export interface PipelineResult {
  runId: string;
  runDir: string;
  sourced: number;
  analyzed: { ok: number; fallback: number };
  scored: number;
  unscored: number;
  memos: number;
  summaryPath: string;
}

/**
 * The whole pipeline as one call: query in → memos out.
 * Sourcing → Analysis → Scoring → Memos, sharing one run directory and one cache.
 * A thin wrapper over the four stage functions — no new pipeline logic lives here.
 */
export async function runPipeline(opts: RunPipelineOptions): Promise<PipelineResult> {
  const log = opts.log ?? (() => {});
  const offline = opts.offline ?? false;
  const runsRoot = opts.runsRoot ?? "runs";
  const cacheRoot = opts.cacheRoot ?? ".cache/http";

  const cache = createDiskCache(cacheRoot);
  const { llm, provider, model } = resolveLlmFromEnv({
    offline,
    cache,
    ...(opts.provider !== undefined ? { provider: opts.provider } : {}),
    ...(opts.model !== undefined ? { model: opts.model } : {}),
  });
  log(`LLM: ${provider} · ${model}${offline ? " (offline replay)" : ""}`);

  log("① Sourcing…");
  const sourcing = await runSourcing({
    query: opts.query,
    llm,
    offline,
    runsRoot,
    cacheRoot,
    ...(opts.limit !== undefined ? { limit: opts.limit } : {}),
    ...(opts.runId !== undefined ? { runId: opts.runId } : {}),
  });
  const { runDir, runId } = sourcing;
  log(`   query plan → HN "${sourcing.plan.hnQuery}" · keywords [${sourcing.plan.keywords.join(", ")}]`);
  log(`   ${sourcing.counts.final} candidates → ${runDir}`);
  for (const w of sourcing.warnings) log(`   ⚠ ${w}`);

  log("② Analysis…");
  const analysis = await runAnalysis({ runDir, llm });
  log(`   analyzed ${analysis.analyzed} (ok ${analysis.ok}, fallback ${analysis.fallback})`);

  log("③ Scoring…");
  const scoring = await runScoring({ runDir, llm });
  log(`   scored ${scoring.scored}/${scoring.total}, unscored ${scoring.unscored.length}`);

  log("④ Memos…");
  const memos = await runMemos({ runDir, seed: opts.query });
  log(`   wrote ${memos.written} memos + summary.md`);

  return {
    runId,
    runDir,
    sourced: sourcing.counts.final,
    analyzed: { ok: analysis.ok, fallback: analysis.fallback },
    scored: scoring.scored,
    unscored: scoring.unscored.length,
    memos: memos.written,
    summaryPath: `${runDir}/summary.md`,
  };
}
