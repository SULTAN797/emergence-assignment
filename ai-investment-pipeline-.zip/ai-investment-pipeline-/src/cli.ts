import "dotenv/config";
import { parseArgs } from "node:util";
import { runPipeline } from "./pipeline";

/**
 * The one command: query in → memos out.
 *
 *   npm run pipeline -- --query "AI receptionists for home services" [--limit 15]
 *                       [--model <id>] [--offline] [--run-id my-run]
 *
 * Requires GEMINI_API_KEY (in .env) unless --offline (replays the cached run — no API calls).
 */
async function main(): Promise<void> {
  const { values } = parseArgs({
    options: {
      query: { type: "string" },
      limit: { type: "string" },
      provider: { type: "string" },
      model: { type: "string" },
      offline: { type: "boolean" },
      "run-id": { type: "string" },
      "runs-root": { type: "string" },
      "cache-root": { type: "string" },
    },
  });

  if (!values.query) {
    console.error('Usage: npm run pipeline -- --query "<topic or thesis>" [--provider groq|gemini] [--limit 15] [--offline]');
    process.exit(1);
  }

  // Key presence is validated inside the resolver (per provider); --offline needs no key.
  const result = await runPipeline({
    query: values.query,
    offline: Boolean(values.offline),
    log: (m) => console.log(m),
    ...(values.provider ? { provider: values.provider } : {}),
    ...(values.model ? { model: values.model } : {}),
    ...(values.limit ? { limit: Number(values.limit) } : {}),
    ...(values["run-id"] ? { runId: values["run-id"] } : {}),
    ...(values["runs-root"] ? { runsRoot: values["runs-root"] } : {}),
    ...(values["cache-root"] ? { cacheRoot: values["cache-root"] } : {}),
  });

  console.log(`\n✓ Done → ${result.runDir}`);
  console.log(
    `  sourced ${result.sourced} · analyzed ${result.analyzed.ok} · scored ${result.scored} · ` +
      `unscored ${result.unscored} · memos ${result.memos}`,
  );
  console.log(`  Open ${result.summaryPath} for the ranked triage view.`);
}

main().catch((err: unknown) => {
  console.error("Pipeline failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
