import { sourceConfig } from "../../config/source-config";
import type { StartupCandidate } from "../../domain";
import { createDiskCache, createHttpClient, type LlmClient, makeRunId, runPaths, writeJson } from "../../infra";
import { dedupeCandidates } from "./dedupe";
import { extractHnCandidates, searchHn } from "./hn";
import { candidateFromHn, candidateFromYc, candidateHost } from "./normalize";
import { planSearchQuery, type SearchPlan } from "./query-plan";
import { filterRelevant } from "./relevance";
import { clamp } from "./util";
import { indexYcByHost, loadYcCompanies, searchYcByQuery } from "./yc";

export interface SourcingOptions {
  /** The seed query — drives Hacker News discovery. */
  query: string;
  /** When provided, an LLM distills the query into effective search terms before sourcing. */
  llm?: LlmClient;
  limit?: number; // target count (assignment wants 10–20). Default 15, clamped to [1, 20].
  runsRoot?: string;
  cacheRoot?: string;
  offline?: boolean;
  runId?: string;
}

export interface SourcingResult {
  runId: string;
  runDir: string;
  plan: SearchPlan;
  candidates: StartupCandidate[];
  counts: {
    hnHits: number;
    hnCandidates: number;
    ycEnriched: number; // HN candidates matched to a YC company
    ycSupplemented: number; // added from YC to grow the pool
    pool: number; // candidates before the relevance filter
    relevant: number; // candidates the relevance filter kept
    final: number; // after ranking + cap
  };
  warnings: string[];
}

function recencyKey(c: StartupCandidate): number {
  return c.signals.launchedAt ? Date.parse(c.signals.launchedAt) : 0;
}

/**
 * Sourcing stage (query-driven): Hacker News search → extract startups → enrich with YC →
 * supplement from YC to reach the target → normalize → dedupe → persist.
 * Ranks by traction (HN points) first, then recency. Writes candidates.json + raw + meta.
 */
export async function runSourcing(opts: SourcingOptions): Promise<SourcingResult> {
  const now = new Date();
  const runId = opts.runId ?? makeRunId(opts.query, now);
  const runsRoot = opts.runsRoot ?? "runs";
  const cacheRoot = opts.cacheRoot ?? ".cache/http";
  const limit = clamp(opts.limit ?? 15, 1, 20);
  const paths = runPaths(runsRoot, runId);
  const warnings: string[] = [];

  const cache = createDiskCache(cacheRoot);
  const http = createHttpClient(cache, { offline: opts.offline ?? false });

  // 0. Distill the user's request into effective search terms (LLM, with a deterministic fallback).
  const plan = await planSearchQuery(opts.query, opts.llm);

  // 1. Query-driven discovery on Hacker News, using the planned search terms.
  const { hits, retrievedAt } = await searchHn(http, plan.hnQuery);
  const hnCandidates = extractHnCandidates(hits);

  // 2. Load YC and enrich HN candidates by host.
  const { companies } = await loadYcCompanies(http);
  const ycByHost = indexYcByHost(companies);

  let ycEnriched = 0;
  const candidates: StartupCandidate[] = hnCandidates.map((hn) => {
    const yc = ycByHost.get(hn.host);
    if (yc) ycEnriched += 1;
    return candidateFromHn(hn, yc, retrievedAt);
  });

  // 3. Grow the pool with YC keyword matches (so the relevance filter has enough to find `limit`
  //    on-topic companies). Capped, so the filter's input stays bounded.
  const POOL_CAP = Math.max(limit * 3, 45);
  let ycSupplemented = 0;
  {
    const seenHosts = new Set(candidates.map(candidateHost));
    for (const yc of searchYcByQuery(companies, plan.keywords)) {
      if (candidates.length >= POOL_CAP) break;
      const c = candidateFromYc(yc, retrievedAt);
      if (seenHosts.has(candidateHost(c))) continue;
      seenHosts.add(candidateHost(c));
      candidates.push(c);
      ycSupplemented += 1;
    }
  }

  // 4. Dedupe, then keep ONLY relevant candidates (never pad with random ones).
  const deduped = dedupeCandidates(candidates);
  const relevant = await filterRelevant(deduped, opts.query, plan, opts.llm);

  // 5. Rank the relevant set (traction first, then recency) + cap.
  const final = relevant
    .sort((a, b) => {
      const pd = (b.signals.hnPoints ?? -1) - (a.signals.hnPoints ?? -1);
      return pd !== 0 ? pd : recencyKey(b) - recencyKey(a);
    })
    .slice(0, limit);

  if (final.length === 0) {
    warnings.push(`no relevant companies found for "${opts.query}" — try a different or broader query.`);
  } else if (final.length < 10) {
    warnings.push(`only ${final.length} relevant candidates (<10) for "${opts.query}".`);
  }

  // 5. Persist raw + normalized + meta.
  await writeJson(paths.rawYc, { hnHits: hits, query: opts.query });
  await writeJson(paths.candidates, final);
  await writeJson(paths.meta, {
    stage: "sourcing",
    runId,
    seed: opts.query,
    searchPlan: plan,
    generatedAt: now.toISOString(),
    sources: {
      hn: { url: sourceConfig.hn.searchUrl, retrievedAt, hits: hits.length, candidates: hnCandidates.length },
      yc: { url: sourceConfig.yc.apiUrl, enriched: ycEnriched, supplemented: ycSupplemented },
    },
    counts: { pool: deduped.length, relevant: relevant.length, final: final.length },
    note: "Query-driven: HN search (planned query) primary; YC enriches + grows the pool; a relevance filter keeps only on-topic companies — no padding.",
    warnings,
  });

  return {
    runId,
    runDir: paths.dir,
    plan,
    candidates: final,
    counts: {
      hnHits: hits.length,
      hnCandidates: hnCandidates.length,
      ycEnriched,
      ycSupplemented,
      pool: deduped.length,
      relevant: relevant.length,
      final: final.length,
    },
    warnings,
  };
}
