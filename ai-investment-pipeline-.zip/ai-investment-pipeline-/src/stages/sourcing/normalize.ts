import { StartupCandidate, type SourceRecord } from "../../domain";
import { slugify } from "../../infra";
import type { HnCandidate } from "./hn";
import { compact, hostOf, isHttpUrl } from "./util";
import type { YcCompanyRaw } from "./yc";

function ycUrl(yc: YcCompanyRaw): string {
  return yc.url && isHttpUrl(yc.url) ? yc.url : `https://www.ycombinator.com/companies/${yc.slug}`;
}

function launchedAtIso(unixSeconds: number | null | undefined): string | undefined {
  return typeof unixSeconds === "number" && unixSeconds > 0
    ? new Date(unixSeconds * 1000).toISOString()
    : undefined;
}

/**
 * Build a candidate from an HN story, enriched with a matched YC company when available.
 * HN supplies name/website/traction; YC (if matched) adds batch + a one-liner + provenance.
 * Missing fields are omitted, never invented.
 */
export function candidateFromHn(hn: HnCandidate, yc: YcCompanyRaw | undefined, retrievedAt: string): StartupCandidate {
  const sourceRecords: SourceRecord[] = [{ source: "hn", url: hn.hnItemUrl, retrievedAt }];
  if (yc) sourceRecords.push({ source: "yc", url: ycUrl(yc), retrievedAt });

  const candidate = compact({
    id: yc?.slug ?? slugify(hn.host),
    name: hn.name,
    website: hn.website,
    description: hn.description ?? yc?.one_liner ?? undefined,
    founders: [],
    sourceRecords,
    signals: compact({
      batch: yc?.batch || undefined,
      launchedAt: launchedAtIso(yc?.launched_at) ?? hn.createdAt,
      hnPoints: hn.points,
    }),
    discoveredAt: retrievedAt,
  });
  return StartupCandidate.parse(candidate);
}

/** Build a candidate directly from a YC company (used only for query supplements). */
export function candidateFromYc(yc: YcCompanyRaw, retrievedAt: string): StartupCandidate {
  const website = yc.website && isHttpUrl(yc.website) ? yc.website : undefined;
  const candidate = compact({
    id: yc.slug,
    name: yc.name,
    website,
    description: yc.one_liner || undefined,
    founders: [],
    sourceRecords: [{ source: "yc" as const, url: ycUrl(yc), retrievedAt }],
    signals: compact({ batch: yc.batch || undefined, launchedAt: launchedAtIso(yc.launched_at) }),
    discoveredAt: retrievedAt,
  });
  return StartupCandidate.parse(candidate);
}

/** Host used for identity/dedupe (website host, else the slugged name). */
export function candidateHost(c: StartupCandidate): string {
  return (c.website && hostOf(c.website)) || `name:${slugify(c.name)}`;
}
