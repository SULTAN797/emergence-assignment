import { sourceConfig } from "../../config/source-config";
import type { HttpClient } from "../../infra";
import { hostOf } from "./util";

/** The subset of the YC OSS export fields we read. */
export interface YcCompanyRaw {
  name: string;
  slug: string;
  website?: string;
  one_liner?: string;
  long_description?: string;
  batch?: string;
  industry?: string;
  subindustry?: string;
  industries?: string[];
  tags?: string[];
  launched_at?: number | null; // unix seconds
  url?: string; // YC canonical page
}

type Cfg = typeof sourceConfig;

/** Load the YC export (cached). Used to enrich HN matches and to supplement the list. */
export async function loadYcCompanies(
  http: HttpClient,
  cfg: Cfg = sourceConfig,
): Promise<{ companies: YcCompanyRaw[]; retrievedAt: string }> {
  const { data, retrievedAt } = await http.getJson<YcCompanyRaw[]>(cfg.yc.apiUrl);
  return { companies: data ?? [], retrievedAt };
}

/** Index YC companies by website host, for enriching HN candidates. First writer wins. */
export function indexYcByHost(companies: YcCompanyRaw[]): Map<string, YcCompanyRaw> {
  const byHost = new Map<string, YcCompanyRaw>();
  for (const c of companies) {
    if (!c.website) continue;
    const h = hostOf(c.website);
    if (h && !byHost.has(h)) byHost.set(h, c);
  }
  return byHost;
}

/**
 * Supplement discovery: find YC companies matching the plan's DISTINCTIVE keywords (topic terms +
 * synonyms), ranked by how many they hit. Keywords are pre-distilled (no generic words), so matches
 * are on-topic rather than on filler like "companies"/"helping". Used to top up when HN yields too few.
 */
export function searchYcByQuery(companies: YcCompanyRaw[], keywords: string[]): YcCompanyRaw[] {
  const kws = [...new Set(keywords.map((k) => k.toLowerCase().trim()).filter((k) => k.length > 2))];
  if (kws.length === 0) return [];
  const scored: { company: YcCompanyRaw; score: number }[] = [];
  for (const c of companies) {
    const blob = [c.name, c.one_liner, c.long_description, c.industry, c.subindustry, ...(c.tags ?? [])]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    const score = kws.filter((k) => blob.includes(k)).length;
    if (score > 0) scored.push({ company: c, score });
  }
  return scored.sort((a, b) => b.score - a.score).map((s) => s.company);
}
