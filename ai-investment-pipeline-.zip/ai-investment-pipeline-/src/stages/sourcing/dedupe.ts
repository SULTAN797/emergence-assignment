import { StartupCandidate } from "../../domain";
import { compact, hostOf } from "./util";

/**
 * Canonical identity key for a company: website host if present (most reliable),
 * else a normalized name. Two records with the same key are the same company.
 */
export function canonicalKey(c: StartupCandidate): string {
  if (c.website) {
    const host = hostOf(c.website);
    if (host) return `domain:${host}`;
  }
  return `name:${c.name.toLowerCase().replace(/[^a-z0-9]/g, "")}`;
}

function dedupeBy<T>(items: T[], keyOf: (t: T) => string): T[] {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of items) {
    const k = keyOf(item);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(item);
  }
  return out;
}

/** Merge two records for the same company: union provenance, fill missing fields from either. */
function mergeCandidates(a: StartupCandidate, b: StartupCandidate): StartupCandidate {
  const merged = compact({
    id: a.id,
    name: a.name,
    website: a.website ?? b.website,
    description: a.description ?? b.description,
    founders: dedupeBy([...a.founders, ...b.founders], (f) => f.name.toLowerCase()),
    sourceRecords: dedupeBy([...a.sourceRecords, ...b.sourceRecords], (r) => r.url),
    signals: compact({
      batch: a.signals.batch ?? b.signals.batch,
      launchedAt: a.signals.launchedAt ?? b.signals.launchedAt,
      hnPoints: a.signals.hnPoints ?? b.signals.hnPoints,
    }),
    discoveredAt: a.discoveredAt,
  });
  return StartupCandidate.parse(merged);
}

/**
 * Deduplicate a list of candidates by canonical identity, merging duplicates.
 * Order is preserved by first appearance. Pure function — unit-tested in isolation.
 */
export function dedupeCandidates(candidates: StartupCandidate[]): StartupCandidate[] {
  const byKey = new Map<string, StartupCandidate>();
  for (const c of candidates) {
    const key = canonicalKey(c);
    const existing = byKey.get(key);
    byKey.set(key, existing ? mergeCandidates(existing, c) : c);
  }
  return [...byKey.values()];
}
