import { z } from "zod";
import type { StartupCandidate } from "../../domain";
import type { LlmClient } from "../../infra";
import type { SearchPlan } from "./query-plan";

const RelevanceResult = z.object({ relevantIds: z.array(z.string()) });

const SYSTEM = `You filter a list of startups for relevance to a user's request.
Keep ONLY startups that genuinely match the user's intent — the specific domain AND use case they described.
Drop anything off-topic, in the wrong domain (even if it shares a keyword), or clearly unrelated.
If none are relevant, return an empty list. Return ONLY JSON: {"relevantIds": string[]} — the ids to KEEP.`;

function parseJson(raw: string): unknown {
  const cleaned = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    return undefined;
  }
}

/** Ask the LLM which candidates genuinely match the user's intent. Returns undefined on invalid output. */
async function llmRelevant(
  candidates: StartupCandidate[],
  userQuery: string,
  llm: LlmClient,
): Promise<StartupCandidate[] | undefined> {
  const listing = candidates
    .map((c) => `- id="${c.id}" ${c.name}: ${c.description ?? "(no description)"}`)
    .join("\n");
  const prompt = `User request: ${userQuery}\n\nStartups:\n${listing}\n\nReturn the ids of the ones genuinely relevant to the request.`;
  const parsed = RelevanceResult.safeParse(parseJson(await llm.generate({ system: SYSTEM, prompt, json: true })));
  if (!parsed.success) return undefined;
  const keep = new Set(parsed.data.relevantIds);
  return candidates.filter((c) => keep.has(c.id));
}

/** Deterministic backstop: keep candidates whose name/description contains a distinctive keyword. */
function deterministicRelevant(candidates: StartupCandidate[], keywords: string[]): StartupCandidate[] {
  const kws = keywords.map((k) => k.toLowerCase().trim()).filter((k) => k.length > 2);
  if (kws.length === 0) return candidates;
  return candidates.filter((c) => {
    const blob = `${c.name} ${c.description ?? ""}`.toLowerCase();
    return kws.some((k) => blob.includes(k));
  });
}

/**
 * Keep only candidates relevant to the user's request. Uses the LLM (judges intent, not just
 * keywords) when available; otherwise a deterministic keyword gate. Either way, an irrelevant
 * candidate is DROPPED rather than padded in — better to return few (or none) than random ones.
 */
export async function filterRelevant(
  candidates: StartupCandidate[],
  userQuery: string,
  plan: SearchPlan,
  llm?: LlmClient,
): Promise<StartupCandidate[]> {
  if (candidates.length === 0) return [];
  if (llm) {
    try {
      const relevant = await llmRelevant(candidates, userQuery, llm);
      if (relevant) return relevant;
    } catch {
      // fall through to the deterministic backstop
    }
  }
  return deterministicRelevant(candidates, plan.keywords);
}
