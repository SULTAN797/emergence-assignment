import { z } from "zod";
import { NonEmptyString } from "../../domain";
import type { LlmClient } from "../../infra";

/** The search terms to actually use, derived from the user's natural-language request. */
export const SearchPlan = z.strictObject({
  hnQuery: NonEmptyString, // concise terms for the HN Show HN search
  keywords: z.array(NonEmptyString).min(1), // distinctive terms (+ synonyms) for matching YC companies
});
export type SearchPlan = z.infer<typeof SearchPlan>;

/** Generic words that don't narrow a startup search — stripped in the deterministic fallback. */
const STOPWORDS = new Set([
  "the", "a", "an", "for", "to", "of", "and", "or", "in", "on", "with", "that", "this", "their", "them",
  "they", "who", "how", "what", "which", "using", "use", "uses", "based", "help", "helps", "helping",
  "reduce", "reducing", "improve", "improving", "workload", "work", "startup", "startups", "company",
  "companies", "business", "businesses", "platform", "platforms", "tool", "tools", "software", "solution",
  "solutions", "app", "apps", "product", "products", "service", "services", "ai", "ml", "llm", "tech",
  "technology", "new", "best", "top", "find", "building", "build", "make", "making", "get", "enable",
  "enabling", "powered", "driven", "automate", "automating", "automation", "system", "systems", "their",
]);

/** Deterministic backstop: strip stopwords, keep distinctive tokens. Used when no LLM is available. */
export function deterministicDistill(userQuery: string): SearchPlan {
  const tokens = [
    ...new Set(userQuery.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 2 && !STOPWORDS.has(t))),
  ];
  const keywords = tokens.length > 0 ? tokens : [userQuery.trim()];
  const hnQuery = tokens.slice(0, 4).join(" ") || userQuery.trim();
  return { hnQuery, keywords };
}

const SYSTEM = `You convert a user's startup/company-search request into search terms optimized for finding relevant companies on Hacker News, especially "Show HN" posts.

Your goal is to preserve the user's CORE SEARCH INTENT, not merely extract the most distinctive noun.

Return JSON with:
- "hnQuery": 1–4 words representing the CORE CONCEPT or COMBINATION of concepts being searched for.
- "keywords": 4–8 distinctive search terms including the core concept, close synonyms, related terminology, and adjacent industry terms that relevant startups may use.

IMPORTANT RULES:

1. Preserve the user's intent-defining concepts.
   If the request combines multiple meaningful concepts, KEEP THEM TOGETHER.
   Example:
   "AI startups for healthcare" → "AI healthcare"
   NOT → "healthcare"

2. Do NOT remove terms simply because they are broad.
   Terms such as "AI", "machine learning", "fintech", "healthcare", "cybersecurity", "developer tools", "robotics", etc. can be essential to the search intent.

3. Remove only truly generic business words that do not define the domain:
   "startup", "company", "help", "reduce", "workload", "platform", "tool", "software", "solution", "application", "service".

4. Identify the semantic relationship between concepts.
   Examples:
   - "AI for healthcare" → "AI healthcare"
   - "AI helping lawyers" → "AI legal"
   - "AI for cybersecurity" → "AI cybersecurity"
   - "blockchain for payments" → "blockchain payments"
   - "developer tools using AI" → "AI developer tools"
   - "robotics for warehouses" → "warehouse robotics"
   - "fintech for small businesses" → "SMB fintech"

5. For "keywords", include:
   - the primary technology/domain
   - the target industry/domain
   - close synonyms
   - abbreviations
   - adjacent terminology
   - terminology a startup/founder might actually use in its product description

6. Do not add unrelated concepts merely to increase keyword count.

7. Prefer specific combinations over isolated generic terms.

Examples:

User: "AI startups for healthcare"
{
  "hnQuery": "AI healthcare",
  "keywords": ["AI", "artificial intelligence", "machine learning", "healthcare", "healthtech", "digital health", "medical AI"]
}

User: "AI helping architects"
{
  "hnQuery": "AI architecture",
  "keywords": ["AI", "artificial intelligence", "architecture", "architect", "AEC", "BIM", "building design"]
}

User: "cybersecurity startups for developers"
{
  "hnQuery": "developer cybersecurity",
  "keywords": ["cybersecurity", "application security", "AppSec", "developer security", "DevSecOps", "software security", "cloud security"]
}

User: "AI tools for financial institutions"
{
  "hnQuery": "AI fintech",
  "keywords": ["AI", "artificial intelligence", "machine learning", "fintech", "financial services", "banking", "financial technology"]
}

User: "robotics for warehouse automation"
{
  "hnQuery": "warehouse robotics",
  "keywords": ["robotics", "warehouse automation", "industrial robotics", "logistics automation", "fulfillment", "AMR", "autonomous robots"]
}

Output ONLY the JSON object.`;

function parseJson(raw: string): unknown {
  const cleaned = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    return undefined;
  }
}

/**
 * Plan the search terms for a user query. Uses the LLM when available (it adds synonyms /
 * adjacent terms the keyword approach would miss), and falls back to a deterministic distill
 * if there's no LLM or the model returns nothing valid — so sourcing never breaks.
 */
export async function planSearchQuery(userQuery: string, llm?: LlmClient): Promise<SearchPlan> {
  if (!llm) return deterministicDistill(userQuery);
  try {
    const raw = await llm.generate({ system: SYSTEM, prompt: `Request: ${userQuery}`, json: true, temperature: 0 });
    const parsed = SearchPlan.safeParse(parseJson(raw));
    if (parsed.success) return parsed.data;
  } catch {
    // fall through to the deterministic backstop
  }
  return deterministicDistill(userQuery);
}
