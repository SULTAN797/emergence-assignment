/**
 * Sourcing stage — query-driven discovery from Hacker News (primary) enriched and
 * supplemented by the YC export, normalized into `StartupCandidate`, deduped, ranked.
 * No analysis/scoring/memo logic here.
 */
export { runSourcing } from "./sourcing";
export type { SourcingOptions, SourcingResult } from "./sourcing";
export { searchHn, extractHnCandidates, hnHitToCandidate } from "./hn";
export type { HnHit, HnCandidate } from "./hn";
export { loadYcCompanies, indexYcByHost, searchYcByQuery } from "./yc";
export type { YcCompanyRaw } from "./yc";
export { candidateFromHn, candidateFromYc, candidateHost } from "./normalize";
export { planSearchQuery, deterministicDistill } from "./query-plan";
export type { SearchPlan } from "./query-plan";
export { filterRelevant } from "./relevance";
export { dedupeCandidates, canonicalKey } from "./dedupe";
