import { sourceConfig } from "../../config/source-config";
import type { HttpClient } from "../../infra";
import { hostOf, originOf } from "./util";

export interface HnHit {
  objectID: string;
  title?: string;
  url?: string | null;
  points?: number | null;
  num_comments?: number | null;
  author?: string;
  created_at?: string;
}
interface HnSearchResponse {
  hits?: HnHit[];
}

/** A startup candidate extracted from one HN story. */
export interface HnCandidate {
  name: string;
  host: string;
  website: string;
  description?: string;
  points?: number; // HN points → traction signal
  hnItemUrl: string;
  createdAt?: string; // ISO
}

type Cfg = typeof sourceConfig;

/**
 * Query-driven discovery: search Hacker News SHOW HN posts for the seed query.
 * Show HN posts are makers launching their own product, so precision (actual startups,
 * not news/discussion) is far higher than a general story search.
 */
export async function searchHn(
  http: HttpClient,
  query: string,
  cfg: Cfg = sourceConfig,
): Promise<{ hits: HnHit[]; retrievedAt: string }> {
  const url = `${cfg.hn.searchUrl}?query=${encodeURIComponent(query)}&tags=show_hn&hitsPerPage=${cfg.hn.hitsPerPage}`;
  const { data, retrievedAt } = await http.getJson<HnSearchResponse>(url);
  return { hits: data.hits ?? [], retrievedAt };
}

/** Academic / government hosts are never startups. */
function isInstitutionalHost(host: string): boolean {
  return /\.(edu|gov|mil)$/.test(host) || /\.(ac|edu|gov)\.[a-z.]+$/.test(host);
}

/** Pull a plausible company name + description out of an HN title. */
function parseTitle(title: string, host: string): { name: string; description?: string } {
  const t = title.trim().replace(/^show\s+hn:\s*/i, "").replace(/^ask\s+hn:\s*/i, "").trim();
  // "Name – tagline" / "Name — tagline" / "Name: tagline"
  const m = t.match(/^(.{2,40}?)\s*[–—:-]\s*(.+)$/);
  if (m?.[1] && m[2]) return { name: m[1].trim(), description: m[2].trim() };
  // Short, name-like title (≤2 words) → treat as the company name, no description.
  const words = t.split(/\s+/).filter(Boolean);
  if (t.length > 0 && words.length <= 2 && t.length <= 30) return { name: t };
  // Otherwise it's a headline → derive a name from the host, keep the title as description.
  const sld = host.split(".").slice(-2, -1)[0] ?? host;
  const name = sld.charAt(0).toUpperCase() + sld.slice(1);
  return { name, ...(t ? { description: t } : {}) };
}

/**
 * Turn an HN story into a startup candidate, or undefined if it isn't startup-like
 * (no linked site, or the link is a news/platform/social host rather than a company).
 */
export function hnHitToCandidate(hit: HnHit, cfg: Cfg = sourceConfig): HnCandidate | undefined {
  if (!hit.url) return undefined;
  const host = hostOf(hit.url);
  const website = originOf(hit.url);
  if (!host || !website) return undefined;
  if (isInstitutionalHost(host)) return undefined;
  if (cfg.nonStartupHosts.some((h) => host === h || host.endsWith(`.${h}`))) return undefined;

  const { name, description } = parseTitle(hit.title ?? host, host);
  return {
    name,
    host,
    website,
    ...(description ? { description } : {}),
    ...(typeof hit.points === "number" && hit.points >= 0 ? { points: hit.points } : {}),
    hnItemUrl: `https://news.ycombinator.com/item?id=${hit.objectID}`,
    ...(hit.created_at ? { createdAt: hit.created_at } : {}),
  };
}

/** Extract + dedupe HN candidates by host, keeping the highest-points post per company. */
export function extractHnCandidates(hits: HnHit[], cfg: Cfg = sourceConfig): HnCandidate[] {
  const byHost = new Map<string, HnCandidate>();
  for (const hit of hits) {
    const c = hnHitToCandidate(hit, cfg);
    if (!c) continue;
    const existing = byHost.get(c.host);
    if (!existing || (c.points ?? -1) > (existing.points ?? -1)) byHost.set(c.host, c);
  }
  return [...byHost.values()];
}
