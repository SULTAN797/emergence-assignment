import "dotenv/config";
import { parseArgs } from "node:util";
import { createDiskCache, resolveLlmFromEnv } from "../../infra";
import { runSourcing } from "./sourcing";

/**
 * Independently runnable Sourcing stage.
 *
 *   npm run source -- --query "AI agents for developer tooling" [--limit 15] [--offline] [--run-id my-run]
 */
async function main(): Promise<void> {
  const { values } = parseArgs({
    options: {
      query: { type: "string" },
      limit: { type: "string" },
      offline: { type: "boolean" },
      "run-id": { type: "string" },
      "runs-root": { type: "string" },
      "cache-root": { type: "string" },
    },
  });

  if (!values.query) {
    console.error('Usage: npm run source -- --query "<topic or thesis>" [--limit 15] [--offline]');
    process.exit(1);
  }

  // Build an LLM for query planning if a key is available; otherwise fall back to deterministic distill.
  const offline = Boolean(values.offline);
  let llm;
  try {
    llm = resolveLlmFromEnv({ offline, cache: createDiskCache(values["cache-root"] ?? ".cache/http") }).llm;
  } catch {
    llm = undefined; // no key → planSearchQuery uses the deterministic backstop
  }

  const result = await runSourcing({
    query: values.query,
    ...(llm ? { llm } : {}),
    ...(values.limit ? { limit: Number(values.limit) } : {}),
    ...(values["run-id"] ? { runId: values["run-id"] } : {}),
    ...(values["runs-root"] ? { runsRoot: values["runs-root"] } : {}),
    ...(values["cache-root"] ? { cacheRoot: values["cache-root"] } : {}),
    offline,
  });

  const { counts } = result;
  console.log(`\nSourcing complete → ${result.runDir}`);
  console.log(`  query plan → HN "${result.plan.hnQuery}" · keywords [${result.plan.keywords.join(", ")}]`);
  console.log(
    `  HN hits: ${counts.hnHits} | HN candidates: ${counts.hnCandidates} | ` +
      `pool: ${counts.pool} | relevant: ${counts.relevant} | final: ${counts.final}`,
  );
  console.log(`  candidates.json + raw/ + meta.json written.`);
  for (const w of result.warnings) console.warn(`  ⚠ ${w}`);
}

main().catch((err: unknown) => {
  console.error("Sourcing failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
