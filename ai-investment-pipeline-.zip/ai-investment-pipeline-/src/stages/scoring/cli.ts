import "dotenv/config";
import { parseArgs } from "node:util";
import { join } from "node:path";
import { createDiskCache, resolveLlmFromEnv } from "../../infra";
import { runScoring } from "./scoring";

/**
 * Independently runnable Scoring stage.
 *
 *   npm run score -- --run-id <run-id> [--provider groq|gemini] [--model <id>] [--offline]
 *
 * Requires the provider's API key (in .env) unless --offline.
 */
async function main(): Promise<void> {
  const { values } = parseArgs({
    options: {
      "run-id": { type: "string" },
      "run-dir": { type: "string" },
      "runs-root": { type: "string" },
      "cache-root": { type: "string" },
      provider: { type: "string" },
      model: { type: "string" },
      offline: { type: "boolean" },
    },
  });

  const runsRoot = values["runs-root"] ?? "runs";
  const runDir = values["run-dir"] ?? (values["run-id"] ? join(runsRoot, values["run-id"]) : undefined);
  if (!runDir) {
    console.error("Usage: npm run score -- --run-id <run-id> [--provider groq|gemini] [--offline]");
    process.exit(1);
  }

  const cache = createDiskCache(values["cache-root"] ?? ".cache/http");
  const { llm } = resolveLlmFromEnv({
    offline: Boolean(values.offline),
    cache,
    ...(values.provider ? { provider: values.provider } : {}),
    ...(values.model ? { model: values.model } : {}),
  });

  const result = await runScoring({ runDir, llm });

  console.log(`\nScoring complete → ${runDir}/recommendations.json`);
  console.log(
    `  scored: ${result.scored}/${result.total} | ` +
      `TAKE_A_MEETING: ${result.byCall.TAKE_A_MEETING} | WATCH: ${result.byCall.WATCH} | PASS: ${result.byCall.PASS}`,
  );
  if (result.unscored.length > 0) {
    const byKind = result.unscored.reduce<Record<string, number>>((acc, u) => {
      acc[u.errorKind] = (acc[u.errorKind] ?? 0) + 1;
      return acc;
    }, {});
    console.warn(`  unscored: ${result.unscored.length} (${Object.entries(byKind).map(([k, n]) => `${k}: ${n}`).join(", ")})`);
    if (byKind.rate_limit) console.warn("  ↳ rate-limited — re-run once the quota resets (analysis is cached) or use a paid tier.");
  }
}

main().catch((err: unknown) => {
  console.error("Scoring failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
