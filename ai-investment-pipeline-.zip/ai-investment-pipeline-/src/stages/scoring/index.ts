/**
 * Scoring / Recommendation stage — score a candidate's analysis against the rubric
 * (scoring-model.md), aggregate deterministically, and emit a validated Recommendation
 * with PASS / WATCH / TAKE_A_MEETING. No memo rendering here.
 */
export { scoreCandidate } from "./score";
export type { ScoreOptions, ScoreResult, UnscoredReason } from "./score";
export { runScoring } from "./scoring";
export type { RunScoringOptions, ScoringRunResult, UnscoredEntry } from "./scoring";
export { computeTotal, decideCall } from "./aggregate";
export type { CallDecision } from "./aggregate";
export { buildScoringRequest } from "./prompt";
export {
  ScoringBody,
  invalidEvidenceRefs,
  unsupportedHighScores,
  referencedEvidenceIds,
  UNSUPPORTED_SCORE_CEILING,
} from "./schema";
