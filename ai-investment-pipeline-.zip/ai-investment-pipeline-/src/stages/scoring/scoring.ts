import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { thesisStatement } from "../../config/thesis-config";
import { Evidence, type Recommendation, StartupAnalysis, StartupCandidate } from "../../domain";
import { type LlmClient, writeJson } from "../../infra";
import { scoreCandidate, type UnscoredReason } from "./score";

export interface RunScoringOptions {
  runDir: string;
  llm: LlmClient;
  thesis?: string;
  maxAttempts?: number;
}

export interface UnscoredEntry {
  startupId: string;
  errorKind: UnscoredReason;
  reason: string;
}

export interface ScoringRunResult {
  total: number;
  scored: number; // produced a real Recommendation
  unscored: UnscoredEntry[]; // could not be scored — NOT counted as PASS
  byCall: Record<Recommendation["recommendation"], number>;
}

async function readJsonIfExists<T>(file: string): Promise<T | undefined> {
  try {
    return JSON.parse(await readFile(file, "utf8")) as T;
  } catch {
    return undefined;
  }
}

/**
 * Scoring stage: for each candidate, score its analysis+evidence against the rubric and
 * emit a validated Recommendation. Per-item isolation. Writes runs/<id>/recommendations.json
 * (ranked by score, highest first).
 */
export async function runScoring(opts: RunScoringOptions): Promise<ScoringRunResult> {
  const thesis = opts.thesis ?? thesisStatement;
  const rawCandidates = await readJsonIfExists<unknown>(join(opts.runDir, "candidates.json"));
  if (rawCandidates === undefined) throw new Error(`no candidates.json in ${opts.runDir} — run sourcing first`);
  const candidates = StartupCandidate.array().parse(rawCandidates);

  const recommendations: Recommendation[] = [];
  const unscored: UnscoredEntry[] = [];
  const byCall: Record<Recommendation["recommendation"], number> = { PASS: 0, WATCH: 0, TAKE_A_MEETING: 0 };

  for (const candidate of candidates) {
    try {
      const analysisRaw = await readJsonIfExists<unknown>(join(opts.runDir, "analysis", `${candidate.id}.json`));
      if (analysisRaw === undefined) throw new Error("analysis missing — run analysis first");
      const analysis = StartupAnalysis.parse(analysisRaw);

      const evidenceRaw = await readJsonIfExists<unknown>(join(opts.runDir, "evidence", `${candidate.id}.json`));
      const evidence = evidenceRaw !== undefined ? Evidence.array().parse(evidenceRaw) : [];

      const res = await scoreCandidate(candidate, analysis, evidence, thesis, opts.llm, {
        ...(opts.maxAttempts !== undefined ? { maxAttempts: opts.maxAttempts } : {}),
      });
      if (res.status === "ok" && res.recommendation) {
        recommendations.push(res.recommendation);
        byCall[res.recommendation.recommendation] += 1;
      } else {
        unscored.push({
          startupId: candidate.id,
          errorKind: res.errorKind ?? "invalid_output",
          reason: res.reason ?? "could not be scored",
        });
      }
    } catch (err) {
      // Missing analysis or an unexpected failure — unscored, never a fabricated PASS.
      unscored.push({
        startupId: candidate.id,
        errorKind: "invalid_output",
        reason: err instanceof Error ? err.message : String(err),
      });
    }
  }

  recommendations.sort((a, b) => b.score - a.score);
  await writeJson(join(opts.runDir, "recommendations.json"), recommendations);
  await writeJson(join(opts.runDir, "unscored.json"), unscored);

  return { total: candidates.length, scored: recommendations.length, unscored, byCall };
}
