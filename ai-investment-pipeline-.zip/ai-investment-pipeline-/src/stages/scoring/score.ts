import type { z } from "zod";
import { type ThesisConfig, thesisConfig } from "../../config/thesis-config";
import { type Evidence, Recommendation, type StartupAnalysis, type StartupCandidate } from "../../domain";
import { type LlmClient, rateLimitInfo } from "../../infra";
import { type CallDecision, computeTotal, decideCall } from "./aggregate";
import { buildScoringRequest } from "./prompt";
import { invalidEvidenceRefs, referencedEvidenceIds, ScoringBody, unsupportedHighScores } from "./schema";

export interface ScoreOptions {
  maxAttempts?: number; // default 3
  config?: ThesisConfig; // default: thesisConfig
}

/** Why a candidate could not be scored — kept distinct from any judgment (never a fabricated PASS). */
export type UnscoredReason = "rate_limit" | "network" | "invalid_output";

export interface ScoreResult {
  status: "ok" | "unscored";
  recommendation?: Recommendation; // present iff status === "ok"
  errorKind?: UnscoredReason; // present iff status === "unscored"
  reason?: string; // human-readable explanation for an unscored result
  attempts: number;
  issues: string[];
}

const UNSCORED_REASON: Record<UnscoredReason, string> = {
  rate_limit: "LLM rate limit / quota exhausted — retry after the limit resets or use a higher tier.",
  network: "The LLM request failed (network or API error).",
  invalid_output: "The model did not return valid, evidence-grounded output after retries.",
};

function classifyLlmError(err: unknown): "rate_limit" | "network" {
  return rateLimitInfo(err).is429 ? "rate_limit" : "network";
}

function parseJson(raw: string): unknown {
  const cleaned = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    return undefined;
  }
}

function firstIssues(error: z.ZodError): string {
  return error.issues.slice(0, 3).map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`).join("; ");
}

function callLabel(call: Recommendation["recommendation"]): string {
  return call === "TAKE_A_MEETING" ? "Take a meeting" : call === "WATCH" ? "Watch" : "Pass";
}

function composeRationale(decision: CallDecision, total: number, gateReason?: string): string {
  if (decision.reason === "gate") return `Auto-Pass — ${gateReason ?? "failed a thesis gate"}.`;
  return `${callLabel(decision.call)} — scored ${total}/100 against the thesis.`;
}

/** Compose the validated LLM body + deterministic aggregation into a schema-valid Recommendation. */
function compose(startupId: string, body: ScoringBody, config: ThesisConfig): Recommendation {
  const gates = { ventureScale: body.gates.ventureScale.pass, earlyStage: body.gates.earlyStage.pass };
  const total = computeTotal(body.criteria, config.weights);
  const decision = decideCall(gates, total, config.bands);

  const gateReason =
    decision.reason === "gate"
      ? !gates.ventureScale
        ? `fails the venture-scale gate: ${body.gates.ventureScale.reason}`
        : `fails the early-stage gate: ${body.gates.earlyStage.reason}`
      : undefined;

  return Recommendation.parse({
    startupId,
    gates,
    categoryScores: body.criteria,
    score: total,
    recommendation: decision.call,
    strongestPositive: body.strongestPositive,
    biggestRisk: body.biggestRisk,
    whatWouldChangeOurMind: body.whatWouldChangeOurMind,
    rationale: composeRationale(decision, total, gateReason),
    ...(gateReason ? { gateReason } : {}),
    evidenceIds: referencedEvidenceIds(body),
  });
}

/**
 * Score one candidate. LLM is injected (testable with a fake). Each attempt must:
 *   parse JSON -> validate schema -> cite only provided evidence -> no unsupported high scores.
 * The total and call are computed deterministically from the validated body. If no attempt
 * yields valid output, returns status "unscored" with the cause — NEVER a fabricated PASS, so an
 * infrastructure failure (e.g. a rate limit) can't masquerade as an evaluated recommendation.
 */
export async function scoreCandidate(
  candidate: StartupCandidate,
  analysis: StartupAnalysis,
  evidence: Evidence[],
  thesis: string,
  llm: LlmClient,
  opts: ScoreOptions = {},
): Promise<ScoreResult> {
  const config = opts.config ?? thesisConfig;
  const req = buildScoringRequest(candidate, analysis, evidence, thesis);
  const maxAttempts = Math.max(1, opts.maxAttempts ?? 3);
  const issues: string[] = [];
  let errorKind: UnscoredReason = "invalid_output";

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    let raw: string;
    try {
      raw = await llm.generate(req);
    } catch (err) {
      errorKind = classifyLlmError(err);
      issues.push(`attempt ${attempt}: LLM error: ${err instanceof Error ? err.message : String(err)}`);
      continue;
    }

    const json = parseJson(raw);
    if (json === undefined) {
      errorKind = "invalid_output";
      issues.push(`attempt ${attempt}: response was not valid JSON`);
      continue;
    }

    const parsed = ScoringBody.safeParse(json);
    if (!parsed.success) {
      errorKind = "invalid_output";
      issues.push(`attempt ${attempt}: schema validation failed: ${firstIssues(parsed.error)}`);
      continue;
    }

    const badRefs = invalidEvidenceRefs(parsed.data, evidence);
    if (badRefs.length > 0) {
      errorKind = "invalid_output";
      issues.push(`attempt ${attempt}: cited unknown evidence ids: ${badRefs.join(", ")}`);
      continue;
    }

    const unsupported = unsupportedHighScores(parsed.data);
    if (unsupported.length > 0) {
      errorKind = "invalid_output";
      issues.push(`attempt ${attempt}: unsupported high scores (no evidence): ${unsupported.join(", ")}`);
      continue;
    }

    return { status: "ok", recommendation: compose(candidate.id, parsed.data, config), attempts: attempt, issues };
  }

  return { status: "unscored", errorKind, reason: UNSCORED_REASON[errorKind], attempts: maxAttempts, issues };
}
