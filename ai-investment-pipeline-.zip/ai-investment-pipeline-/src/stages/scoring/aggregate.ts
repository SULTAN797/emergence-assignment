import type { RubricWeights, ScoreBands } from "../../config/thesis-config";
import type { CategoryScores, Gates, RecommendationCall } from "../../domain";

/**
 * Deterministic weighted total, rounded to an integer 0–100.
 * total = round( Σ (weightᵢ/100 · scoreᵢ) ). This is CODE, not the model — reproducible.
 */
export function computeTotal(criteria: CategoryScores, weights: RubricWeights): number {
  const weighted =
    weights.market * criteria.market.score +
    weights.team * criteria.team.score +
    weights.product * criteria.product.score +
    weights.traction * criteria.traction.score +
    weights.moat * criteria.moat.score;
  return Math.round(weighted / 100);
}

export interface CallDecision {
  call: RecommendationCall;
  reason: "gate" | "band";
}

/** Deterministic call: gates first (fail => PASS), then the score bands. */
export function decideCall(gates: Gates, total: number, bands: ScoreBands): CallDecision {
  if (!gates.ventureScale || !gates.earlyStage) return { call: "PASS", reason: "gate" };
  if (total >= bands.meetingMin) return { call: "TAKE_A_MEETING", reason: "band" };
  if (total >= bands.watchMin) return { call: "WATCH", reason: "band" };
  return { call: "PASS", reason: "band" };
}
