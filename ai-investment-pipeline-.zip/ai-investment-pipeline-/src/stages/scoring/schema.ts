import { z } from "zod";
import { CategoryScores, type Evidence, NonEmptyString } from "../../domain";

/** A gate verdict from the LLM: pass/fail with a grounded reason. */
export const GateAssessment = z.strictObject({
  pass: z.boolean(),
  reason: NonEmptyString,
});

/**
 * What the LLM produces. It fills gates + the five criteria (score/explanation/evidence)
 * + the qualitative fields. It does NOT compute the total or the call — those are derived
 * deterministically in code (aggregate.ts), which is what makes the numbers reproducible.
 */
export const ScoringBody = z.strictObject({
  gates: z.strictObject({
    ventureScale: GateAssessment,
    earlyStage: GateAssessment,
  }),
  criteria: CategoryScores,
  strongestPositive: NonEmptyString,
  biggestRisk: NonEmptyString,
  whatWouldChangeOurMind: NonEmptyString.array().min(2).max(3),
});
export type ScoringBody = z.infer<typeof ScoringBody>;

/** A criterion may exceed this only if it cites evidence — above it with none = unsupported claim. */
export const UNSUPPORTED_SCORE_CEILING = 40;

const CRITERIA_KEYS = ["market", "team", "product", "traction", "moat"] as const;

export function referencedEvidenceIds(body: ScoringBody): string[] {
  const ids = new Set<string>();
  for (const key of CRITERIA_KEYS) for (const id of body.criteria[key].evidenceIds) ids.add(id);
  return [...ids];
}

/** Cited evidence ids that were not in the provided evidence (rule: no fabricated citations). */
export function invalidEvidenceRefs(body: ScoringBody, evidence: Evidence[]): string[] {
  const known = new Set(evidence.map((e) => e.id));
  return referencedEvidenceIds(body).filter((id) => !known.has(id));
}

/** Criteria scored above the ceiling with NO evidence — unsupported claims (rejected). */
export function unsupportedHighScores(body: ScoringBody, ceiling = UNSUPPORTED_SCORE_CEILING): string[] {
  return CRITERIA_KEYS.filter(
    (key) => body.criteria[key].evidenceIds.length === 0 && body.criteria[key].score > ceiling,
  );
}
