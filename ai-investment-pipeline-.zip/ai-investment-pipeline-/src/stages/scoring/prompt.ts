import type { Evidence, StartupAnalysis, StartupCandidate } from "../../domain";
import type { LlmRequest } from "../../infra";
import { UNSUPPORTED_SCORE_CEILING } from "./schema";

const SYSTEM = `You are a partner at a seed-stage VC firm scoring one startup against the firm's thesis rubric.

Hard rules — follow exactly:
1. Score ONLY from the provided analysis and evidence. Do not use outside knowledge.
2. Every criterion score above ${UNSUPPORTED_SCORE_CEILING} MUST cite at least one evidenceId from the
   provided evidence list. If the evidence is thin, score low and cite nothing — never inflate a score.
3. Never cite an evidenceId that is not in the provided list.
4. Do NOT compute the total or the final call — those are computed downstream. You only fill the fields below.
5. Output ONLY a single JSON object in the requested shape. No prose outside the JSON.`;

const RUBRIC = `GATES (binary — pass/fail with a one-line reason):
- ventureScale: a venture-scale, potentially category-defining opportunity (not a lifestyle business, agency, or tiny niche).
- earlyStage: genuinely early-stage (pre-seed to Series A), not a mature incumbent or public company.

SCORED CRITERIA (0–100 each; higher = stronger):
- market: size / structural growth of the market and a clear "why now" catalyst (tech shift, regulation, behavior change).
- team: founder insight, technical capability, and credible domain proximity.
- product: differentiation and whether it resolves an acute, validated customer pain (not a nice-to-have).
- traction: real demand and momentum — usage, revenue, growth, attention — and capital efficiency.
- moat: durable defensibility — proprietary data, network effects, high switching costs, or a distribution advantage.`;

function evidenceBlock(evidence: Evidence[]): string {
  if (evidence.length === 0) return "(no evidence provided)";
  return evidence.map((e) => `- id="${e.id}" [${e.kind}] "${e.snippet}" <${e.sourceUrl}>`).join("\n");
}

function analysisBlock(a: StartupAnalysis): string {
  const section = (name: string, s: { summary: string; confidence: string }) =>
    `${name} (${s.confidence}): ${s.summary}`;
  return [
    section("team", a.team),
    section("product", a.product),
    section("market", a.market),
    section("traction", a.traction),
    `risks: ${a.risks.join("; ") || "(none listed)"}`,
    `unknowns: ${a.unknowns.join("; ") || "(none listed)"}`,
  ].join("\n");
}

const SHAPE = `{
  "gates": {
    "ventureScale": { "pass": boolean, "reason": string },
    "earlyStage":   { "pass": boolean, "reason": string }
  },
  "criteria": {
    "market":   { "score": 0-100, "explanation": string, "evidenceIds": string[] },
    "team":     { "score": 0-100, "explanation": string, "evidenceIds": string[] },
    "product":  { "score": 0-100, "explanation": string, "evidenceIds": string[] },
    "traction": { "score": 0-100, "explanation": string, "evidenceIds": string[] },
    "moat":     { "score": 0-100, "explanation": string, "evidenceIds": string[] }
  },
  "strongestPositive": string,
  "biggestRisk": string,
  "whatWouldChangeOurMind": string[]   // 2 or 3 items
}`;

/** Build the scoring request for one candidate. Deterministic (no timestamps / randomness). */
export function buildScoringRequest(
  candidate: StartupCandidate,
  analysis: StartupAnalysis,
  evidence: Evidence[],
  thesis: string,
): LlmRequest {
  const prompt = `THESIS:
${thesis}

RUBRIC:
${RUBRIC}

STARTUP: ${candidate.name} — ${candidate.description ?? "(no one-liner)"} <${candidate.website ?? "no website"}>

ANALYSIS:
${analysisBlock(analysis)}

EVIDENCE (cite these ids only):
${evidenceBlock(evidence)}

TASK: Assess the two gates; score the five criteria with an explanation and supporting evidence for each;
name the single strongest positive signal and the single biggest risk; and list the 2–3 pieces of evidence
that would change the recommendation.

Return ONLY a JSON object with this exact shape:
${SHAPE}`;

  return { system: SYSTEM, prompt, json: true, temperature: 0 };
}
