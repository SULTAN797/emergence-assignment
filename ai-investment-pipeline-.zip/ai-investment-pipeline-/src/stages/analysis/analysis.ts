import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { thesisStatement } from "../../config/thesis-config";
import { Evidence, StartupCandidate, type StartupAnalysis } from "../../domain";
import { type LlmClient, writeJson } from "../../infra";
import { analyzeCandidate, fallbackAnalysis } from "./analyze";
import { buildCandidateEvidence } from "./evidence";

export interface RunAnalysisOptions {
  runDir: string; // the sourcing run directory (contains candidates.json)
  llm: LlmClient;
  thesis?: string; // default: the firm thesis
  maxAttempts?: number;
}

export interface AnalysisRunResult {
  analyzed: number;
  ok: number;
  fallback: number;
  perStartup: { id: string; status: "ok" | "fallback" | "error"; note?: string }[];
}

async function readJsonIfExists<T>(file: string): Promise<T | undefined> {
  try {
    return JSON.parse(await readFile(file, "utf8")) as T;
  } catch {
    return undefined;
  }
}

/** Load committed evidence for a candidate if the Evidence stage produced it; else derive it. */
async function loadOrBuildEvidence(runDir: string, candidate: StartupCandidate): Promise<Evidence[]> {
  const existing = await readJsonIfExists<unknown>(join(runDir, "evidence", `${candidate.id}.json`));
  if (existing !== undefined) {
    const parsed = Evidence.array().safeParse(existing);
    if (parsed.success) return parsed.data;
  }
  return buildCandidateEvidence(candidate);
}

/**
 * Analysis stage: for each candidate, gather evidence, produce a validated StartupAnalysis,
 * and persist it. Per-item isolation — one startup failing never aborts the batch.
 * Writes: runs/<id>/evidence/<cid>.json (the evidence used) and analysis/<cid>.json.
 */
export async function runAnalysis(opts: RunAnalysisOptions): Promise<AnalysisRunResult> {
  const thesis = opts.thesis ?? thesisStatement;
  const rawCandidates = await readJsonIfExists<unknown>(join(opts.runDir, "candidates.json"));
  if (rawCandidates === undefined) throw new Error(`no candidates.json in ${opts.runDir} — run sourcing first`);
  const candidates = StartupCandidate.array().parse(rawCandidates);

  const result: AnalysisRunResult = { analyzed: 0, ok: 0, fallback: 0, perStartup: [] };

  for (const candidate of candidates) {
    result.analyzed += 1;
    try {
      const evidence = await loadOrBuildEvidence(opts.runDir, candidate);
      await writeJson(join(opts.runDir, "evidence", `${candidate.id}.json`), evidence);

      const { analysis, status, issues } = await analyzeCandidate(candidate, evidence, thesis, opts.llm, {
        ...(opts.maxAttempts !== undefined ? { maxAttempts: opts.maxAttempts } : {}),
      });
      await writeJson(join(opts.runDir, "analysis", `${candidate.id}.json`), analysis);

      if (status === "ok") result.ok += 1;
      else result.fallback += 1;
      result.perStartup.push({
        id: candidate.id,
        status,
        ...(status === "fallback" ? { note: issues.at(-1) ?? "LLM output never validated" } : {}),
      });
    } catch (err) {
      // Unexpected failure for this candidate — still persist an explicit-unknown analysis and continue.
      const analysis: StartupAnalysis = fallbackAnalysis(candidate.id);
      await writeJson(join(opts.runDir, "analysis", `${candidate.id}.json`), analysis).catch(() => {});
      result.fallback += 1;
      result.perStartup.push({
        id: candidate.id,
        status: "error",
        note: err instanceof Error ? err.message : String(err),
      });
    }
  }

  return result;
}
