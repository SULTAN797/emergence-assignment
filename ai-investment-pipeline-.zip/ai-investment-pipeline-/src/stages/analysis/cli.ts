import "dotenv/config";
import { parseArgs } from "node:util";
import { join } from "node:path";
import { createDiskCache, resolveLlmFromEnv } from "../../infra";
import { runAnalysis } from "./analysis";

/**
 * Independently runnable Analysis stage.
 *
 *   npm run analyze -- --run-id <sourcing-run-id> [--provider groq|gemini] [--model <id>] [--offline]
 *
 * Requires the provider's API key (in .env) unless --offline (replays cached responses).
 */
async function main(): Promise<void> {
  const { values } = parseArgs({
    options: {
      "run-id": { type: "string" },
      "run-dir": { type: "string" },
      "runs-root": { type: "string" },
      "cache-root": { type: "string" },
      provider: { type: "string" },
      model: { type: "string" },
      offline: { type: "boolean" },
    },
  });

  const runsRoot = values["runs-root"] ?? "runs";
  const runDir = values["run-dir"] ?? (values["run-id"] ? join(runsRoot, values["run-id"]) : undefined);
  if (!runDir) {
    console.error("Usage: npm run analyze -- --run-id <sourcing-run-id> [--provider groq|gemini] [--offline]");
    process.exit(1);
  }

  const cache = createDiskCache(values["cache-root"] ?? ".cache/http");
  const { llm } = resolveLlmFromEnv({
    offline: Boolean(values.offline),
    cache,
    ...(values.provider ? { provider: values.provider } : {}),
    ...(values.model ? { model: values.model } : {}),
  });

  const result = await runAnalysis({ runDir, llm });

  console.log(`\nAnalysis complete → ${runDir}/analysis/`);
  console.log(`  analyzed: ${result.analyzed} | ok: ${result.ok} | fallback/unknown: ${result.fallback}`);
  for (const s of result.perStartup) {
    if (s.status !== "ok") console.warn(`  ⚠ ${s.id}: ${s.status}${s.note ? ` — ${s.note}` : ""}`);
  }
}

main().catch((err: unknown) => {
  console.error("Analysis failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
