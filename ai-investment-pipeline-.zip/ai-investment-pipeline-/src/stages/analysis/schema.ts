import { z } from "zod";
import { AnalysisSection, type Evidence, type StartupAnalysis } from "../../domain";

/**
 * What the LLM is asked to produce: the analysis body WITHOUT `startupId`. We inject
 * `startupId` ourselves so the model can't change identity — rule #7 (preserve source IDs).
 */
export const AnalysisBody = z.strictObject({
  team: AnalysisSection,
  product: AnalysisSection,
  market: AnalysisSection,
  traction: AnalysisSection,
  risks: z.array(z.string().min(1)),
  unknowns: z.array(z.string().min(1)),
});
export type AnalysisBody = z.infer<typeof AnalysisBody>;

/** Every evidenceId referenced anywhere in the body. */
export function referencedEvidenceIds(body: AnalysisBody): string[] {
  const ids = new Set<string>();
  for (const section of [body.team, body.product, body.market, body.traction]) {
    for (const fact of section.facts) for (const id of fact.evidenceIds) ids.add(id);
  }
  return [...ids];
}

/**
 * A factual claim may only cite evidence that was actually provided (rule #3 + #1:
 * a fact citing a non-existent evidence id is invented). Returns the offending ids.
 */
export function invalidEvidenceRefs(body: AnalysisBody, evidence: Evidence[]): string[] {
  const known = new Set(evidence.map((e) => e.id));
  return referencedEvidenceIds(body).filter((id) => !known.has(id));
}

/** Compose the validated body with the injected id into a full, schema-valid StartupAnalysis. */
export function composeAnalysis(startupId: string, body: AnalysisBody): StartupAnalysis {
  return { startupId, ...body };
}
