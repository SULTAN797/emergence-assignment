/**
 * Analysis stage — reason over a candidate's evidence to produce a validated
 * StartupAnalysis (team / product / market / traction / risks / unknowns).
 * Facts cite evidence; unknowns are explicit; nothing is invented.
 */
export { analyzeCandidate, fallbackAnalysis } from "./analyze";
export type { AnalyzeOptions, AnalyzeResult } from "./analyze";
export { runAnalysis } from "./analysis";
export type { RunAnalysisOptions, AnalysisRunResult } from "./analysis";
export { buildCandidateEvidence } from "./evidence";
export { buildAnalysisRequest } from "./prompt";
export { AnalysisBody, composeAnalysis, invalidEvidenceRefs, referencedEvidenceIds } from "./schema";
