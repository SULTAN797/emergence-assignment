import { Evidence, type StartupCandidate } from "../../domain";
import { hashKey } from "../../infra";

/**
 * Minimal evidence bridge: derive `Evidence[]` from what Sourcing already collected
 * (one-liner, batch, HN points) — each item verbatim, with its real source URL.
 *
 * This is NOT the full Evidence stage (website fetch + snippet extraction is a later
 * step). It exists so Analysis has real, cited facts to reason over today. Every id is
 * deterministic so it is stable across runs and traceable back to a source.
 */
export function buildCandidateEvidence(candidate: StartupCandidate): Evidence[] {
  const items: Evidence[] = [];
  const ycUrl =
    candidate.sourceRecords.find((r) => r.source === "yc")?.url ?? candidate.sourceRecords[0]?.url;
  const hnRecord = candidate.sourceRecords.find((r) => r.source === "hn");

  const push = (partial: Omit<Evidence, "id">): void => {
    const id = `${candidate.id}-${hashKey(`${partial.sourceUrl}|${partial.snippet}`).slice(0, 8)}`;
    items.push(Evidence.parse({ id, ...partial }));
  };

  if (candidate.description && ycUrl) {
    push({
      startupId: candidate.id,
      kind: "product",
      snippet: candidate.description,
      sourceType: "yc",
      sourceUrl: ycUrl,
      sourceTitle: `${candidate.name} — YC profile`,
      retrievedAt: candidate.discoveredAt,
    });
  }
  if (candidate.signals.batch && ycUrl) {
    push({
      startupId: candidate.id,
      kind: "traction",
      snippet: `Backed by Y Combinator, batch ${candidate.signals.batch}.`,
      sourceType: "yc",
      sourceUrl: ycUrl,
      retrievedAt: candidate.discoveredAt,
    });
  }
  if (candidate.signals.hnPoints !== undefined && hnRecord) {
    push({
      startupId: candidate.id,
      kind: "traction",
      snippet: `${candidate.signals.hnPoints} points on a Hacker News discussion.`,
      sourceType: "hn",
      sourceUrl: hnRecord.url,
      retrievedAt: hnRecord.retrievedAt,
    });
  }
  return items;
}
