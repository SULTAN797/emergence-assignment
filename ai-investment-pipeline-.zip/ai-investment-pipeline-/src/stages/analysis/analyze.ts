import type { z } from "zod";
import { AnalysisSection, type Evidence, StartupAnalysis, type StartupCandidate } from "../../domain";
import type { LlmClient } from "../../infra";
import { buildAnalysisRequest } from "./prompt";
import { AnalysisBody, composeAnalysis, invalidEvidenceRefs } from "./schema";

export interface AnalyzeOptions {
  maxAttempts?: number; // default 3
}

export interface AnalyzeResult {
  analysis: StartupAnalysis;
  status: "ok" | "fallback"; // "fallback" => LLM output never validated; explicit-unknown result
  attempts: number;
  issues: string[]; // why attempts were rejected (for the run log / trail)
}

/** Strip optional ```json fences, then JSON.parse. Returns undefined on any failure. */
function parseJson(raw: string): unknown {
  const cleaned = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    return undefined;
  }
}

function firstIssues(error: z.ZodError): string {
  return error.issues
    .slice(0, 3)
    .map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`)
    .join("; ");
}

function unknownSection(what: string): z.infer<typeof AnalysisSection> {
  return { summary: `Insufficient evidence to assess ${what}.`, facts: [], confidence: "low" };
}

/** Explicit-unknown analysis used when no LLM attempt produced valid output. Never invents. */
export function fallbackAnalysis(startupId: string): StartupAnalysis {
  return StartupAnalysis.parse({
    startupId,
    team: unknownSection("the team"),
    product: unknownSection("the product"),
    market: unknownSection("the market"),
    traction: unknownSection("traction"),
    risks: [],
    unknowns: ["A structured analysis could not be produced from the available evidence."],
  });
}

/**
 * Analyze one candidate. Pure w.r.t. I/O — the LLM is injected, so tests drive it with a fake.
 *
 * Each attempt must clear three gates before it is accepted:
 *   1. parse as JSON, 2. validate against the Zod schema, 3. cite only provided evidence ids.
 * If no attempt passes, returns an explicit-unknown analysis (rule #6) rather than anything invented.
 */
export async function analyzeCandidate(
  candidate: StartupCandidate,
  evidence: Evidence[],
  thesis: string,
  llm: LlmClient,
  opts: AnalyzeOptions = {},
): Promise<AnalyzeResult> {
  const req = buildAnalysisRequest(candidate, evidence, thesis);
  const maxAttempts = Math.max(1, opts.maxAttempts ?? 3);
  const issues: string[] = [];

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    let raw: string;
    try {
      raw = await llm.generate(req);
    } catch (err) {
      issues.push(`attempt ${attempt}: LLM error: ${err instanceof Error ? err.message : String(err)}`);
      continue;
    }

    const json = parseJson(raw);
    if (json === undefined) {
      issues.push(`attempt ${attempt}: response was not valid JSON`);
      continue;
    }

    const parsed = AnalysisBody.safeParse(json);
    if (!parsed.success) {
      issues.push(`attempt ${attempt}: schema validation failed: ${firstIssues(parsed.error)}`);
      continue;
    }

    const badRefs = invalidEvidenceRefs(parsed.data, evidence);
    if (badRefs.length > 0) {
      issues.push(`attempt ${attempt}: cited unknown evidence ids: ${badRefs.join(", ")}`);
      continue;
    }

    // Final belt-and-suspenders: validate the composed, id-injected analysis.
    const analysis = StartupAnalysis.parse(composeAnalysis(candidate.id, parsed.data));
    return { analysis, status: "ok", attempts: attempt, issues };
  }

  return { analysis: fallbackAnalysis(candidate.id), status: "fallback", attempts: maxAttempts, issues };
}
