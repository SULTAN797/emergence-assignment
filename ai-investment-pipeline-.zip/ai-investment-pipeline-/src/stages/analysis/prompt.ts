import type { Evidence, StartupCandidate } from "../../domain";
import type { LlmRequest } from "../../infra";

const SYSTEM = `You are an analyst at a seed-stage VC firm. You produce a structured, evidence-grounded
analysis of a single startup, judged against the firm's thesis.

Hard rules — follow exactly:
1. NEVER invent information. If a fact is not supported by the provided evidence, do not state it.
2. Separate facts from inference. "summary" is YOUR inference/synthesis. "facts" are specific claims,
   and EVERY fact MUST cite one or more evidenceIds drawn ONLY from the provided evidence list.
3. Never cite an evidenceId that is not in the provided evidence. Do not fabricate ids.
4. If the evidence is insufficient for a section, return an empty "facts" array, a short honest
   "summary" saying what is not known, and set "confidence" to "low". Add the gap to "unknowns".
5. Output ONLY a single JSON object matching the requested shape. No prose outside the JSON.`;

function evidenceBlock(evidence: Evidence[]): string {
  if (evidence.length === 0) return "(no evidence provided)";
  return evidence
    .map((e) => `- id="${e.id}" [${e.kind}] (${e.sourceType}) "${e.snippet}" <${e.sourceUrl}>`)
    .join("\n");
}

const SHAPE = `{
  "team":      { "summary": string, "facts": [{ "statement": string, "evidenceIds": string[] }], "confidence": "high"|"medium"|"low" },
  "product":   { "summary": string, "facts": [ ... ], "confidence": ... },
  "market":    { "summary": string, "facts": [ ... ], "confidence": ... },
  "traction":  { "summary": string, "facts": [ ... ], "confidence": ... },
  "risks":     string[],
  "unknowns":  string[]
}`;

/** Build the analysis request for one candidate. Deterministic (no timestamps / randomness). */
export function buildAnalysisRequest(
  candidate: StartupCandidate,
  evidence: Evidence[],
  thesis: string,
): LlmRequest {
  const prompt = `THESIS:
${thesis}

STARTUP:
name: ${candidate.name}
website: ${candidate.website ?? "(unknown)"}
one-liner: ${candidate.description ?? "(unknown)"}

EVIDENCE (cite these ids only):
${evidenceBlock(evidence)}

TASK:
Analyze this startup across team, product, market, and traction; list risks ("what would kill this")
and unknowns (signals you could not find). Judge relevance against the thesis, but do not score here.

Return ONLY a JSON object with this exact shape:
${SHAPE}`;

  return { system: SYSTEM, prompt, json: true, temperature: 0 };
}
