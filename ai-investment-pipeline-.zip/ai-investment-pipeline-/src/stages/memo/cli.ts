import { parseArgs } from "node:util";
import { join } from "node:path";
import { runMemos } from "./memo";

/**
 * Independently runnable Memo stage. Fully deterministic — no LLM, no API key.
 *
 *   npm run memo -- --run-id <run-id>
 */
async function main(): Promise<void> {
  const { values } = parseArgs({
    options: {
      "run-id": { type: "string" },
      "run-dir": { type: "string" },
      "runs-root": { type: "string" },
    },
  });

  const runsRoot = values["runs-root"] ?? "runs";
  const runDir = values["run-dir"] ?? (values["run-id"] ? join(runsRoot, values["run-id"]) : undefined);
  if (!runDir) {
    console.error("Usage: npm run memo -- --run-id <run-id>");
    process.exit(1);
  }

  const result = await runMemos({ runDir });
  console.log(`\nMemos written → ${runDir}/memos/  (+ summary.md)`);
  console.log(`  memos: ${result.written} | skipped: ${result.skipped.length}`);
  for (const s of result.skipped) console.warn(`  ⚠ ${s.id}: ${s.reason}`);
}

main().catch((err: unknown) => {
  console.error("Memo generation failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
