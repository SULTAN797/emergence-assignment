/**
 * Memo stage — render a one-page, ~60-second Markdown memo per recommendation and a
 * ranked summary index. Deterministic assembly from analysis + recommendation + evidence;
 * no LLM. Every factual bullet carries a numbered source reference.
 */
export { renderMemo } from "./render";
export { renderSummary } from "./summary";
export type { SummaryRow } from "./summary";
export { runMemos } from "./memo";
export type { RunMemoOptions, MemoRunResult } from "./memo";
