import { readFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { Evidence, Recommendation, StartupAnalysis, StartupCandidate } from "../../domain";
import { writeText } from "../../infra";
import { renderMemo } from "./render";
import { renderSummary, type SummaryRow, type UnscoredRow } from "./summary";

export interface RunMemoOptions {
  runDir: string;
  seed?: string; // for the summary title (falls back to meta.json / runDir)
}

export interface MemoRunResult {
  written: number;
  skipped: { id: string; reason: string }[];
}

async function readJsonIfExists<T>(file: string): Promise<T | undefined> {
  try {
    return JSON.parse(await readFile(file, "utf8")) as T;
  } catch {
    return undefined;
  }
}

/**
 * Memo stage: render one Markdown memo per recommendation (deterministic, no LLM) plus a
 * ranked summary.md. Per-item isolation — a missing analysis for one startup skips only that memo.
 * Writes runs/<id>/memos/<cid>.md and runs/<id>/summary.md.
 */
export async function runMemos(opts: RunMemoOptions): Promise<MemoRunResult> {
  const recsRaw = await readJsonIfExists<unknown>(join(opts.runDir, "recommendations.json"));
  if (recsRaw === undefined) throw new Error(`no recommendations.json in ${opts.runDir} — run scoring first`);
  const recommendations = Recommendation.array().parse(recsRaw);

  const candRaw = await readJsonIfExists<unknown>(join(opts.runDir, "candidates.json"));
  const candidates = StartupCandidate.array().parse(candRaw ?? []);
  const candidateById = new Map(candidates.map((c) => [c.id, c]));

  const meta = await readJsonIfExists<{ seed?: string }>(join(opts.runDir, "meta.json"));
  const seed = opts.seed ?? meta?.seed ?? opts.runDir;

  // Clear stale memos so a candidate that is no longer scored can't leave a misleading old memo behind.
  await rm(join(opts.runDir, "memos"), { recursive: true, force: true });

  const result: MemoRunResult = { written: 0, skipped: [] };
  const rows: SummaryRow[] = [];

  for (const rec of recommendations) {
    const candidate = candidateById.get(rec.startupId);
    if (!candidate) {
      result.skipped.push({ id: rec.startupId, reason: "candidate not found" });
      continue;
    }
    const analysisRaw = await readJsonIfExists<unknown>(join(opts.runDir, "analysis", `${rec.startupId}.json`));
    if (analysisRaw === undefined) {
      result.skipped.push({ id: rec.startupId, reason: "analysis missing" });
      continue;
    }
    const analysis = StartupAnalysis.parse(analysisRaw);
    const evidenceRaw = await readJsonIfExists<unknown>(join(opts.runDir, "evidence", `${rec.startupId}.json`));
    const evidence = evidenceRaw !== undefined ? Evidence.array().parse(evidenceRaw) : [];

    const memo = renderMemo(candidate, analysis, rec, evidence);
    await writeText(join(opts.runDir, "memos", `${rec.startupId}.md`), memo);
    result.written += 1;
    rows.push({ candidate, rec });
  }

  const unscoredRaw = await readJsonIfExists<{ startupId: string; reason: string }[]>(
    join(opts.runDir, "unscored.json"),
  );
  const unscored: UnscoredRow[] = (unscoredRaw ?? []).map((u) => ({
    name: candidateById.get(u.startupId)?.name ?? u.startupId,
    reason: u.reason,
  }));

  await writeText(join(opts.runDir, "summary.md"), renderSummary(seed, rows, unscored));
  return result;
}
