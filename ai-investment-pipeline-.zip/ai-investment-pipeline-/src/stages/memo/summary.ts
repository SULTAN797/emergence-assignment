import type { Recommendation, RecommendationCall, StartupCandidate } from "../../domain";

const MARK: Record<RecommendationCall, string> = {
  TAKE_A_MEETING: "🟢 Take a meeting",
  WATCH: "🟡 Watch",
  PASS: "⚪ Pass",
};

export interface SummaryRow {
  candidate: StartupCandidate;
  rec: Recommendation;
}

/** A candidate that could not be scored — listed separately so it is never shown as a Pass. */
export interface UnscoredRow {
  name: string;
  reason: string;
}

/** The partner's triage view: a ranked table linking to each memo. Rows come pre-sorted by score. */
export function renderSummary(seed: string, rows: SummaryRow[], unscored: UnscoredRow[] = []): string {
  const header = `# Deal screen — ${seed}\n\n${rows.length} scored candidates, ranked by thesis fit.\n`;
  const table = [
    "| Call | Score | Company | One-liner | Memo |",
    "|---|---:|---|---|---|",
    ...rows.map(({ candidate, rec }) => {
      const oneLiner = (candidate.description ?? "").replace(/\|/g, "\\|");
      return `| ${MARK[rec.recommendation]} | ${rec.score} | ${candidate.name} | ${oneLiner} | [memo](memos/${candidate.id}.md) |`;
    }),
  ].join("\n");

  let out = `${header}\n${table}\n`;
  if (unscored.length > 0) {
    out +=
      `\n## Unscored (${unscored.length})\n\nNot evaluated — no recommendation was produced (this is **not** a Pass).\n\n` +
      "| Company | Reason |\n|---|---|\n" +
      unscored.map((u) => `| ${u.name} | ${u.reason.replace(/\|/g, "\\|")} |`).join("\n") +
      "\n";
  }
  return out;
}
