import type {
  AnalysisSection,
  Evidence,
  Recommendation,
  RecommendationCall,
  StartupAnalysis,
  StartupCandidate,
} from "../../domain";

const CALL_LABEL: Record<RecommendationCall, string> = {
  TAKE_A_MEETING: "Take a meeting",
  WATCH: "Watch",
  PASS: "Pass",
};

function host(url: string): string {
  try {
    return new URL(url).host.replace(/^www\./, "");
  } catch {
    return url;
  }
}

interface Citations {
  sources: { n: number; title: string; url: string }[];
  numFor: Map<string, number>; // evidenceId -> source number
}

/** Number sources by unique URL (so the same YC page is one entry) and map each evidence id to it. */
function buildCitations(evidence: Evidence[]): Citations {
  const urlToNum = new Map<string, number>();
  const sources: Citations["sources"] = [];
  const numFor = new Map<string, number>();
  for (const e of evidence) {
    let n = urlToNum.get(e.sourceUrl);
    if (n === undefined) {
      n = sources.length + 1;
      urlToNum.set(e.sourceUrl, n);
      sources.push({ n, title: e.sourceTitle ?? host(e.sourceUrl), url: e.sourceUrl });
    }
    numFor.set(e.id, n);
  }
  return { sources, numFor };
}

function cite(evidenceIds: string[], numFor: Map<string, number>): string {
  const nums = [...new Set(evidenceIds.map((id) => numFor.get(id)).filter((n): n is number => n !== undefined))].sort(
    (a, b) => a - b,
  );
  return nums.map((n) => `[${n}]`).join("");
}

/** One section: a one-line read + up to 3 cited facts. Every fact carries a source reference. */
function section(title: string, sec: AnalysisSection, numFor: Map<string, number>): string {
  const lines = [`**${title}.** ${sec.summary}`];
  for (const fact of sec.facts.slice(0, 3)) {
    const refs = cite(fact.evidenceIds, numFor);
    if (refs) lines.push(`- ${fact.statement} ${refs}`);
  }
  return lines.join("\n");
}

/**
 * Render a one-page memo. Deterministic, no LLM. Compact by construction (one-line reads,
 * ≤3 facts/section, ≤3 risks) so a partner gets the case in ~60 seconds. Every factual bullet
 * cites a numbered source; sections with no evidence say so plainly rather than padding.
 */
export function renderMemo(
  candidate: StartupCandidate,
  analysis: StartupAnalysis,
  rec: Recommendation,
  evidence: Evidence[],
): string {
  const { sources, numFor } = buildCitations(evidence);
  const cs = rec.categoryScores;
  const r = (n: number): number => Math.round(n);

  const thesis = candidate.description ?? analysis.product.summary;
  const thesisCite = cite(
    evidence.filter((e) => e.snippet === candidate.description).map((e) => e.id),
    numFor,
  );

  const extraRisks = analysis.risks.filter((x) => x !== rec.biggestRisk).slice(0, 2);

  const parts = [
    `# ${candidate.name} — ${CALL_LABEL[rec.recommendation]} (${rec.score}/100)`,
    candidate.website ? `${host(candidate.website)} · <${candidate.website}>` : "",
    `> ${thesis} ${thesisCite}`.trim(),
    `**Score ${rec.score}/100** — market ${r(cs.market.score)} · team ${r(cs.team.score)} · ` +
      `product ${r(cs.product.score)} · traction ${r(cs.traction.score)} · moat ${r(cs.moat.score)}` +
      (rec.gateReason ? `\n_Gate: ${rec.gateReason}._` : ""),
    section("Product", analysis.product, numFor),
    section("Team", analysis.team, numFor),
    section("Market", analysis.market, numFor),
    section("Traction", analysis.traction, numFor),
    `**Why we like it.** ${rec.strongestPositive}`,
    [`**Risks.** ${rec.biggestRisk}`, ...extraRisks.map((x) => `- ${x}`)].join("\n"),
    `**What would change our mind.**\n${rec.whatWouldChangeOurMind.map((x, i) => `${i + 1}. ${x}`).join("\n")}`,
    `**Sources.**\n${
      sources.length > 0
        ? sources.map((s) => `[${s.n}] ${s.title} — <${s.url}>`).join("\n")
        : "No public sources found."
    }`,
  ];

  return parts.filter((p) => p.length > 0).join("\n\n") + "\n";
}
