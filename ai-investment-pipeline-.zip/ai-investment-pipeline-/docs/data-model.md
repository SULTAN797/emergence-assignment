# Data Model — Pipeline Contracts

> **Version:** 1.0 · **Date:** 2026-08-25 · Design contract only (no implementation).
> These types are the boundary between stages. They map **1:1 to Zod schemas** in `src/` at build time
> (the stack already ships `zod`), which is how we satisfy *"validate LLM output with schemas."*
> Aligned to [thesis.md](thesis.md) (rubric) and [source-strategy.md](source-strategy.md) (provenance).

## Design rules (why the model looks like this)

1. **Facts vs. inference are different types.** `Evidence` = a *verbatim* sourced fact (a quote + its URL). `AnalysisSection.summary` = *inference* the LLM wrote. Never mix them; every inferred point links to the evidence under it.
2. **Unknowns are explicit, never invented.** Optional fields are `?` and may be `null`; missing signals go in `unknowns[]`. A blank is a real answer.
3. **Deterministic IDs** (slugs / content hashes, never random) so runs are replayable and artifacts diff cleanly.
4. **Provenance on every claim.** `{ sourceUrl, retrievedAt }` travels with each `Evidence`. Website text is marked as a self-reported claim via `sourceType`.
5. **Score is derived, not authored.** The LLM fills `categoryScores`; the composite `score` is a deterministic weighted sum (weights live in `thesis.md`), which is what makes a "72" reproducible and defensible.

## Notable modelling choices (and why — all in service of "don't over-design")

- **`categoryScores` + `gates` mirror the rubric** (2 gates + 5 scored, S1–S5) in `thesis.md` §6 / [scoring-model.md](scoring-model.md), so the score is measured against exactly the stated thesis.
- **`Recommendation` carries `whatWouldChangeOurMind: string[]`** — the assignment requires the memo to state *"the 2–3 things that would change your mind."*
- **`Evidence` is a verbatim fact only** (`snippet` + provenance). Reliability is encoded by `sourceType` (website = self-reported claim); confidence lives on the *inference* (the `AnalysisSection`), not on a quote.
- **`AnalysisSection` splits facts from inference** (`summary` = inference, `facts[]` each linked to evidence) so traceability is per-section, not one flat `evidenceIds` bag.
- **`founders` is optional/possibly-empty** — founder data isn't in the discovery sources; it comes from the website/LinkedIn during Analysis and is often unknown. Never invented.
- **A tiny `RunManifest`** — replayability is a hard requirement and needs one small record (seed, model, snapshot, thesis version). Nothing more.

---

## Sourcing stage

```ts
type SourceType = "yc" | "hn" | "website";

type SourceRecord = {
  source: SourceType;      // where this was discovered / corroborated
  url: string;             // canonical, citable (YC /companies/<slug>, HN item?id=)
  retrievedAt: string;     // ISO 8601
  cacheKey?: string;       // ref to the committed raw response (offline replay)
};

type Founder = {
  name: string;
  role?: string;           // e.g. "CEO", "CTO" — often unknown
  background?: string;     // one line; from website/LinkedIn, may be absent
  linkedinUrl?: string;
  evidenceIds: string[];   // [] until corroborated — never fabricate a background
};

// >=1 freshness/traction signal per candidate (assignment requirement). All fields
// optional so a missing signal is omitted, never invented; the object is always present.
type CandidateSignals = {
  batch?: string;          // YC batch, e.g. "Fall 2024" (freshness)
  launchedAt?: string;     // YC launch time, ISO 8601 (freshness)
  hnPoints?: number;       // Hacker News points (traction)
};

type StartupCandidate = {
  id: string;              // deterministic slug (e.g. yc slug)
  name: string;
  website?: string;
  description?: string;    // one-liner (YC one_liner / HN blurb)

  founders: Founder[];     // may be [] — unknown, not invented
  sourceRecords: SourceRecord[];
  signals: CandidateSignals;

  discoveredAt: string;    // ISO 8601
};
```

## Evidence (shared — the traceability backbone)

```ts
type Evidence = {
  id: string;              // deterministic (hash of startupId+sourceUrl+snippet)
  startupId: string;

  kind: "team" | "product" | "market" | "traction" | "company" | "other";

  snippet: string;         // VERBATIM text from the source — the fact itself
  sourceType: SourceType;  // website => treat as a self-reported claim
  sourceUrl: string;
  sourceTitle?: string;
  retrievedAt: string;     // ISO 8601 — freezes mutable website content
};
```

## Analysis stage

```ts
type FactPoint = {
  statement: string;       // a single sourced claim, plain language
  evidenceIds: string[];   // >=1 — a FactPoint with no evidence is not allowed
};

type AnalysisSection = {
  summary: string;                         // INFERENCE — the LLM's synthesis
  facts: FactPoint[];                      // FACTS — each linked to Evidence
  confidence: "high" | "medium" | "low";   // confidence in the inference
};

type StartupAnalysis = {
  startupId: string;

  team: AnalysisSection;
  product: AnalysisSection;
  market: AnalysisSection;
  traction: AnalysisSection;

  risks: string[];         // "what would kill this"
  unknowns: string[];      // signals we could not find — explicit
};
```

## Recommendation stage

```ts
// Binary gates (thesis.md §6, G1–G2). Fail => auto-PASS with a reason.
type Gates = {
  ventureScale: boolean;   // G1 — a venture-scale, category-defining opportunity
  earlyStage: boolean;     // G2 — genuinely pre-seed to Series A (not a mature incumbent)
};

// One scored criterion: the number, WHY (inference), and the evidence it rests on.
// evidenceIds may be [] only when the score is low — a high score with no evidence is
// an unsupported claim and is rejected in the scoring stage.
type CriterionScore = {
  score: number;           // 0–100
  explanation: string;
  evidenceIds: string[];
};

// Scored criteria = scoring-model.md rubric S1–S5. Weights live in thesis.md/config.
type CategoryScores = {
  market: CriterionScore;    // S1 25% — market size/growth + "why now"
  team: CriterionScore;      // S2 25% — insight, technical depth, domain proximity
  product: CriterionScore;   // S3 20% — differentiation, acute pain solved
  traction: CriterionScore;  // S4 15% — demand, momentum, capital efficiency
  moat: CriterionScore;      // S5 15% — data / network effects / switching costs / distribution
};

type Recommendation = {
  startupId: string;

  gates: Gates;
  categoryScores: CategoryScores;
  score: number;           // DERIVED (code): round(0.25·S1+0.25·S2+0.20·S3+0.15·S4+0.15·S5), 0–100

  recommendation: "PASS" | "WATCH" | "TAKE_A_MEETING"; // DERIVED: gates -> bands

  strongestPositive: string;         // the single strongest positive signal
  biggestRisk: string;               // the single biggest risk
  whatWouldChangeOurMind: string[];  // 2–3 items; evidence that would flip the call
  rationale: string;                 // one-line synthesis
  gateReason?: string;               // present iff a gate failed (why the auto-PASS)

  evidenceIds: string[];   // union of all evidence the scores rest on
};
```

## Run manifest (replayability)

```ts
type RunManifest = {
  runId: string;           // deterministic (e.g. seed + date passed in)
  seed: string;            // the topic/URL/feed input
  model: string;           // pinned model id
  thesisVersion: string;   // which thesis.md version scored this run
  sourceSnapshot: string;  // YC export snapshot id / date
  createdAt: string;
  counts: { candidates: number; analyzed: number; memos: number };
};
```

---

## Artifact layout (which type lands where)

| File (per run) | Type | Stage |
|---|---|---|
| `runs/<runId>/candidates.json` | `StartupCandidate[]` | Sourcing |
| `runs/<runId>/evidence/<id>.json` | `Evidence[]` (per startup) | Evidence |
| `runs/<runId>/analysis/<id>.json` | `StartupAnalysis` (per startup) | Analysis |
| `runs/<runId>/recommendations.json` | `Recommendation[]` | Scoring |
| `runs/<runId>/memos/<id>.md` | rendered from Analysis + Recommendation | Memos |
| `runs/<runId>/summary.md` | ranked index | Memos |
| `runs/<runId>/meta.json` | run provenance: seed, search plan, source counts, warnings | Sourcing |
| `.cache/http/` | shared content-addressed http+llm cache (repo root, not per-run) | all |

Per-startup files for `evidence`/`analysis` (not one big array) so a single bad candidate can't corrupt the
batch and each is independently inspectable — see [pipeline-design.md](pipeline-design.md).

The **memo is a rendered artifact**, not a type — it's assembled from `StartupAnalysis` +
`Recommendation`, so there's nothing extra to model. Every claim printed in a memo carries an
`evidenceId`, so the reviewer can trace any line back to a `sourceUrl` + `retrievedAt`.

## Deliberately NOT modeled (scope discipline)

- No `Memo` type, no per-field audit trails, no `updatedAt` on every record, no soft-delete/versioning
  on records (the `RunManifest` carries versions).
- No graph/relational structure — flat arrays keyed by `startupId`, joined in memory. No DB, per constraints.
