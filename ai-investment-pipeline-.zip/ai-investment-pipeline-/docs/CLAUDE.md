# AI Investment Pipeline

## Assignment

Build an AI-augmented investment pipeline for a seed-stage VC firm.

The pipeline must:

1. Source 10–20 startups from public sources.
2. Analyze startups.
3. Score startups against a specific investment thesis.
4. Produce Pass / Watch / Take a Meeting recommendations.
5. Generate concise one-page investment memos.
6. Preserve source traceability.
7. Be replayable.
8. Demonstrate a thoughtful AI-assisted development workflow.

## Required Pipeline

Sourcing
→ Analysis
→ Recommendation

## Important Constraints

- Use public sources.
- Pick only 1–2 sources and go deep.
- Avoid unnecessary infrastructure.
- Do not build a job queue.
- Do not build a vector database.
- Do not build a React frontend unless there is a compelling reason.
- Scope is part of the evaluation.
- Outputs should be inspectable without rerunning the pipeline.
- The pipeline should be runnable with one command.
- Do not invent missing information.
- Claims in final memos must be traceable to sources.

## Engineering Principles

- Prefer simple solutions.
- Persist intermediate artifacts.
- Keep pipeline stages independent.
- Validate LLM output with schemas.
- Separate facts from inference.
- Explicitly represent unknown information.
- Keep prompts version controlled.
- Make important design decisions documented.
- Optimize for reviewer usability rather than infrastructure complexity.