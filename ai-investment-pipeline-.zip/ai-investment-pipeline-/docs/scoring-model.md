# Scoring Model

> **Version:** 1.0 · **Date:** 2026-08-25 · **Status:** Locked. This is the rubric of record; it feeds
> `CategoryScores` + `Gates` in [data-model.md](data-model.md) and is summarized in [thesis.md](thesis.md) §6–§7.

## The governing principle

The score must be **meaningful and reproducible**. Two rules get us there:

1. **Weight ∝ (observability × differentiation).** Criteria we can actually see from public data *and* that
   genuinely separate companies get the most weight. Speculative or near-constant criteria get little or none.
2. **Binary assumptions are gates, not scores.** "Is this a venture-scale, early-stage startup?" is a yes/no
   disqualifier — scoring it would waste weight and let a non-startup earn a high composite. So it's a gate.

> The LLM fills evidence-backed sub-scores; the total and the call are computed **in code**. That separation is
> what makes a "72 → Watch" defensible and reproducible rather than a model's mood.

---

## The framework: 2 gates + 5 scored criteria

### Gates (binary — not scored)

The **Scoring** stage records the formal gate verdicts on the `Recommendation` (grounded in the evidence gathered
by then, each with a one-line reason).

| Gate | Pass condition | Why a gate, not a score |
|---|---|---|
| **G1 — Venture-scale** | Could plausibly become a large, category-defining business (not lifestyle/agency/niche) | Binary; a high score on a non-venture-scale business is meaningless |
| **G2 — Early-stage** | Genuinely pre-seed to Series A (not a mature incumbent or public company) | Binary; the thesis only backs early-stage |

Gate failure ⇒ the company is carried as an **auto-PASS with a stated reason** (so the reviewer sees *why* it was
excluded), not scored then averaged up.

### Scored criteria (each 0–100, weighted to 100)

| # | Criterion | Weight | Observable | Relevant | Independent | Differentiates |
|---|---|---:|---|---|---|---|
| S1 | **Market** — size / structural growth of the market and a clear "why now" catalyst | **25** | Medium–High | **Highest** | High | **High** |
| S2 | **Team** — founder insight, technical capability, credible domain proximity | **25** | Medium (often unknown) | **High** | High | **High** |
| S3 | **Product** — differentiation and whether it resolves an acute, validated pain | **20** | High (product/site) | High | High | High |
| S4 | **Traction** — real demand and momentum (usage, revenue, funding, attention) | **15** | Medium (sparse early) | High | Medium–High | Medium–High |
| S5 | **Moat** — proprietary data, network effects, switching costs, distribution | **15** | Low–Medium (inference) | High | Medium | Medium |
| | **Total** | **100** | | | | |

**Weights follow the principle:** Market and Team — the two axes that most separate outliers from the pack and are
still assessable from public evidence — carry the most weight; Moat, the most speculative to judge early, carries
the least.

**The one residual overlap, stated honestly:** Product (differentiation *today*) and Moat (durability *tomorrow*)
correlate. We keep them separate but define S3 on present capability and S5 on what protects it over time, and hold
S5's weight to 15 so the correlation can't dominate.

## Scoring bands

| Composite score | Call |
|---|---|
| **75–100** | **TAKE A MEETING** |
| **60–74** | **WATCH** |
| **0–59** | **PASS** |

Bands are tuned to the real score distribution once we've run a set — don't treat 60/75 as sacred before seeing
the histogram.

## How the score is computed (deterministic + honest about unknowns)

- `score = round( 0.25·S1 + 0.25·S2 + 0.20·S3 + 0.15·S4 + 0.15·S5 )` — the LLM fills S1–S5 with evidence; the
  aggregation is **code, not the model**, so it's reproducible.
- **No unsupported claims.** A criterion scored above 40 must cite at least one piece of provided evidence; a high
  score with no evidence is rejected. Any evidence id cited must exist in the provided evidence.
- **Unknown signal ⇒ score conservatively (low) and lower confidence** — never impute a high score to fill a gap.
- **Infrastructure failures are not judgments.** If the model can't return valid, grounded output (or a provider
  error blocks it), the company is recorded as **unscored with a reason** — never a fabricated PASS.
- Each S-score cites the `evidenceIds` it rests on, so any number is traceable to a source.
