# Pipeline Design

> **Version:** 1.0 · **Date:** 2026-08-25 · Design only — no implementation.
> Realizes the contracts in [data-model.md](data-model.md), the rubric in [scoring-model.md](scoring-model.md),
> and the sources in [source-strategy.md](source-strategy.md). Honors the constraints in `CLAUDE.md`
> (stages independent · artifacts persisted · replayable · schema-validated · no queue/DB/frontend).

## Verdict on the proposed design

Keep it. The 5 stages map 1:1 to the data model, and two of the splits are the important ones:
**Evidence vs. Analysis** = facts vs. inference (a stage boundary, not just a field), and **Scoring vs.
Memos** = machine numbers vs. human rendering. What I'm adding is not new stages — it's the **layer under
the stages** (cache, per-item isolation, schema boundaries, the LLM-vs-deterministic split) that turns a
clean diagram into something a reviewer can replay offline and trust.

## Architecture

```
   seed query ("AI receptionists for home services")
        │
        │   ┌── config (versioned) ──────────────────────────────────────────────┐
        │   │  thesis: weights · gates · bands   sources: batches/keywords         │
        │   │  LLM: Gemini (@google/genai)        src/stages/*/prompt.ts (versioned)  │
        │   │       pinned id · temp=0 · GEMINI_API_KEY                             │
        │   └─────────────────────────────────────────────────────────────────────┘
        ▼
   ┌──────────┐  fetch YC snapshot + HN → coarse filter → LLM relevance classifier
   │ SOURCING │  ──▶ candidates.json                       [deterministic + 1 LLM/candidate]
   └────┬─────┘
        ▼
   ┌──────────┐  fetch website/raw (cached) → extract VERBATIM snippets + provenance
   │ EVIDENCE │  ──▶ evidence/<id>.json                    [det. fetch + LLM extract · FACTS only, no reasoning]
   └────┬─────┘
        ▼
   ┌──────────┐  LLM reasons over evidence → team/product/market/traction + risks + unknowns
   │ ANALYSIS │  ──▶ analysis/<id>.json                    [LLM inference · every point cites evidenceIds]
   └────┬─────┘
        ▼
   ┌──────────┐  gates (det.) → LLM fills S1–S5 w/ evidence → det. weighted sum → band → guardrail
   │ SCORING  │  ──▶ recommendations.json                  [LLM sub-scores · DETERMINISTIC aggregation/call]
   └────┬─────┘
        ▼
   ┌──────────┐  render Markdown from analysis + recommendation; build ranked index
   │  MEMOS   │  ──▶ memos/<id>.md + summary.md            [DETERMINISTIC render · no LLM]
   └──────────┘
        │
        └── everything lands in runs/<runId>/ (+ meta.json) ── committed for the reviewer

   ══ cache (content-addressed, cross-cutting) ═════════════════════════════════════════════
      http:  YC snapshot · HN Algolia JSON · website HTML      llm:  hash(prompt + input + model)
      → re-runs are free & offline; the cache lives at .cache/http/, shared across runs
```

## Stage contracts

Each stage is a pure function `(inputArtifact, config) → outputArtifact`, **Zod-validated on both the way in
and the way out**. Each is runnable standalone from the previous artifact (independence + inspectability).

| Stage | Input | Output | LLM? | Deterministic part | Per-item failure |
|---|---|---|---|---|---|
| **Sourcing** | seed + source config | `candidates.json` (`StartupCandidate[]`) | 1 relevance call/candidate | fetch YC snapshot + HN; coarse tag/industry/keyword filter | a source down → log + continue with the other |
| **Evidence** | candidates | `evidence/<id>.json` (`Evidence[]`) | extract verbatim snippets | fetch + cache website/raw; attach `{sourceUrl, retrievedAt}` | no website → evidence from YC/HN only; never invent |
| **Analysis** | candidate + its evidence | `analysis/<id>.json` (`StartupAnalysis`) | yes — reasoning | assemble sections; enforce every `FactPoint` has ≥1 evidenceId | thin evidence → low `confidence` + populated `unknowns[]` |
| **Scoring** | analysis + evidence | `recommendations.json` (`Recommendation[]`) | S1–S5 sub-scores + rationale | gates, `Σ wᵢ·Sᵢ`, band, S1<40 guardrail | missing signal → score low + `confidence:"low"` |
| **Memos** | analysis + recommendation | `memos/<id>.md`, `summary.md` | no | template render + rank | one memo fails → render the rest; note the gap in summary |

**Why Memos has no LLM:** the prose (`rationale`, `whatWouldChangeOurMind`) is already produced in Scoring and
stored structurally. The memo is *assembly*, so it's fully deterministic and regenerable without re-spending
tokens or risking drift.

## Cross-cutting concerns (the part the diagram didn't show)

### 1. Cache = the replayability backbone (most important)
A content-addressed cache wraps **all** external I/O — every HTTP fetch and every LLM call — keyed by a hash
of its inputs (`prompt + input + model` for LLM; URL + params for HTTP).
- First run populates it; re-runs hit it → **deterministic, free, offline**.
- The cache is shared across runs at `.cache/http/`. `--offline` is cache-only: it replays whatever that
  cache already holds and fails loudly on a miss rather than silently going to the network.
- Temp=0 + pinned model narrows LLM variance, but the **cache**, not temperature, is the real guarantee.

### 2. Per-item error isolation (serves the 20% "robust to bad data" rubric line)
Stages 2–5 loop per startup inside an isolated `try/catch`. A fetch error, an empty page, or a schema
violation after retries downgrades *that one* record to a partial/errored status with a reason — **the batch
never dies**. Robustness is a design property here, not an afterthought.

### 3. Schema validation at every boundary
Zod schemas (from [data-model.md](data-model.md)) validate each artifact on read and write. We ask Gemini for
structured output via its native `responseSchema` (JSON mode) to *request* the right shape, then **Zod
validates the returned JSON regardless** — a mismatch triggers a bounded retry, then falls back to an explicit
`unknown`. This is the `CLAUDE.md` "validate LLM output with schemas" principle, enforced at the seams and
independent of the provider.

### 4. Facts vs. inference / deterministic vs. LLM
A hard rule visible in the table: **Evidence = verbatim facts with provenance; Analysis = inference that
cites them; aggregation, gates, bands, and memo rendering are deterministic code.** The LLM proposes; code
disposes. That's what makes a "72 → Watch" call reproducible and auditable.

### 5. Config & prompts
Externalized, not hard-coded: thesis weights/gates/bands, source batches/keywords, model id, and
the prompt templates, which live beside the stage that owns them in `src/stages/*/prompt.ts`.

### 6. Run directory
```
runs/<runId>/
  meta.json              run provenance (seed, searchPlan, source URLs + counts, warnings)
  candidates.json
  evidence/<id>.json
  analysis/<id>.json
  recommendations.json
  memos/<id>.md
  summary.md             partner triage view: ranked table (call · score · one-liner)
                         (the http+llm cache is shared at `.cache/http/`, not per-run)
```

## Orchestrator / one command

A single CLI entrypoint runs the whole chain, and the same entrypoint exposes the seams:

```
npm run pipeline -- --query "AI receptionists for home services" [--limit 15]
npm run pipeline -- --query "…" --offline   # cache-only: no network, no API keys
```
- Default `run` = the assignment's "one command, topic in → memos out."
- Each stage also has its own entrypoint, run off the previous stage's artifact:
  `npm run source|analyze|score|memo -- --run-id <id>` — the independence isn't decorative.

## What we deliberately do NOT build (scope discipline)

- **No job queue** — a synchronous `for` loop with bounded concurrency over ~15 items is plenty.
- **No database / vector DB** — flat JSON files in the run dir, joined in memory by `startupId`.
- **No server / React frontend** — `summary.md` + per-startup Markdown *is* the UI; it renders in GitHub.
- **No streaming/eventing/orchestration framework** — five function calls in sequence.

## Open decisions (don't block)

- **Evidence extraction depth** — LLM-extract atomic snippets vs. store larger cached blobs and let Analysis
  quote them. Leaning LLM-extract (cleaner `Evidence` records) but it adds a call per candidate.
- **Concurrency** — sequential is simplest and safest for rate limits; a small `p-limit` pool (≈3–5) if the
  full run is too slow. Not a queue.
- **runId scheme** — human-readable (`<slug>-<date>`) vs. content hash. Recommend readable + a committed
  canonical run the README points at.

---

*Reconciliation: this adopts per-startup `evidence/<id>.json` and `analysis/<id>.json` (your diagram) over
the single-file layout first sketched in data-model.md — better for per-item isolation and inspection.
Updating data-model.md's artifact table to match.*
