# Assignment Analysis — AI-Augmented Investment Pipeline

> Planning document. **No code here, by design.** This is the map we build against.
> Author's note on honesty: this analysis was produced with Claude (planning + structuring).
> That is allowed and, per the rubric, is itself part of the trail. The *reflective / personal*
> writing required by the assignment (how it felt to work, what you learned, judgment calls in
> your own voice) must be written by **you**, not ghostwritten — see [Risks](#6-risks).

---

## 0. The one thing that should drive every decision

The rubric is **40% "Process & AI workflow visibility."** That is double the next-largest
category and larger than *all pure engineering combined* (System design 10% + Code quality 10% = 20%).

**Implication:** the pipeline is the easy part. The differentiator is a **genuine, continuous,
honest trail of how you worked with AI** — decisions, prompts, dead-ends, overrides. Most
candidates will over-build the pipeline and leave no trail. Invert that instinct. Build a *sharp,
small* pipeline and instrument the *process* obsessively and honestly, as you go, not after.

Second-order read of the weights:

| Lever | Weight | What actually moves it |
|---|---|---|
| Process & AI visibility | 40% | Authentic decision log, prompt library, honest AI-authorship notes, meaningful commit history, the walkthrough video |
| Output quality | 20% | Memos a partner would skim; **defensible** scores; graceful handling of missing data |
| Scoping & judgment | 20% | Narrow, specific thesis held *consistently*; 1–2 sources done deep; right corners cut |
| System design | 10% | Clean stage separation, replayable, no overengineering |
| Code quality | 10% | Readable, modular, *appropriately* tested |

60% of the grade (Process + Scoping) rewards **taste and honesty**, not lines of code.

---

## 1. Explicit Requirements

Everything in this section is stated in the assignment PDF or `docs/CLAUDE.md`. Nothing here is my invention.

### 1.1 Functional — the pipeline (Sourcing → Analysis → Recommendation)

**Sourcing**
- Accept a **seed input**: a topic query (e.g. *"AI agents for SMBs"*), a list of URLs, **or** a feed (e.g. YC W25 batch).
- Collect **10–20 candidate startups**.
- Each candidate must carry: **name**, **website**, **one-line description**, **founders/team signal** (where findable), and **≥1 freshness or traction signal** (recent launch, funding, HN traction, GitHub activity — your pick).
- **Pick 1–2 sources and go deep.**

**Analysis** — per startup, a structured analysis covering:
- **Team** — founder backgrounds, prior exits, technical depth.
- **Product** — what they actually do, in plain language.
- **Market** — size hint, competitive landscape, why now.
- **Risks / open questions** — what would kill this.
- **Score 0–100** against *your stated thesis*.
- You must **define the thesis**; it must be **specific and defensible**.

**Recommendation** — per startup:
- A **one-page memo** ending in a clear call: **Pass / Watch / Take a meeting**.
- With **rationale** and **the 2–3 things that would change your mind**.

### 1.2 Operational / non-functional

- **Public sources only** (free tiers fine).
- **One command** runs the pipeline end-to-end.
- **Commit the outputs** — reviewer must not need to re-run.
- Outputs must be **inspectable without rerunning**.
- **Replayable.**
- **Source traceability**: every claim in a final memo must be traceable to a source.
- **Do not invent missing information**; **explicitly represent unknowns**.
- **Demonstrate the AI-assisted development workflow** visibly.

### 1.3 Engineering principles (from `docs/CLAUDE.md`)

- Prefer simple solutions.
- Persist intermediate artifacts.
- Keep pipeline stages independent.
- Validate LLM output with schemas.
- Separate facts from inference.
- Explicitly represent unknown information.
- Keep prompts version-controlled.
- Document important design decisions.
- Optimize for reviewer usability over infrastructure complexity.

### 1.4 Submission requirements

- A **repo (or zip)**.
- A **~5-minute walkthrough video** (Loom or similar) showing **one startup end-to-end**.
- Reviewer must be able to: run it, read committed outputs, and form a picture of how it was built.

### 1.5 Hard constraints (must NOT)

- **No job queue.**
- **No vector DB / vector DB cluster.**
- **No React frontend** unless there's a compelling reason.
- Avoid unnecessary infrastructure / don't overengineer.
- Stack = your choice; LLM = any model.

---

## 2. What the Rubric Rewards (and how to win each line)

1. **Process & AI workflow visibility (40%)** — By the end of the read, the reviewer must have a *real picture* of how you thought, planned, prompted, debugged, and decided. **The choice of form is graded** — so choosing good forms (decision log, prompt library, honest AI-usage notes, commit narrative, video) is itself points.
2. **Output quality (20%)** — Memos a partner would actually skim in 60 seconds. Scores that are **defensible** (you can explain *why* 72 not 55). **Robust to bad or missing data** — no crashes, no fabrication, unknowns shown as unknown.
3. **Scoping & judgment (20%)** — Right problems picked, right corners cut. **Thesis specific and held consistently** across all startups.
4. **System design (10%)** — Clean separation between stages. Replayable. No overengineering.
5. **Code quality (10%)** — Readable, modular, *appropriately* tested (not exhaustively — appropriately).

---

## 3. What the Assignment Explicitly Warns Against

**Named anti-patterns:**
- Code dumped with no window into how it got built.
- Reflective writing that reads like a model wrote it about how a model was used.
- A trail **clearly assembled after the fact** to look thorough.
- A **12-source sourcing layer where each source returns 2 garbage results** (breadth theater — go deep instead).
- Claims in memos with **no traceable source**.
- A thesis **so broad ("good companies")** the score is meaningless.

**Ground-rule warnings:**
- Use AI freely — but **be honest about it**. Hiding AI is penalized; using it is not.
- **Don't ghostwrite reflective writing** — "it's obvious."
- **Don't pad. Volume isn't signal.**

**Scope warnings (the literal word used is "stop"):**
- Building a job queue, vector DB cluster, or React frontend → stop.

---

## 4. My Decisions (proposed defaults — you own these; confirm or override)

These are the decisions I recommend locking so we can move. They have sensible defaults; the
genuinely-uncertain ones are escalated to [Open Questions](#7-open-questions). **You are the owner
of the thesis and any judgment call** — I'm proposing, not deciding.

| # | Decision | Proposed default | Why |
|---|---|---|---|
| D1 | **Stack** | TypeScript + Node (already scaffolded: `zod`, `tsx`, `dotenv`, `vitest`) | It's already set up. Zod = schema validation requirement, for free. Don't re-litigate the stack — that's wasted scope. |
| D2 | **Schema/validation** | **Zod** as the contract between every stage | Directly satisfies "validate LLM output with schemas" + "keep stages independent." |
| D3 | **LLM** | **Gemini** (Google), via `@google/genai`, temp 0, pinned, `GEMINI_API_KEY`. Used in Sourcing (relevance filter), Evidence (extraction), Analysis, and Scoring — **Memos are deterministic, no LLM**. (Claude Code remains the *dev* assistant; Gemini is the *pipeline's* runtime LLM — kept separate behind the LLM wrapper.) | Google's free tier fits "public sources / free tiers fine"; provider is swappable behind the wrapper. Confirm the exact current Gemini model id (Flash tier for cheap steps, Pro tier for reasoning) from Google AI docs at build — it moves fast. |
| D4 | **Sources (go deep on 1–2)** | **Hacker News (Algolia API)** as primary + **one** of {YC public directory, GitHub API} as secondary | HN Algolia is free, keyless, great freshness/traction signal. Secondary adds team/technical depth. Avoids fragile/ToS-risky scraping (Twitter, Product Hunt auth). See [Open Questions](#7-open-questions). |
| D5 | **Handoff between stages** | **Plain JSON files on disk** per run, no DB, no queue | Satisfies "persist intermediate artifacts," "stages independent," "replayable," and the no-infra constraints in one move. |
| D6 | **Memo format** | **Markdown**, one file per startup + a ranked `summary.md` index | Renders in GitHub, diff-able, committable, inspectable without rerunning. No frontend needed. |
| D7 | **Scoring method** | **Transparent weighted rubric**: LLM fills sub-scores (with evidence), code aggregates deterministically to 0–100 | Makes scores *defensible* and *consistent* (rubric line 3). Avoids opaque "vibe" scoring. |
| D8 | **Call thresholds** | Deterministic score bands → Pass / Watch / Take a meeting; LLM only *phrases* the rationale from the analysis | Keeps the call reproducible and grounded; no hallucinated verdicts. |
| D9 | **Traceability model** | Every fact carries an **evidence ref** `{source_url, snippet, retrieved_at}`; schema separates **`facts`** (sourced) from **`inference`** (LLM reasoning) | Satisfies traceability + "separate facts from inference" + "don't invent." |
| D10 | **Unknowns** | Explicit `null` / `"unknown"` + `confidence` fields — never a fabricated value | "Explicitly represent unknown information." Directly serves the "robust to missing data" rubric line. |
| D11 | **Replayability** | Content-addressed **cache of HTTP fetches + LLM responses**, committed for the demo run; low/zero temperature; pinned model | Reviewer can replay the *exact* committed results offline/free. This is the backbone of "replayable + commit outputs." |
| D12 | **One command** | Single entrypoint runs all three stages; each stage also runnable standalone off the prior artifact | Satisfies "one command" *and* "stages independent" without contradiction. |
| D13 | **Target count** | Source ~15 to comfortably land in the 10–20 band after dedup/filtering | Margin against dedup loss and dead candidates. |
| D14 | **Testing** | Vitest on the **deterministic glue only**: schema parsing, dedup, score aggregation, traceability integrity (no memo ships a claim without an evidence ref) | "Appropriately tested" at 10% weight — test what's deterministic and load-bearing, not the LLM's prose. |
| D15 | **Reflective writing ownership** | **You** write all first-person reflection; Claude helps with architecture/code/docs only | The rubric explicitly penalizes ghostwritten reflection. Non-negotiable. |

---

## 5. Claude's Recommendations

### 5.1 Smallest viable architecture

> **Superseded — early sketch.** This 3-stage outline (source → analyze → recommend) was the first pass.
> The **authoritative design is the 5-stage pipeline** (Sourcing → Evidence → Analysis → Scoring → Memos)
> in [pipeline-design.md](pipeline-design.md); in it, memo rendering is deterministic (no LLM). Kept here
> as part of the trail, not as the current spec.

A file-based CLI pipeline. Three independent stages, each reads the previous stage's JSON artifact
and writes its own. No database, no queue, no server, no frontend. The LLM is called only inside
stages, always through a Zod schema.

```
seed input ──▶ [1] source ──▶ 01_candidates.json ──▶ [2] analyze ──▶ 02_analyses.json ──▶ [3] recommend ──▶ 03_memos/*.md + summary.md
                    │                                      │                                     │
                    └──────────── cache/ (HTTP + LLM responses, content-addressed) ─────────────┘
```

**Stage 1 — `source`**
- Input: seed (topic / URL list / feed) + source config.
- Fetch from the 1–2 chosen public sources → normalize to a `Candidate` (Zod) → dedup.
- Output: `runs/<run_id>/01_candidates.json` + raw responses in `cache/`.

**Stage 2 — `analyze`**
- Input: candidates. For each (isolated — one failure never kills the batch):
  gather the evidence collected in sourcing → LLM extraction into an `Analysis` schema
  (team / product / market / risks, each field tagged **fact vs inference** with evidence refs)
  → compute rubric sub-scores → deterministic 0–100 aggregate.
- Output: `runs/<run_id>/02_analyses.json`.

**Stage 3 — `recommend`**
- Input: analyses + thesis + score. Deterministic band maps score → Pass / Watch / Take a meeting.
  LLM only *writes the prose* of the memo, grounded strictly in the analysis (no new facts).
- Output: `runs/<run_id>/03_memos/<slug>.md`, `summary.md` (ranked triage table), `recommendations.json`.

**Cross-cutting**
- `thesis.md` (+ machine-readable rubric weights) — versioned, the single source of the thesis.
- `prompts/` — every prompt template, version-controlled.
- Zod schemas = the contract; a malformed LLM response fails fast and retries, never silently corrupts a downstream stage.
- `manifest.json` per run — run_id, seed, model, timestamps, source config, prompt/schema versions.

Why this is *smallest viable*: it satisfies stage independence, replayability, schema validation,
facts-vs-inference, explicit unknowns, one-command run, and committed inspectable outputs — while
using nothing more than files, HTTP, and an LLM SDK. Every constraint (no queue/DB/frontend) is met
by *not adding the thing*, not by working around it.

### 5.2 Where the AI-workflow trail lives (the 40%)

In this repo the trail is the `docs/` planning record itself, written before the code and kept as-is:
- **This file** — the requirements read, the decisions (D1–D15) with their rationale, the risks, and the
  questions escalated to a human rather than assumed. The AI-authorship note at the top says who wrote what.
- **[thesis.md](thesis.md), [scoring-model.md](scoring-model.md), [source-strategy.md](source-strategy.md)** —
  the judgment calls (what we bet on, how a score is derived, which two sources and why) argued out in prose
  before anything was implemented.
- **[pipeline-design.md](pipeline-design.md)** — the architecture review, including where it overrode the
  earlier sketch in §5.1 below and in [data-model.md](data-model.md).
- **Superseded sections are kept, not deleted** (see §5.1) so the revisions stay visible.
- **Prompts** live next to the stage that owns them — `src/stages/*/prompt.ts` — as version-controlled source.

### 5.3 Risks — see next section.

---

## 6. Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| R1 | **Under-investing in the 40% process trail** — building a slick pipeline, leaving no window into how it was built | **Critical** | Write the planning record (§5.2) *before* the code and keep it, superseded sections included. This is the highest-leverage work. |
| R2 | **Ghostwritten reflection** — reflective writing that reads like a model wrote it | **Critical** | You author all first-person reflection (D15). Claude never writes the "how I worked" narrative. |
| R3 | **Trail looks assembled after the fact** | High | Plan in writing first, then build against it; keep the revisions and dead ends visible rather than tidying them away. |
| R4 | **Thesis too broad** → meaningless scores (named anti-pattern) | High | Narrow, specific, defensible thesis + explicit weighted rubric; hold it consistently across all 15 startups. |
| R5 | **Untraceable / hallucinated claims** in memos | High | Evidence refs mandatory in schema; a memo that surfaces a claim with no evidence ref fails a test (D14); separate facts from inference. |
| R6 | **Source flakiness / rate limits / ToS** (esp. Twitter, Product Hunt, scraping) | High | Prefer stable free APIs (HN Algolia, GitHub, YC public); cache aggressively; degrade gracefully. |
| R7 | **Non-determinism breaks replay** — live fetches + LLM sampling | High | Cache HTTP + LLM responses and commit them; low/zero temperature; pin the model; document a "replay from cache" mode reproducing committed results. |
| R8 | **Crash on bad/missing data** (directly hits Output-quality rubric) | Medium | Per-startup error isolation; partial analysis with explicit unknowns; the batch continues. |
| R9 | **Over-scoping** — extra sources, enrichment, a UI | Medium | 1–2 sources deep; Markdown outputs; no frontend; re-read the "stop" constraint before adding anything. |
| R10 | **Results at review time differ from committed** | Medium | Commit outputs + cache; README documents replay-from-cache so the reviewer reproduces *your* run exactly. |
| R11 | **Cost/latency over 15 startups** | Low | Two-tier model use (cheap extraction, strong synthesis); cache; demo one startup E2E in the video rather than all. |

---

## 7. Open Questions (need your input before build)

These genuinely need a human call — I can recommend, but you should decide:

1. **The thesis (highest-stakes decision).** It must be narrow and defensible. Example shape:
   *"Pre-seed / seed dev-tooling startups building AI-agent infrastructure for technical teams,
   with technical founders and early open-source or usage traction."* — **What is your actual thesis?**
   Everything downstream (sources, scoring, memos) hangs off this.
2. **Which 1–2 sources?** Recommendation: **HN Algolia + one of {YC directory, GitHub}**. Do you have a
   preference, an existing API key, or a source you specifically want to show off?
3. **What seed do we demo with?** A topic query matching the thesis is cleanest for the video.
   Recommendation: a single topic query (e.g. *"AI agents for developer tooling"*). Agree?
4. **Model choice / budget.** RESOLVED — **Gemini** (Google, `@google/genai`, free tier). Exact model id
   (Flash vs. Pro tier per stage) confirmed at build. See D3.
5. **How much to commit of the `cache/`.** Full cache = perfect replay but heavier repo; curated
   subset = lighter but partial. Recommendation: commit the demo run's cache in full, gitignore the rest.
6. **Loom now or later.** The video is required and carries process weight — when do you want to record it,
   and do you want a scripted one-startup walkthrough outline drafted (by you, from the journal)?

---

## 8. Suggested build order (so the trail is authentic, not backfilled)

1. Lock thesis + rubric + sources (Open Questions 1–2). Commit `thesis.md`.
2. Scaffold schemas (Zod) + the three stage boundaries.
3. Stage 1 `source` on one source, real output committed. Journal the source choice.
4. Stage 2 `analyze` on 2–3 startups; iterate prompts; **keep the failed prompt versions**.
5. Stage 3 `recommend` + memo template; eyeball one memo as a partner would.
6. Scale to ~15; add error isolation + cache; commit the full run's outputs + cache.
7. Tests on the deterministic glue (D14). README with one-command run + replay instructions.
8. Record the ~5-min Loom on one startup end-to-end. Write the final reflection (your voice).

---

*Next step: answer the Open Questions (esp. the thesis) and I'll turn this into a concrete build
plan — still without writing code until you say go.*
