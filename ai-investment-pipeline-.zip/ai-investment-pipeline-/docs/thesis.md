# Investment Thesis — Early-Stage, Sector-Agnostic

> **Version:** 1.0 · **Date:** 2026-08-25 · **Status:** Locked for this build. Rubric = 2 gates + 5 scored criteria (see §6 / [scoring-model.md](scoring-model.md)); weights & thresholds tunable (§8).
> This file is the **single source of truth** for what the pipeline scores against. The 0–100 score in
> every analysis is measured against *this thesis and this rubric* — nothing else.

---

## 1. The thesis (one paragraph)

> We back **early-stage startups (pre-seed to Series A)** positioned to become **category-defining businesses**.
> Independent of sector, we require a convergence of five conditions:
> **(1) MARKET** — a large or structurally expanding market with a clear "why now" catalyst (a technology shift,
> regulatory change, or behavioral inflection);
> **(2) TEAM** — founders with unique insight, technical capability, and credible domain proximity;
> **(3) PRODUCT** — a differentiated product that resolves an acute, validated customer pain, not a nice-to-have;
> **(4) TRACTION** — early, capital-efficient evidence of real demand and momentum;
> **(5) MOAT** — a durable defensibility mechanism (proprietary data, network effects, high switching costs, or a
> distribution advantage) that compounds over time.
> We are biased toward product-led businesses attacking structural inefficiencies, and against undifferentiated,
> incumbent-imitating, or margin-thin models. A company earns a meeting only when **most conditions hold and its
> failure modes are understood.**

## 2. The belief (why this framework wins — the part that makes it a bet, not a screen)

- **Venture returns are driven by a handful of outliers**, and outliers cluster where a large market, a rare team,
  and a defensible wedge coincide. We optimize for that convergence rather than any single attractive attribute.
- **"Why now" is the most under-priced signal.** The best early bets ride a recent shift (a new technology,
  a regulatory opening, a change in customer behavior) that makes a previously-impossible product suddenly viable.
- **Moat, not features, compounds.** Products get copied; proprietary data, network effects, switching costs, and
  distribution advantages get harder to copy over time. We reward durability over present capability.
- **Discipline beats gut feel.** A specific, held-constant framework lets us compare a fintech tool and a dev-tools
  company on the same axes — and makes every score explainable and defensible rather than a vibe.

## 3. Scope (what the thesis does and does not fix)

- **Stage:** pre-seed to Series A. We pass on mature incumbents and public companies.
- **Sector:** agnostic. The **seed query** chooses the topic area to scan; the **thesis** judges quality *within*
  whatever comes back. The framework is the constant; the domain is the variable.
- **"Venture-scale" means:** a credible path to a large, category-defining outcome — not a lifestyle business,
  a consulting/agency model, or a narrow niche with a low ceiling.

## 4. Qualify vs. Exclude (observable gates)

**Qualifies — both gates must hold:**
1. **Venture-scale** — the opportunity could plausibly become a large, category-defining business.
2. **Early-stage** — genuinely pre-seed to Series A, still shaping product and market.

**Clearly excluded:**
- Lifestyle businesses, agencies, and consultancies (revenue without venture-scale upside).
- Mature incumbents, public companies, and their internal projects.
- Undifferentiated "me-too" products with no wedge and no path to a moat.
- Non-companies (open-source libraries, demos, news, research) surfaced by the source that aren't a startup.

**Known trouble cases** (decide consistently): a promising product with no visible team; a strong team with no
traction yet; a large market entered with a thin, easily-copied product. Default: score honestly on the evidence,
mark what is unknown, and let the composite + gates place the call.

## 5. Evidence we need (all publicly observable → keeps scores consistent)

| Criterion | Public proxy to look for |
|---|---|
| Market | Stated customer + use case; category framing; a plausible "why now" (recent tech/regulatory/behavioral shift) |
| Team | Founder backgrounds, prior companies/exits, technical depth, domain proximity |
| Product | What it actually does; differentiation; whether it solves an acute pain vs. a nice-to-have |
| Traction | Launch recency, usage, revenue, funding, community/HN attention, reviews |
| Moat | Proprietary data, network effects, switching costs, integrations/lock-in, distribution advantage |

## 6. Scoring rubric — the operational form of the thesis

> Full derivation and the observability/differentiation analysis live in [scoring-model.md](scoring-model.md).
> This is the finalized summary.

The rubric is **2 gates + 5 scored criteria**. Gates are binary disqualifiers (a great score on a company that
isn't a venture-scale, early-stage startup is meaningless). **Facts must carry a source; unknown signals are
scored low with low confidence, never invented.**

**Gates (binary — fail ⇒ auto-PASS with a stated reason):**

| Gate | Pass condition |
|---|---|
| **G1 — Venture-scale** | Could plausibly become a large, category-defining business (not lifestyle/agency/niche) |
| **G2 — Early-stage** | Genuinely pre-seed to Series A (not a mature incumbent) |

**Scored criteria (each 0–100, weighted to 100; weight ∝ observability × differentiation):**

| # | Criterion | Weight | High score | Low score |
|---|---|---:|---|---|
| S1 | **Market** (size / structural growth + "why now") | 25% | Large/expanding market with a clear recent catalyst | Small or flat market, no why-now |
| S2 | **Team** (insight, technical depth, domain proximity) | 25% | Exceptional, credible, domain-proximate founders | Thin or unproven, no domain fit |
| S3 | **Product** (differentiation, acute pain solved) | 20% | Clearly differentiated; solves an acute, validated pain | Undifferentiated; a nice-to-have |
| S4 | **Traction** (demand, momentum, capital efficiency) | 15% | Real usage/revenue/funding/attention | No visible demand or momentum |
| S5 | **Moat** (data / network effects / switching costs / distribution) | 15% | A durable, compounding defensibility mechanism | Easily copied; no wedge |

*(The LLM fills evidence-backed sub-scores; `score = round(0.25·S1 + 0.25·S2 + 0.20·S3 + 0.15·S4 + 0.15·S5)`
is computed in code — this is what makes a "72" defensible and reproducible.)*

## 7. Recommendation bands (deterministic call from score)

| Score | Call |
|---|---|
| **75–100** | **Take a meeting** |
| **60–74** | **Watch** |
| **0–59** | **Pass** |

Thresholds are provisional — tune once we see the real score distribution (§8). The memo's "2–3 things that
would change my mind" should map to the lowest S-scores.

## 8. Open sub-decisions (tunable; do not block the build)

- **Call thresholds** — revisit after seeing the score histogram so the bands aren't arbitrary.
- **Rubric weights** — S1–S5 weights (25/25/20/15/15) are a first cut; adjust if one criterion dominates or collapses.
- **Query breadth** — a broad query casts a wide net (more Pass); a specific query concentrates on-thesis candidates.

## 9. How this thesis could be wrong (honest risk to the bet)

Kept here on purpose — the reviewer grades whether the thesis is held *and* stress-tested.
- **Framework over-fit:** a rigid rubric can under-rate genuinely novel companies that break the mold.
- **Public-evidence limit:** team quality and moat are the hardest to verify from public data — we proxy them and
  flag low confidence where evidence is thin.
- **"Why now" is a judgment call:** timing catalysts are clear in hindsight and fuzzy in the moment.

---

*Consistency rule for the whole pipeline: every startup is judged against **this** document. If a scoring decision
requires a judgment not covered here, we add the rule here first, then apply it — so the thesis stays specific and
held consistently across all candidates.*
