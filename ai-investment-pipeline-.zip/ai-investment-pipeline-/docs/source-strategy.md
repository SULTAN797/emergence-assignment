# Source Strategy — Query-Driven Discovery

> **Version:** 1.0 · **Date:** 2026-08-25 · **Status:** Locked & API-verified.
> Governs the **Sourcing** stage and the evidence the **Analysis** stage may cite.
> Assignment rule honored: *"pick one or two sources and go deep"* — and its anti-pattern:
> *"a 12-source layer where each returns 2 garbage results."*

---

## TL;DR

- **Primary discovery: Hacker News (Algolia search) over the seed QUERY.** Pointing the tool at a topic returns
  candidates for that topic — this is what makes it a "point it at a topic" triage tool. We search **Show HN**
  posts specifically, because those are makers launching their own product (high precision: real startups, not
  news or discussion).
- **Secondary source: the YC export.** It does two jobs — **enriches** any HN candidate that matches a YC company
  (adds batch, one-liner, canonical URL), and **supplements** the list with query-matched YC companies when HN
  yields fewer than the target.
- **Per-candidate evidence (not a discovery source): the company's own website** — read in the Analysis stage.

**One-line rationale:** HN gives *query-relevance + freshness + traction*, YC gives *precision + curation + a
citable record*. Two sources, done deep — no breadth theater.

---

## 0. Verification (tested live)

Both APIs are keyless, reachable, and reproducible:

| Check | Hacker News (Algolia) | YC (OSS export `yc-oss.github.io/api`) |
|---|---|---|
| API reachable, no key | ✅ `hn.algolia.com/api/v1/search` | ✅ single JSON, no auth |
| Query-driven | ✅ `?query=<seed>&tags=show_hn` | keyword-matched supplement |
| Fields present | ✅ title, url, points, num_comments, author, created_at, objectID→permalink | ✅ name, website, one_liner, batch, industry, tags, launched_at, canonical url |
| Reproducible / citable | ✅ immutable `item?id=` | ✅ pin snapshot; canonical `/companies/<slug>` |

## 1. The two jobs a source must do

| Job | What it needs | Source |
|---|---|---|
| **Discovery** (find 10–20 relevant candidates for the query) | query-driven search, freshness, traction, citable | **Hacker News (Show HN)** |
| **Curation + enrichment** (confirm they're real startups; add structured facts) | a vetted registry with batch/industry/one-liner | **YC export** |

Company **websites** have essentially zero discovery ability (there is no index of "all startups for topic X"),
so they are an **enrichment** layer read in Analysis, not a discovery source — they don't count against the
"1–2 sources" budget.

## 2. Primary — Hacker News (Show HN)

- **Why Show HN, not all stories:** a general story search returns news articles, blog posts, and discussions.
  **Show HN** posts are the maker submitting their own product — overwhelmingly actual startups/products, which is
  exactly what we want to source. Precision over recall.
- **From each hit we take:** the linked **website** (origin), a **name + description** parsed from the title
  (`Show HN: Name – tagline`), **HN points** (a traction/attention signal), and the permanent **item URL**.
- **Noise filtering (deterministic):** we drop links to non-startup hosts — news/media, social, code/registries,
  VC/analyst sites — via a maintained host blocklist, and drop academic/government TLDs (`.edu/.gov/.mil`).
- **Dedupe by host**, keeping the highest-points post per company.

## 3. Secondary — the YC export

- **Enrichment:** HN candidates are matched to YC companies by website host; a match adds the **batch** (freshness),
  a curated **one-liner**, industry, and the canonical YC URL (a strong "this is a real, vetted startup" signal).
- **Supplement:** if HN returns fewer than the target (a niche query), we top up with YC companies whose text
  matches the query's significant tokens — ranked by match strength. YC companies are, by construction, real
  early-stage startups, so this raises precision as well as count.

## 4. How the choice satisfies the required candidate fields

The Sourcing stage must yield, per startup: **name, website, one-line description, founder/team signal,
≥1 freshness/traction signal.**

| Required field | Primary | Backup |
|---|---|---|
| Name | HN title / YC name | host-derived |
| Website | HN link (origin) | YC website |
| One-line description | HN title tagline | YC one-liner |
| Founder / team signal | website `/about` + YC (enrichment, Analysis stage) | — |
| ≥1 freshness / traction signal | HN points; YC batch recency + `launched_at` | — |

## 5. Ranking & count

Candidates are ranked **by traction first** (HN points) then **recency**, and capped at the target (default 15,
range 10–20). If the pool falls below 10 we surface a warning rather than pad — a signal to broaden the query.

## 6. Reproducibility, citation & caching

- **Every candidate and claim stores provenance:** `{source, source_url, retrievedAt}`. HN `item?id=` and YC
  `/companies/<slug>` URLs are permanent; website content is frozen by caching the fetched HTML in Analysis.
- **Every HTTP response is content-addressed cached**, so a committed run replays for free and offline — no keys.
- **Facts vs. inference:** HN/YC structured fields and cached website text are *facts with sources*; anything the
  LLM concludes beyond them is *inference*, flagged as such (see [thesis.md](thesis.md) §6).

## 7. What we deliberately do NOT do (scope discipline)

- No scraping of ToS-hostile or paywalled sources (Twitter/X, Crunchbase, LinkedIn).
- No third, fourth, fifth discovery source — two, done deep, with a website-enrichment layer per candidate.
